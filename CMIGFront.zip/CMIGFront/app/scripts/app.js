'use strict';

var cmigApp = angular.module('cmigApp',[
        'ui.router',
        'oc.lazyLoad'
]);

cmigApp.run(
    ['$rootScope', '$state', '$stateParams',
        function ($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
        }
    ]
);

cmigApp.config(["$provide", "$compileProvider", "$controllerProvider", "$filterProvider",
    function ($provide, $compileProvider, $controllerProvider, $filterProvider) {
        cmigApp.controller = $controllerProvider.register;
        cmigApp.directive  = $compileProvider.directive;
        cmigApp.filter     = $filterProvider.register;
        cmigApp.factory    = $provide.factory;
        cmigApp.service    = $provide.service;
        cmigApp.constant   = $provide.constant;
    }]);









