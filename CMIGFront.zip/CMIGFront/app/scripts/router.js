'use strict';

cmigApp.config(['$urlRouterProvider', '$stateProvider',function($urlRouterProvider,$stateProvider) {
    $urlRouterProvider
        .otherwise('/index');
    $stateProvider
        .state('index', {
            // abstract: true,
            // catch: false,
            url: '/index',
            templateUrl: 'common/pages/home.html',
            resolve:{
                deps:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load([
                        "common/css/home.css"
                    ]);
                }]
            }
        })
        //注册页面
        .state('register', {
            url: "/register",
            templateUrl: "common/pages/register.html",
            controller: 'registerCtrl',
            resolve:{
                deps:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load([
                        "common/css/signup.css",
                        "common/js/registerCtrl.js",
                        "common/js/jquery.slideunlock.js"
                    ]);
                }]
            }
        })
}]);