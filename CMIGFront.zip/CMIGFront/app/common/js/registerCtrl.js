/**
 * Created by pulang on 2016/10/28.
 */
'use strict';
cmigApp.controller('registerCtrl',['$scope','$state','$interval','$timeout',function($scope,$state,$interval,$timeout){



}]);
