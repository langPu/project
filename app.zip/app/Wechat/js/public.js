var http_service = "http://sfwg.cm-pro.cn/api/v1/"; //服务器地址
//var http_service = "http://bjzy.cm-dev.cn/api/v1/" ; //服务器地址
//var http_service = "http://10.16.72.53:3000/api/v1/" ; //服务器地址
//var http_service = "http://10.16.66.185:3000/api/v1/" ; //服务器地址
//var http_service = "http://10.16.73.72:3000/api/v1/" ; //服务器地址
//var http_service = "http://localhost/api/v1/" ; //服务器地址
//var image_service = ""; //图片服务地址
var image_service = "";
//var image_service="http://image.cmlejia.com/show/";
function GetRequest() {
	var url = location.search; //获取url中"?"符后的字串
	var theRequest = new Object();
	if(url.indexOf("?") != -1) {
		var str = url.substr(1);
		strs = str.split("&");
		for(var i = 0; i < strs.length; i++) {
			theRequest[strs[i].split("=")[0]] = (strs[i].split("=")[1]);
		}
	}
	return theRequest;
}

function getHeaders() {
	var wx_token = "";
	wx_token = window.location.href.split("=")[1];
//	wx_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0.eyJicF9pZCI6IjAwMmswMDAyMTkxQzNTTW9XU2FCM0EifQ.
//zfwg的
//	wx_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0.eyJicF9pZCI6IjAwMmswMDAxMThEdjBleUdzVXBDUHcifQ.
//	wx_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0.eyJicF9pZCI6IjAwMmswMDAxMThJc2lDd2VtNkJxbE0ifQ.
	localStorage.token=wx_token;
	
	return {
		"authorization": wx_token
	}
}

function get_head_token(){
	token = window.location.href.split("=")[1];
//	token=eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0.eyJicF9pZCI6IjAwMmswMDAyMTkxQzNTTW9XU2FCM0EifQ.
//zfwg的
//	?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0.eyJicF9pZCI6IjAwMmswMDAxMThEdjBleUdzVXBDUHcifQ.
//	token=eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0.eyJicF9pZCI6IjAwMmswMDAxMThJc2lDd2VtNkJxbE0ifQ.
	localStorage.token=token;
	return token;
}




function incidentStatus(incident_status){
	incident_status = incident_status.toUpperCase();
	var pairStatus = null ;
	if( incident_status == "NEW" ) {
		pairStatus = "新建"
	}else if( incident_status == "NEW_ASSIGN" ) {
		pairStatus = "已派工"
	}else if( incident_status == "WAIT_REPAIR" ) {
		pairStatus = "待维修"
	}else if( incident_status == "PENDING" ) {
		pairStatus = "处理中"
	}else if( incident_status == "DONE" ) {
		pairStatus = "维修完成"
	}else if( incident_status == "DONE_EX" ) {
		pairStatus = "完成"
	}else if( incident_status == "WAIT_ASSIGN" ) {
		pairStatus = "待分派"
	}else if( incident_status == "CANCEL" ) {
		pairStatus = "已取消"
	}
	return pairStatus ;
}



function closePpage(code) {

	//window.location = "ljh://finish_page";
	if(code == "403") {
		//alert("token："+localStorage.token);
		if(mui != null) {
			mui.toast("操作超时！")
		}
		setTimeout(function() {
			//window.location = "ljh://finish_page";
		}, 3000);
	}
}

var getRightCb = null;



function urlencode(str) {
	//str = (str + '').toString();   
	//return encodeURIComponent(str).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').  
	//replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+');  
	return encodeURI(str)
}
