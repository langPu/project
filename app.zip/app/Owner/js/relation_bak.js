var relation_bak = [{
	value: 'ywj',
	text: '隔壁老王'
}, {
	value: 'aaa',
	text: '子女'
}, {
	value: 'lj',
	text: '租客'
}, {
	value: 'ymt',
	text: '配偶'
}, {
	value: 'shq',
	text: '租客'
}, {
	value: 'shq',
	text: '联名业主'
}]