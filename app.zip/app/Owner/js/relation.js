var relation = [{
	value: 'ywj',
	text: '业主本人'
}, {
	value: 'aaa',
	text: '子女'
}, {
	value: 'lj',
	text: '租客'
}, {
	value: 'ymt',
	text: '配偶'
}, {
	value: 'shq',
	text: '租客'
}, {
	value: 'shq',
	text: '联名业主'
}]