var repairList = [{
	repairnumber:'01201604272693',
	repairaddress: '北京怡海花园1单元1号楼1层103室',
	repairtype: '个人设施=>卫生间=>水管损坏',
	time:'12:25',
	state:'处理中...',
	name: '李大妈'
}, {
	repairnumber:'01201604272693',
	repairaddress: '北京怡海花园1单元1号楼1层103室',
	repairtype: '公共设施=>路灯=>线路损坏',
	time:'13:25',
	state:'处理中...',
	name: '李大妈'
}, {
	repairnumber:'01201604272693',
	repairaddress: '北京怡海花园1单元1号楼1层103室',
	repairtype: '个人设施=>卫生间=>水管损坏',
	time:'14:25',
	state:'处理中...',
	name: '李大妈'
}, {
	repairnumber:'01201604272693',
	repairaddress: '北京怡海花园1单元1号楼1层103室',
	repairtype: '公共设施=>路灯=>线路损坏',
	time:'15:25',
	state:'处理中...',
	name: '李大妈'
}, {
	repairnumber:'01201604272693',
	repairaddress: '北京怡海花园1单元1号楼1层103室',
	repairtype: '个人设施=>卫生间=>水管损坏',
	time:'16:25',
	state:'处理中...',
	name: '李大妈'
}, {
	repairnumber:'01201604272693',
	repairaddress: '北京怡海花园1单元1号楼1层103室',
	repairtype: '个人设施=>卫生间=>水管损坏',
	time:'17:25',
	state:'处理中...',
	name: '李大妈'
}]