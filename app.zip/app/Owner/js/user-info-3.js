var user_info_3 = [{
	value: '110000',
	text: '公共区域',
	children: [{
		value: "110101",
		text: "路灯",
		children: [{
			value: "110101",
			text: "线路故障"
		}, {
			value: "110102",
			text: "西城区"
		}, {
			value: "110230",
			text: "其它区"
		}]
	}]
}, {
	value: '110000',
	text: '私人区域',
	children: [{
		value: "110101",
		text: "路灯",
		children: [{
			value: "110101",
			text: "线路故障"
		}, {
			value: "110102",
			text: "西城区"
		}, {
			value: "110230",
			text: "其它区"
		}]
	}]
}]