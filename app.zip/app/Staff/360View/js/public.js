//var http_service = "http://test-wg.cm-dev.cn"; //服务器地址
// var http_service = "http://10.16.199.64:3002"; //develop服务器地址
//var http_service1 = "http://10.16.199.64:3002"; //develop服务器地址
//var http_service2 = "http://10.16.65.146:3000"; //陈鉴本地服务器地址
//var http_service = "http://10.16.69.173:3000"; //服务器地址
//var http_service = "http://api-wg.cm-dev.cn/api/v1/"; //服务器地址
//var http_service_1 = "http://develop.cm-inv.com/api/v1/"; //服务器地址
//var http_service = "http://localhost/api/v1/" ; //服务器地址
//var image_service = ""; //图片服务地址
var image_service = "";
//var image_service="http://image.cmlejia.com/show/";

var param0 = '';
param0 = GetParam();
var http_service = '';
http_service = param0.http_service;

function GetRequest() {
	var url = location.search; //获取url中"?"符后的字串
	var theRequest = new Object();
	if(url.indexOf("?") != -1) {
		var str = url.substr(1);
		strs = str.split("&");
		for(var i = 0; i < strs.length; i++) {
			theRequest[strs[i].split("=")[0]] = (strs[i].split("=")[1]);
		}
	}
	return theRequest;
}

//截取地址内token和project_id
function GetParam() {
	var url = location.search; //获取url中"?"符后的字串
	var _url = window.location.href; //获取url
	var theParam = new Object();
	var arr = _url.split('/'); //截取域名
	theParam['http_service'] = "http://"+arr[2]; //拼接
	if(url.indexOf("?") != -1) {
		var str = url.substr(1);//截取下来从索引1开始的后边所有子字符串
		strs = str.split("&");
		for (var i = 0; i < strs.length; i++) {
			theParam[strs[i].split("=")[0]] = (strs[i].split("=")[1]);
		}
	}
	return theParam
}

function getHeaders() {
	var token = localStorage.token;
	return {
		//动态获取token值
		"authorization": token
	}
}



//请求数据后状态403时提示操作超
function closePpage(code) {

	//window.location = "ljh://finish_page";
	if(code == "403") {
		if(mui != null) {
			mui.toast("操作超时！")
		}
		setTimeout(function() {
			window.location = "ljh://finish_page";
		}, 3000);
	}
}

var getRightCb = null;
//获得othrar认证
var getRight = function(cb) {
		mui.ajax(lijiahui_service + 'common/oauth2/authorize', {
			data: {
				appid: appid,
				redirect_uri: http_service + "/Owner/userCreateRepairList.html",
				scope: "snsapi_base"
			},
			dataType: 'test', //服务器返回json格式数据
			type: 'get', //HTTP请求类型
			timeout: 10000, //超时时间设置为10秒；
			headers: {
				'Content-Type': 'application/json'
			},
			success: function(data) {
				//服务器返回响应，根据响应结果，分析是否登录成功；
				//if(data.status_code == "200"){
				//	
				//}
				var obj = null;
				try {
					obj = eval('(' + data + ')');
					//得到code 
					mui.alert("得到的CODE：" + obj.code);
					//得到授权code
					getAccessToken(obj.code);
				} catch(e) {
					mui.toast(data)
				}

			},
			error: function(xhr, type, errorThrown) {
				//异常处理；
				//console.log(type);
			}
		});

	}
//获得access_token认证
var getAccessToken = function(code) {
	mui.ajax(lijiahui_service + '/common/oauth2/access_token', {
		data: {
			appid: appid,
			code: code,
			secret: secret,
			grant_type: grant_type
		},
		dataType: 'json', //服务器返回json格式数据
		type: 'get', //HTTP请求类型
		timeout: 10000, //超时时间设置为10秒；
		headers: {
			'Content-Type': 'application/json'
		},
		success: function(data) {
			//服务器返回响应，根据响应结果，分析是否登录成功；
			if(data.status == "Y") {
				if(data.status.Result != null) {
					mui.toast(data.status.Result.access_token)
					localStorage.access_token = data.status.Result.access_token;
					localStorage.expires_in = data.status.Result.expires_in;
					localStorage.refresh_token = data.status.Result.refresh_token;
				}
			} else {

			}
		},
		error: function(xhr, type, errorThrown) {
			//异常处理；
			//console.log(type);
		}
	});

}

//调用原生的提示信息
function totast(msg) {
	var params = {
		"message": msg
	}
	var sds = urlencode(JSON.stringify(params));
	location.href = "ljh://show_toast?" + sds
}

function urlencode(str) {
	//str = (str + '').toString();   
	//return encodeURIComponent(str).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').  
	//replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+');  
	
	//编码加密
	return encodeURI(str)
}
