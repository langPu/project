var relation = [{
	value: 'ywj',
	text: '业主'
}, {
	value: 'aaa',
	text: '物业人员'
}, {
	value: 'lj',
	text: '租客'
}, {
	value: 'ymt',
	text: '公共人员'
}, {
	value: 'shq',
	text: '群众'
}]