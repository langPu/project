var fee = [{
	value: 'ywj',
	text: '人工费 -- 40元'
}, {
	value: 'aaa',
	text: '派遣费 -- 40元'
}]