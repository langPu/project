var nativeFlage = false; //源生与mui环境替换 true源生环境 false mui环境
var native_bridge = null ;
var isAndriod = true ; //操作系统Android还是是IOS 

//Android初始化操作
function connectWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) {
        callback(WebViewJavascriptBridge)
    } else {
        document.addEventListener(
            'WebViewJavascriptBridgeReady'
            , function() {
                callback(WebViewJavascriptBridge)
            },
            false
        );
    }
}

//IOS初始化操作
function setupWebViewJavascriptBridge(callback) {
	if (window.WebViewJavascriptBridge) { return callback(WebViewJavascriptBridge); }
	if (window.WVJBCallbacks) { return window.WVJBCallbacks.push(callback); }
	window.WVJBCallbacks = [callback];
	var WVJBIframe = document.createElement('iframe');
	WVJBIframe.style.display = 'none';
	WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__';
	document.documentElement.appendChild(WVJBIframe);
	setTimeout(function() { document.documentElement.removeChild(WVJBIframe) }, 0)
}

//拦截开始
if(nativeFlage){
	mui.ajax = function(url,options){
		if( url == null || url == '' ){
			showToast("请求路径不能为空。");
			return ; //如果路径是空的 不执行方法
		}
		if(options != null ){
			var data = options.data ; //参数
			var dataType = options.dataType ; //返回值类型 json text
			var type = options.type ; //HTTP请求类型 get post
			var timeout = options.timeout ; //超时时间
			var headers = options.headers ; //头文件信息
			var success = options.success ; //执行成功后的回调方法
			var error = options.error ; //发生错误的回调方法
			var activityFunName = options.activityFunName ;
			//调用源生方法 并向之传入值
			
			var obj = new Object();
			obj.url = url ;
			obj.data = data ;
			obj.type = type ;
			obj.token = headers.authorization ;
			
			//var sendToNativeParam = JSON.stringify(obj);
		    window.WebViewJavascriptBridge.callHandler(
		        activityFunName
		        , obj
		        , function(data){
		        	success(eval('('+data+')'));
		        }
		    );
		    
		    if( native_bridge == null ){
				if(isAndriod){
					connectWebViewJavascriptBridge(function(bridge) {
						native_bridge = bridge ;
						//无论怎样形式的交互，JS必须初始化JsBridge
						bridge.init(function(message, responseCallback) {
							console.log('JS got a message', message);
							var data;
							if (message) {
								data = '接收到数据:'+message;
								alert(data);
							} else { 
								data = '未接收到数据';
								alert(data);
							}
						   
							alert(responseCallback);
							if(responseCallback){
								 responseCallback(data);
							}
						});
						// 注册一个
						bridge.registerHandler(activityFunName, function(data, responseCallback) {
							responseCallback(responseData);
						});
					   
					});
				}else{
					setupWebViewJavascriptBridge(function(bridge) {
		            	bridge.callHandler(activityFunName
		                                  , {'param': sendToNativeParam }
		                                  ,success
		                )
		             })
				}
		    	
		    }else{
		    	// 注册一个
				if(isAndriod){
					native_bridge.registerHandler(activityFunName, function(data, responseCallback) {
						// response层,调用回调
						responseCallback(responseData);
					});
				}else{
					native_bridge.callHandler(activityFunName
                      	, {'param': sendToNativeParam }
                      	,success
	                )
				}
			    
		    }
		    
		}
		
		
	}
}





//下一步
function nextStep(){
	var data = "这是由demo.html传来的数据";
	window.WebViewJavascriptBridge.callHandler(
        'nextStep'
        , {'param': data }
        , function responseCallback (responseData) {
            document.getElementById("show").innerHTML = ("get responseData from java, data = " + responseData);
        }
    );
}
	
//打开文件
function onOpen() {
  　	var str1 = document.getElementById("text1").value;
    var str2 = document.getElementById("text2").value;
    var data = "name=" + str1 + ",location=" + str2;

	/*
	 * 同步回调java层注册的同名函数
	 * 第一参数：方法名
	 * 第二个:JS调用native的请求参数
	 * 第三个：JS在被回调后具体执行方法，responseData为java层回传jsonStr.
	 */
    window.WebViewJavascriptBridge.callHandler(
        'functionOpen'
        , {'param': data }
        , function(responseData) {
            document.getElementById("show").innerHTML = "send get responseData from java, data = " + responseData;
        }
    );
}

//显示源代码
function testDiv() {
    document.getElementById("show").innerHTML = document.getElementsByTagName("html")[0].innerHTML;
}


//发消息给Native
function testClick() {
    var str1 = document.getElementById("text1").value;
    var str2 = document.getElementById("text2").value;
    //发送消息给java本地代码
    var data = {id: 1, content: "这是一个图片 <img src=\"a.png\"/> test\r\nhahaha"};
    window.WebViewJavascriptBridge.send(
    	{'param': data }
        , function(responseData) {
        	if(responseData){
        		alert(responseData);
        	}
        	document.getElementById("show").innerHTML = ("repsonseData from java, data = " + responseData);
        }
    );
}


//调用Native方法
function testClick1(url,data) {
    //var str1 = document.getElementById("text1").value;
    //var str2 = document.getElementById("text2").value;
    //var data = "name=" + str1 + ",pass=" + str2;
   
    window.WebViewJavascriptBridge.callHandler(
        'submitFromWeb'
        , {'param': JSON.stringify(data) }
        , function responseCallback (responseData) {
            //document.getElementById("show").innerHTML = ("get responseData from java, data = " + responseData);
        	data.success(responseData);//这里只调用了成功的方法!失败或者超时并没有调用!
        }
    );
}
    
function showToast(data){
	//var data = "Hello JSBridge";
	window.WebViewJavascriptBridge.callHandler(
		'showToast',
		{'param':data},
		function (responseData){
			document.getElementById("show").innerHTML = ("get responseData from java, data = " + responseData);
		}
	);
}
    
//childThread
function childThread(){
	var data = "子线程";
	window.WebViewJavascriptBridge.callHandler(
		'testThread',
		{'param':data},
		function (responseData){
			document.getElementById("show").innerHTML = ("get responseData from java, data = " + responseData);
		}
			
	);
}
    
function bridgeLog(logContent) {
    document.getElementById("show").innerHTML = logContent;
}
    
    


/*
// 第一连接时初始化bridage
connectWebViewJavascriptBridge(function(bridge) {
	//无论怎样形式的交互，JS必须初始化JsBridge
    bridge.init(function(message, responseCallback) {
        console.log('JS got a message', message);
        var data;
        if (message) {
        	data = '接收到数据:'+message;
        	alert(data);
        } else { 
        	data = '未接收到数据';
        	alert(data);
        }
       
        console.log('JS responding with', data);
        if(responseCallback){
       		 responseCallback(data);
        }
    });
    
    // 注册一个"functionInJs",
    bridge.registerHandler("functionInJs", function(data, responseCallback) {

       document.getElementById("show").innerHTML = ("data from Java: = " + data);
       var str= JSON.parse(data); 
       document.getElementById("text1").value="姓名："+str.name;
       document.getElementById("text2").value="地点："+str.location;
        var responseData = "Javascript Says  我要你的地址!";
        // response层,调用回调
        responseCallback(responseData);
    });
   
});
 */