var user_info_1 = [{
	value: 'ywj',
	text: '北京怡海花园32号楼5层501室'
}, {
	value: 'aaa',
	text: '北京怡海花园32号楼5层501室'
}, {
	value: 'lj',
	text: '北京怡海花园32号楼5层501室'
}, {
	value: 'ymt',
	text: '北京怡海花园32号楼5层501室'
}, {
	value: 'shq',
	text: '北京怡海花园32号楼5层501室'
}]