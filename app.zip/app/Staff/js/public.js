
var http_service = "http://test-wg.cm-dev.cn/api/v1/" ; //服务器地址


//var http_service = "http://test-wg.cm-dev.cn/api/v1/" ; //服务器地址


//var http_service = "http://10.16.72.53:3000/api/v1/" ; //服务器地址
//var http_service = "http://10.16.73.72:3000/api/v1/" ; //服务器地址
//var http_service = "http://localhost/api/v1/" ; //服务器地址
var image_service = "http://ljhui.cm-dev.cn/ljhui-api/show/"; //图片服务地址


function GetRequest() {
  
  var url = location.search; //获取url中"?"符后的字串
   var theRequest = new Object();
   if (url.indexOf("?") != -1) {
      var str = url.substr(1);
      strs = str.split("&");
      for(var i = 0; i < strs.length; i ++) {
         theRequest[strs[i].split("=")[0]]=(strs[i].split("=")[1]);
      }
   }
   return theRequest;
}

function closePpage(code){
	//window.location = "ljh://finish_page";
	if(code == "403"){
		//alert("token："+localStorage.token);
		if(mui != null ){
			mui.toast("操作超时！")
		}
		setTimeout(function(){
			window.location = "ljh://finish_page";
		},3000);
	}
}

//appcan 打开窗口编号
var appcanPageName = "outsideModel" ;

////授权服务
//var lijiahui_service = "http://ljhui.cm-dev.cn/ljhui-api/";
//var lijiahui_service = "http://localhost/ljhui-api/";
////授权码
//var appid = "146c74602a3c422b8e5aaf41d5eb73db" ;
//var secret = "f0ff6faaa34a4893b583b0568f61ca35" ;
//var grant_type = "authorization_code";

function getHeaders(){
	var token = localStorage.token ;
	//reurn {"Authorization":token} ;
	return {

		//"authorization":"eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0.eyJicF9pZCI6IjAwNVkwMDBUMG5OUVc2NHNSTkIzSGsifQ." 

		//"authorization":"eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0.eyJicF9pZCI6IjAwNVkwMDBBMHNNQzA3MFBOZFBpcm8ifQ." 

		
		
		"authorization":token
	}
}

function incidentStatus(incident_status){
	incident_status = incident_status.toUpperCase();
	var pairStatus = null ;
	if( incident_status == "NEW" ) {
		pairStatus = "新建"
	}else if( incident_status == "NEW_ASSIGN" ) {
		pairStatus = "已派工"
	}else if( incident_status == "WAIT_REPAIR" ) {
		pairStatus = "待维修"
	}else if( incident_status == "PENDING" ) {
		pairStatus = "处理中"
	}else if( incident_status == "DONE" ) {
		pairStatus = "维修完成"
	}else if( incident_status == "DONE_EX" ) {
		pairStatus = "确认完成"
	}else if( incident_status == "WAIT_ASSIGN" ) {
		pairStatus = "待分派"
	}else if( incident_status == "CANCEL" ) {
		pairStatus = "已取消"
	}
	return pairStatus ;
}

var getRightCb = null ;
//获得othrar认证
var getRight = function(cb){
	mui.ajax(lijiahui_service+'common/oauth2/authorize',{
		data:{
			appid:appid,
			redirect_uri:http_service+"/Owner/userCreateRepairList.html",
			scope:"snsapi_base"
		},
		dataType:'test',//服务器返回json格式数据
		type:'get',//HTTP请求类型
		timeout:10000,//超时时间设置为10秒；
		headers:{'Content-Type':'application/json'},
		success:function(data){
			//服务器返回响应，根据响应结果，分析是否登录成功；
			//if(data.status_code == "200"){
			//	
			//}
			var obj = null ;
			try{
				obj = eval('('+data+')');
				//得到code 
				mui.alert("得到的CODE："+obj.code);
				//得到授权code
				getAccessToken(obj.code);
			}catch(e){
				mui.toast(data)
			}
			
		},
		error:function(xhr,type,errorThrown){
			//异常处理；
			console.log(type);
		}
	});
	
}
//获得access_token认证
var getAccessToken = function(code){
	mui.ajax(lijiahui_service+'/common/oauth2/access_token',{
		data:{
			appid:appid,
			code:code,
			secret:secret,
			grant_type:grant_type
		},
		dataType:'json',//服务器返回json格式数据
		type:'get',//HTTP请求类型
		timeout:10000,//超时时间设置为10秒；
		headers:{'Content-Type':'application/json'},
		success:function(data){
			//服务器返回响应，根据响应结果，分析是否登录成功；
			if(data.status == "Y"){
				if(data.status.Result != null ){
					mui.toast(data.status.Result.access_token )
				    localStorage.access_token = data.status.Result.access_token ;
					localStorage.expires_in = data.status.Result.expires_in;
					localStorage.refresh_token = data.status.Result.refresh_token;
				}
			}else{
				
			}
		},
		error:function(xhr,type,errorThrown){
			//异常处理；
			console.log(type);
		}
	});
	
}


function totast(msg){
		var params = {"message":msg}
		var sds = urlencode(JSON.stringify(params));
		location.href = "ljh://show_toast?"+sds
}


function urlencode (str) {  
    str = (str + '').toString();   

    return encodeURIComponent(str).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').  
    replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+');  
} 
