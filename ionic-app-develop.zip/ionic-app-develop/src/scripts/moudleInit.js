/**
 * Created by gusenlin on 16/5/22.
 */
(function () {
  'use strict';
  angular.module('utilModule', []);
  angular.module('hmsModule', []);//汉得公用模块库
  angular.module('loginModule', []);
  angular.module('messageModule', []);
  angular.module('contactModule', []);
  angular.module('applicationModule', []);
  angular.module('myInfoModule', []);
  angular.module('utilsModule', []);
})();
