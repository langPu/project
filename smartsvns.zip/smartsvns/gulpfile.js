var gulp = require('gulp');
// Include Plugins
var del = require('del'),
    gutil = require('gulp-util'),
    jshint = require('gulp-jshint'),
    useref = require('gulp-useref'),
    lazypipe = require('lazypipe'),
    sass = require('gulp-sass'),
    concat = require('gulp-concat'),
    uglify = require('gulp-uglify'),
    rename = require('gulp-rename'),
    runSequence = require('gulp-sequence'),
    sourcemaps = require('gulp-sourcemaps'),
    clean = require('gulp-clean'),
    notify = require('gulp-notify'),//提示信息
    minifyCSS = require('gulp-minify-css');

var jsFilePath = ['app/scripts/*.js', 'app/pages/**/*.js', 'app/pages/**/**/*.js', 'app/pages/**/**/**/*.js'];
var imagePath = ['app/img/*', 'app/img/*/*'];
var cssFilePath = ['app/css/**/*.css'];
// var cssFilePath2 = ['app/css/official/index.css'];
var lipPath = ["app/lib/*/*", "app/lib/*/*/*", "app/lib/*/*/*/*", "app/lib/*/*/*/*/*"];
var htmlFilePath = ['app/pages/**/*.html', 'app/pages/**/**/*.html', 'app/pages/**/**/**/*.html'];
var fontFilePath = ['app/fonts/*', 'app/fonts/*/*'];
var apiFilePath = ['app/config/*'];
//清理代码
var compile = gutil.env.compile;
gulp.task('clean', function () {
    return gulp.src(['www/*/*', '!www/build/lib', "!www/build/index.html"], {read: false})
        .pipe(clean({force: true}));
});
//js集成 和 丑化
gulp.task('scripts', function () {
    return gulp.src(jsFilePath)
        //.pipe(sourcemaps.init())
        .pipe(concat('app.bundle.js'))
        .pipe(gulp.dest('www/build'))  // write source file for debug
        .pipe(uglify({mangle: true}))  // for debug, do not mangle variable name
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(sourcemaps.write('.', {includeContent: false, sourceRoot: '.'}))
        .pipe(gulp.dest('www/build'));

});

//转移图片
gulp.task('copy-img-all', function () {
    return gulp.src(imagePath)
        .pipe(gulp.dest('www/build/img'))
});

//编译SCSS
// Compile Sass
gulp.task('copy-css-lib', function () {
    return gulp.src(cssFilePath)
        // .pipe(concat('bundle.css'))
        // .pipe(gulp.dest('www/build/css'))
        .pipe(minifyCSS())
        // .pipe(rename({suffix: '.min'}))   //rename压缩后的文件名
        .pipe(gulp.dest('www/build/css'))
});

gulp.task('copy-css-lib2',function () {

    return gulp.src(cssFilePath2)
        .pipe(gulp.dest('www/build/css/official'))

});
//copy jslib
gulp.task('copy-js-lib', function () {
    return gulp.src(lipPath)
        .pipe(gulp.dest('www/build/lib'));
});
//copy font

gulp.task('copy-font-lib', function () {
    return gulp.src(fontFilePath)
        .pipe(gulp.dest('www/build/fonts'));
});

//copy api apiFilePath
gulp.task('copy-api-lib', function () {
    return gulp.src(apiFilePath)
        .pipe(gulp.dest('www/build/config'));
});
//copy html
// Handle HTML
gulp.task('copy-html-lib', function () {
    return gulp.src(htmlFilePath)
        .pipe(useref({noAssets: true}, lazypipe().pipe(sourcemaps.init, {loadMaps: true})))
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('www/build/pages'))
});
gulp.task('dev', function (callback) {
    runSequence('clean', ['scripts', 'copy-img-all', 'copy-css-lib', 'copy-js-lib', 'copy-html-lib', 'copy-font-lib', 'copy-api-lib'], callback);

});