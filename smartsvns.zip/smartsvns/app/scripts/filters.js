/**
 * Created by admin on
 */

//详情改变
chuanyang.filter('changeUrl', function () {
    return function (input) {
        if (input === "/orderList") {
            return "订单详情";
        } else if (input === "/allocationOrder") {
            return "分配订单";
        } else if (input === "/twiceAllocation") {
            return "二次分配";
        } else if (input === "/ceshi") {
            return "测试分配";
        } else if (input === "/allocationOrderEnd") {
            return "已分配计划单";
        }else if (input === "/allCar") {
            return "所有车辆";
        }else if (input === "/motorcade") {
            return "车队";
        }else if (input === "/company") {
            return "物流公司";
        }else if (input === "/createMotorcade") {
            return "创建车队";
        }else if (input==="/createShipFleet"){
            return "创建船队";
        }else if (input === "/vessel") {
            return "所有船只";
        }else if (input === "/fleet") {
            return "船队";
        }
    };
});

//时间的转换
chuanyang.filter('dateFilter', function () {
    return function (input) {
        if(!input)return '无';
        var s, d;
        d = new Date(input * 1000);
        s = d.getFullYear() + "年";
        s += ("0" + (d.getMonth() + 1)).slice(-2) + "月";
        s += ("0" + d.getDate()).slice(-2) + "日" + " ";
        s += ("0" + d.getHours()).slice(-2) + ":";
        s += ("0" + d.getMinutes()).slice(-2) + ":";
        s += ("0" + d.getSeconds()).slice(-2);
        //s += ("00" + d.getMilliseconds()).slice(-3);
        return s;
    };
});

//订单类型的转换【1：竞价】 【2:抢单】 【3:指定运输】
chuanyang.filter('orderType', function () {
    return function (input) {
        if (input === 1) {
            return "竞价订单";
        } else if (input === 2) {
            return "匹配订单";
        } else if (input === 3) {
            return "专线推送";
        }
    };
});

//运输方式的转换 【1:汽运】【2:船运】【3:车船车】【4：车船】【5:船车】【6:其他】
chuanyang.filter('transPortType', function () {
    return function (input) {
        if (input === 1) {
            return "汽运";
        } else if (input === 2) {
            return "船运";
        } else if (input === 3) {
            return "车船车";
        } else if (input === 4) {
            return "车船";
        } else if (input === 5) {
            return "船车";
        } else if (input === 6) {
            return "其他";
        } else if (input === 7) {
            return "";
        }
    };
});

chuanyang.filter('phoneTransform',['$localStorage', function ($localStorage) {
    return function (input) {
        if(!input) return input;
        if($localStorage.chuanYangloginMessege) return input;
       var phone = input.substring(0,4)+'***'+input.substring(8);
       return phone;
    };
}]);

//头像

chuanyang.filter('userImg',function(){
    return function(input){
        if(!input) return;

        var index=input.indexOf('?');
        if(index!='-1'){
            return input.substring(0,index)+'?x-oss-process=image/resize,m_fixed,h_30,w_30';
        }else{
            return input +'?x-oss-process=image/resize,m_fixed,h_30,w_30';
        }

    }
})
//竞价时间的转换
chuanyang.filter('dayFilter', function () {
    return function (input) {
        if(!input) return;
        var d=Math.floor(input/(3600000*24));
        return d>9 ? d:'0'+d;
    };
});
chuanyang.filter('hourFilter', function () {
    return function (input) {
        if(!input) return;
        var d=Math.floor(input/(3600000*24));
        var h=Math.floor((input-d*3600000*24)/3600000);
        return h>9 ? h:'0'+h;
    };
});
