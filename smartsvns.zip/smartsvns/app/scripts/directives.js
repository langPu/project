/**
 * Created by admin on
 */

chuanyang.directive('myWeight', ['$filter', function ($filter) {
    return {
        restrict: 'AE',
        template: "<input type='text' ng-model='planList.selectWeight' style='width: 100%;text-align: center'" +
        "ng-change='selectWeight(planList)' />",
        link: function (scope, el, attr) {
            scope.selectWeight = function (planList) {
                console.log(scope.planList.selectWeight);
                console.log(planList.surplusWeight);
                if (!isNaN(scope.planList.selectWeight)) {
                    if (parseFloat(scope.planList.selectWeight) < 0) {
                        scope.planList.selectWeight = 0;
                    } else if (parseFloat(scope.planList.selectWeight) > parseFloat(planList.surplusWeight)) {
                        scope.planList.selectWeight = 0;
                    } else {

                    }
                } else {
                    alert("请输入数字！");
                    scope.planList.selectNumber = 0;
                }
            };
        }
    };
}]);

chuanyang.directive('myNumber', ['$filter', function ($filter) {
    return {
        restrict: 'AE',
        template: "<input type='text' ng-model='planList.selectNumber' style='width: 100%;text-align: center'" +
        "ng-change='selectNumber(planList)' />",
        link: function (scope, el, attr) {
            scope.selectNumber = function (planList) {
                if (!isNaN(scope.planList.selectNumber)) {
                    if (parseFloat(scope.planList.selectNumber) < 0) {
                        scope.planList.selectNumber = 0;
                    } else if (parseFloat(scope.planList.selectNumber) > (parseFloat(planList.surplusNum))) {
                        scope.planList.selectNumber = 0;
                    }
                } else {
                    alert("请输入数字！");
                    scope.planList.selectNumber = 0;
                }

            };
        }
    };
}]);
