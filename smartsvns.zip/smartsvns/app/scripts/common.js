/**
 * Created by fangqiang on 16/8/23.
 */
var forMessage = function (text) {
    if (text === "open") {
        $('.alert-cover').fadeIn();
    } else if (text === "close") {
        $('.alert-cover').fadeOut();
    }
};

var ROOTCONFIG;
var UTILITIES = new Object();
(function (object) {
    object.init = function () {
        var loadConfigRequest = new XMLHttpRequest();
        loadConfigRequest.open('GET', 'config/configDev.json', false);
        loadConfigRequest.send(null);
        if (loadConfigRequest.status === 200 || loadConfigRequest.status === 0) {
            ROOTCONFIG = JSON.parse(loadConfigRequest.responseText);
        }
    };
    object.message = function () {
        var toaster = [{
            type: 'success',
            title: '提示',
            text: '成功'
        },
            {
                type: 'wait',
                title: '提示',
                text: '正在加载,请耐心等待'
            },
            {
                type: 'warning',
                title: '提示',
                text: '请将数据填写完整'
            }
            , {
                type: 'error',
                title: '提示',
                text: '提交失败'
            }];
        return toaster
    };


})(UTILITIES);

UTILITIES.init();