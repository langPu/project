/**
 * ==============================公用方法==============================
 */
//日期转换
Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
};

//object TO String
function objToString(obj) {
    var str = '';
    for (var p in obj) {
        if (obj.hasOwnProperty(p)) {
            str += p + ':' + obj[p] + '\n';
        }
    }
    return str;
}

//判断数组中是否含有某个元素
function inArray(array, obj) {
    for (var i = 0; i < array.length; i++) {
        if (array[i] === obj)
            return true;
    }
    return false;
}

//判断输入是否为十一位电话号码
function phoneNumber(str) {
    console.log("phoneNumber:" + str);
    var reg = /^([0-9]|[-])+$/g;
    if (str.length !== 11) {
        if (str.length === 12) {
            if (str.charAt(0) === '0') {
                return true;
            }
        }
        return false;
    }
    else {
        return reg.exec(str);
    }
}

//邮件格式
function isEmailAddress(obj) {
    var pattern = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
    flag = pattern.test(obj);
    return flag;
}

//获得UUID
function guUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

//工具类，判断当前字符串是否为空
function isEmpty(v) {
    switch (typeof v) {
        case 'date':
            return true;
        case 'undefined' :
            return true;
        case 'string' :
            if (v.trim().length === 0)
                return true;
            break;
        case 'boolean' :
            if (!v)
                return true;
            break;
        case 'number' :
            if (0 === v)
                return true;
            break;
        case 'object' :
            if (null === v) {
                return true;
            }
            else if (undefined !== v.length && v.length === 0) {
                return true;
            }
            else {
                return false;
            }
            break;
    }
    return false;
}