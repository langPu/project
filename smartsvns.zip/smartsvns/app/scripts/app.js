'use strict';

var chuanyang = angular.module('chuanyang', [
    'ui.router',
    'ui.bootstrap',
    'bw.paging',
    'ngStorage',
    'toaster',
    'ui.select',
    'angularFileUpload',
    'ngCookies'
]);
chuanyang.run(
    ['$rootScope', '$state', '$stateParams', '$localStorage',
        function ($rootScope, $state, $stateParams, $localStorage) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
        }
    ]
).config(['$urlRouterProvider', '$stateProvider',
    function ($urlRouterProvider, $stateProvider) {
        $urlRouterProvider
            .otherwise('/index/index');
        $stateProvider
            .state('index', {
                abstract: true,
                catch: false,
                url: '/index',
                templateUrl: 'pages/index/index.html'
            })
            //首页
            .state('index.index', {
                url: '/index',
                templateUrl: 'pages/official/index.html',
                controller: 'loginCtrl'
            })
            //寻找车源
            .state('index.carSearch', {
                url: '/carSearch',
                templateUrl: 'pages/index/transportInfo/carSearch.html'
            })
            //登录
            .state('index.login', {
                url: '/login',
                templateUrl: 'pages/index/login/login.html'
            })
            .state('index.carSearch.personcar', {
                url: '/carSearch',
                templateUrl: 'pages/index/transportInfo/personcar.html'
            })
            .state('index.carSearch.fleetcar', {
                url: '/carSearch',
                templateUrl: 'pages/index/transportInfo/fleetcar.html'
            })
            .state('index.carSearch.personship', {
                url: '/carSearch',
                templateUrl: 'pages/index/transportInfo/personship.html'
            })
            .state('index.carSearch.fleetship', {
                url: '/carSearch',
                templateUrl: 'pages/index/transportInfo/fleetship.html'
            })
            .state('index.about', {
                url: '/about',
                templateUrl: 'pages/about/about.html',
                controller: 'aboutController'
            })
            .state('index.about.aboutUs', {
                url: '/aboutUs',
                templateUrl: 'pages/about/aboutUs.html'
            })
            .state('index.about.recruit', {
                url: '/recruit',
                templateUrl: 'pages/about/recruit.html'
            })
            .state('index.about.contact', {
                url: '/contact',
                templateUrl: 'pages/about/contact.html'
            })
            //查询yun 单platformOrder
            .state('index.wayBillSearch', {
                url: '/wayBillSearch',
                templateUrl: 'pages/index/wayBillSearch/wayBillSearch.html'
            })
            .state('index.wayBillSearch.orderInfo', {
                url: '/wayBillSearch',
                params: {orderMessage: null},
                templateUrl: 'pages/index/wayBillSearch/orderInfo.html'
            })
            .state('index.wayBillSearch.wayBillInfo', {
                url: '/wayBillSearch',
                params: {orderMessage: null},
                templateUrl: 'pages/index/wayBillSearch/wayBilInfo.html'
            })
            //寻找货源
            .state('index.goodsSearch', {
                url: '/goodsSearch',
                templateUrl: 'pages/index/goods/goodsSearch.html'
            })
            //招聘
            .state('index.news', {
                url: '/news',
                templateUrl: 'pages/index/news/news.html'
            })
            //帮助手册
            .state('index.help', {
                url: '/help',
                templateUrl: 'pages/index/help/help.html'
            })
            .state('index.newMember', {
                url: '/newMember',
                templateUrl: 'pages/index/help/newMember.html'
            })
            .state('index.newMember.gettingStart', {
                url: '/gettingStart',
                templateUrl: 'pages/index/help/newMmber/gettingStart.html'
            })
            .state('index.newMember.troubleshooting', {
                url: '/troubleshooting',
                templateUrl: 'pages/index/help/newMmber/troubleshooting.html'
            })
            .state('home', {
                abstract: true,
                url: '/home',
                templateUrl: 'pages/home/home.html'
            })
            .state('/login', {
                url: "/login",
                templateUrl: "pages/login/login.html",
                controller: 'loginCtrl'
            })
            //注册
            .state('/userRegister', {
                url: "/userRegister",
                templateUrl: "pages/userRegister/userRegister.html",
                controller: 'userRegisterCtrl'
            })
            .state('/goods', {
                url: "/goods",
                templateUrl: "pages/official/goodsInformation.html"
            })
            .state('home.welcome', {
                url: "/welcome",
                templateUrl: "pages/test/welcome.html",
                controller: 'welcomeCtrl'
            })
            //订单列表
            .state('home.orderList', {
                url: "/orderList",
                templateUrl: "pages/order/orderList.html",
                controller: 'orderListController'
            })
            //未支付订单
            .state('home.unpayOrderList', {
                url: "/unpayOrderList",
                templateUrl: "pages/order/unpayOrder/unpayOrderList.html",
                controller: 'unpayOrderListCtrl'
            })
            //分配订单
            .state('home.allocationOrder', {
                url: "/allocationOrder",
                templateUrl: "pages/order/allocationOrder.html",
                controller: 'allocationOrderController'
            })
            .state('home.allocationOrderEnd', {
                url: "/allocationOrderEnd",
                templateUrl: "pages/order/allocationOrderEnd.html",
                controller: 'allocationOrderEndController'
            })

            .state('home.platformOrder', {
                url: "/platformOrder",
                templateUrl: "pages/order/platformOrders.html",
                params: {orderTrainMessage: null,planId : null,infoSelect : null},
                controller: 'platformOrderController'
            })
            //$locationProvider.html5Mode(true);
            .state('home.shipperInfo', {
                url: "/shipperInfo",
                templateUrl: "pages/shipper/shipperInfo/shipperInfo.html",
                controller: 'shipperInfoCtrl'
            })
            .state('home.shipperList', {
                url: "/shipperList",
                templateUrl: "pages/shipper/shipperList/shipperList.html",
                controller: 'shipperListCtrl'
            })
            .state('home.orderBoard', {
                url: "/orderBoard",
                templateUrl: "pages/shipper/orderBoard/orderBoard.html",
                controller: 'orderBoardCtrl'
            })
            .state('home.orderPay', {
                url: "/orderPay",
                templateUrl: "pages/shipper/orderPay/orderPay.html",
                controller: 'orderPayCtrl'
            })
            .state('home.wizardList', {
                url: "/wizardList",
                templateUrl: "pages/wizard/wizardList.html",
                controller: 'wizardListCtrl'
            })
            .state('home.motorcadeList', {
                url: "/motorcadeList",
                templateUrl: "pages/motorcadeList/motorcadeList.html",
                controller: 'motorcadeListController'
            })
            .state('home.motorcadeList.allCar', {
                url: "/allCar",
                templateUrl: "pages/motorcadeList/manageAllCar/manageAllCar.html"
            })
            .state('home.motorcadeList.motorcade', {
                url: "/motorcade",
                templateUrl: "pages/motorcadeList/manageMotocade/manageMotocade.html"
                // controller: 'motorcadeListController'
            })
            .state('home.motorcadeList.vessel', {
                url: "/vessel",
                templateUrl: "pages/motorcadeList/manageVessel/manageVessel.html"
                // controller: 'motorcadeListController'
            })

            .state('home.motorcadeList.fleet', {
                url: "/fleet",
                templateUrl: "pages/motorcadeList/manageFleet/manageFleet.html"
                // controller: 'motorcadeListController'
            })

            .state('home.motorcadeList.company', {
                url: "/company",
                templateUrl: "pages/motorcadeList/manageCompany/manageCompany.html"
                // controller: 'motorcadeListController'
            })
            .state('home.createMotorcade', {
                url: "/createMotorcade",
                templateUrl: "pages/motorcadeList/createMotorcade.html"
            })

            .state('home.createMotorcade.createMotorcade', {
                url: "/createMotorcade",
                templateUrl: "pages/motorcadeList/createMotorcade/createMotorcadeList.html"
            })
            .state('home.createMotorcade.createShipFleet', {
                url: "/createShipFleet",
                templateUrl: "pages/motorcadeList/createMotorcade/createShipFleet.html"
            })
            .state('home.unpayOrder', {
                url: "/unpayOrder",
                templateUrl: "pages/shipper/shipperUnpayOrder/shipperUnpayOrder.html",
                controller: 'unpayOrderCtrl'
            })
            .state('home.payPassword', {
                url: "/setPayPassword",
                templateUrl: "pages/shipper/payPassword/payPassword.html",
                controller: 'payPswCtrl'
            })
            .state('home.confirmPayment', {
                url: "/confirmPayment",
                templateUrl: "pages/shipper/confirmPayment/confirmPayment.html",
              //  params:{subOrderInfo:null,currencyInfo:null},
                controller:'confirmPaymentCtrl'
            })
            //招标管理
            .state('home.bidManage', {
                url: "/bidManage",
                templateUrl: "pages/shipper/bidManage/bidManage.html",
                controller: 'bidManageCtrl'
            })

            //预招标单
            .state('home.preTender', {
                url: "/preTender",
                templateUrl: "pages/shipper/preTender/Pretender.html"
            })

            //订阅管理
            .state('home.subscriptionManagement', {
                url: "/subscriptionManagement",
                templateUrl: "pages/subscriptionManagement/subscriptionManagement.html"
            })
        //常用地址维护
            .state('home.addressManage', {
                url: "/addressManage",
                templateUrl: "pages/addressManage/addressManage.html"
            })
            .state('home.tenderList', {
                url: "/tenderList",
                templateUrl: "pages/shipper/tenderList/tenderList.html"
            })
            .state('home.internetBank', {
                url: "/internetBank",
                templateUrl: "pages/shipper/internetBank/internetBank.html",
                controller: 'internetBankCtrl'
            })


    }]);


chuanyang.controller('appCtrl', ['$scope', '$state', '$modal', '$localStorage', '$rootScope',
    function ($scope, $state, $modal, $localStorage, $rootScope) {
        $scope.rootConfig = {
            orderNum: 0,
            orderDetail: []
        };


        console.log(angular.toJson($localStorage.chuanYangloginMessege, true));
        $rootScope.userSettings = {};
        if ($localStorage.chuanYangloginMessege == undefined) {
            $rootScope.userSettings.user = false;

        } else {
            $rootScope.userSettings.user = $localStorage.chuanYangloginMessege;
        }
        $rootScope.userSettings.black = function () {
            $rootScope.userSettings.user = false;
            $localStorage.chuanYangloginMessege = undefined;

        };
        $rootScope.userSettings.goin = function () {
            if ($rootScope.userSettings.user.userType == 1) {
                $state.go('home.shipperList');
            } else if ($rootScope.userSettings.user.userType == 2) {
                $state.go('home.welcome');
            } else if ($rootScope.userSettings.user.userType == 3) {
                $state.go('home.allocationOrder');
            }

        };
        $rootScope.userSettings.rest = function () {
            $rootScope.userSettings.user = false;
            $localStorage.chuanYangloginMessege = undefined;
            $state.go('index.login');
        };
        $scope.goList = function(flag){
            $rootScope.shadow_pay = false;
            if(flag==1){
                if($localStorage.chuanYangloginMessege.userType==1){
                    $state.go('home.shipperList');
                }else if($localStorage.chuanYangloginMessege.userType==3){
                    $state.go('home.orderList');
                }
            }else{
                $state.go('home.orderPay');
            }

        }

    }]);

chuanyang.controller('navCtrl', ['$rootScope', '$scope', '$localStorage', '$state', 'toaster', function ($rootScope, $scope, $localStorage, $state, toaster) {
    $scope.roleType = {};
    console.log($localStorage.chuanYangloginMessege);
    $scope.roleType.selected = $localStorage.chuanYangloginMessege.selected;
    $scope.roleType.username = $localStorage.chuanYangloginMessege.username;
    $scope.shipperRight = function () {
        if($localStorage.chuanYangloginMessege.userType!=1){
            $scope.userSettings.user.username = $localStorage.chuanYangloginMessege.username;
            $state.go('index.login');
            return;
        };
        if ($localStorage.chuanYangloginMessege.auditing != 1) {
            toaster.error('提示', '你还处于未审核状态，不能下单，可联系后台人员进行审核。', 5000);
        } else {
            $state.go('home.platformOrder');
        }
    };

}]);


angular.module("ngLocale", [], ["$provide", function ($provide) {
    var PLURAL_CATEGORY = {ZERO: "zero", ONE: "one", TWO: "two", FEW: "few", MANY: "many", OTHER: "other"};
    $provide.value("$locale", {
        "DATETIME_FORMATS": {
            "AMPMS": [
                "\u4e0a\u5348",
                "\u4e0b\u5348"
            ],
            "DAY": [
                "\u661f\u671f\u65e5",
                "\u661f\u671f\u4e00",
                "\u661f\u671f\u4e8c",
                "\u661f\u671f\u4e09",
                "\u661f\u671f\u56db",
                "\u661f\u671f\u4e94",
                "\u661f\u671f\u516d"
            ],
            "MONTH": [
                "01",
                "02",
                "03",
                "04",
                "05",
                "06",
                "07",
                "08",
                "09",
                "10",
                "11",
                "12"
            ],
            "SHORTDAY": [
                "\u5468\u65e5",
                "\u5468\u4e00",
                "\u5468\u4e8c",
                "\u5468\u4e09",
                "\u5468\u56db",
                "\u5468\u4e94",
                "\u5468\u516d"
            ],
            "SHORTMONTH": [
                "1\u6708",
                "2\u6708",
                "3\u6708",
                "4\u6708",
                "5\u6708",
                "6\u6708",
                "7\u6708",
                "8\u6708",
                "9\u6708",
                "10\u6708",
                "11\u6708",
                "12\u6708"
            ],
            "fullDate": "y\u5e74M\u6708d\u65e5EEEE",
            "longDate": "y\u5e74M\u6708d\u65e5",
            "medium": "yyyy-M-d ah:mm:ss",
            "mediumDate": "yyyy-M-d",
            "mediumTime": "ah:mm:ss",
            "short": "yy-M-d ah:mm",
            "shortDate": "yy-M-d",
            "shortTime": "ah:mm"
        },
        "NUMBER_FORMATS": {
            "CURRENCY_SYM": "\u00a5",
            "DECIMAL_SEP": ".",
            "GROUP_SEP": ",",
            "PATTERNS": [
                {
                    "gSize": 3,
                    "lgSize": 3,
                    "macFrac": 0,
                    "maxFrac": 3,
                    "minFrac": 0,
                    "minInt": 1,
                    "negPre": "-",
                    "negSuf": "",
                    "posPre": "",
                    "posSuf": ""
                },
                {
                    "gSize": 3,
                    "lgSize": 3,
                    "macFrac": 0,
                    "maxFrac": 2,
                    "minFrac": 2,
                    "minInt": 1,
                    "negPre": "(\u00a4",
                    "negSuf": ")",
                    "posPre": "\u00a4",
                    "posSuf": ""
                }
            ]
        },
        "id": "zh-cn",
        "pluralCat": function (n) {
            return PLURAL_CATEGORY.OTHER;
        }
    });
}]);

