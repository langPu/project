chuanyang.factory('urls', ['$http', '$rootScope', function ($http, $rootScope) {
    return {
        sendRequest: function (method, data, url, headers) {
            return $http({
                method: method,
                transformRequest: angular.identity,
                data: data,
                url: url,
                headers: headers
            })
        }
    }
}]);

chuanyang.factory('transportationList', function () {
    var transportationList = {};
    transportationList.data = [

        {
            "id":"1",
            "noticeNo": 'E100245812126',
            "planUser": '李四',
            "startTime": '2016-10-12',
            "endTime": '2016-10-22',
            "weigh": '10',
            "num": '34',
            "startPoint": "上海",
            "endPoint": "苏州",
            "mark" : "简短说明",
            "selected" : false
        },
        {
            "id":"2",
            "noticeNo": 'E100241212536',
            "planUser": '李四',
            "startTime": '2016-10-09',
            "endTime": '2016-10-22',
            "weigh": '10',
            "num": '33',
            "startPoint": "青岛",
            "endPoint": "苏州",
            "mark" : "简短说明",
            "selected" : false
        },
        {
            "id":"3",
            "noticeNo": 'E100512123786',
            "planUser": '张三',
            "startTime": '2016-10-01',
            "endTime": '2016-10-18',
            "weigh": '312',
            "num": '11',
            "startPoint": "杭州",
            "endPoint": "苏州",
            "mark" : "简短说明",
            "selected" : false
        },
        {
            "id":"4",
            "noticeNo": 'E1245121213789',
            "planUser": '王五',
            "startTime": '2016-09-22',
            "endTime": '2016-12-12',
            "weigh": '10',
            "num": '55',
            "startPoint": "北京",
            "endPoint": "苏州",
            "mark" : "简短说明",
            "selected" : false
        }

    ];
    return transportationList;
});

chuanyang.factory('transportationChildList', function () {
    var transportationChildList = {};
    transportationChildList.data = [

        {
            "materialNo":"1",
            "relateId" : 1,
            "commodityName": 'b1002452386',
            "standard": '25',
            "num": '12',
            "weight": '22',
            "weightUnit": '捆',
            "goodsNum": '341233',
            "fromCompanyName": "11",
            "toCompanyName": "11",
            "name":"大黄蜂",
            "selected" : false
        },
        {
            "materialNo":"2",
            "relateId" : 2,
            "commodityName": 'b10021114586',
            "standard": '25',
            "num": '12',
            "weight": '22',
            "weightUnit": '捆',
            "goodsNum": '341233',
            "fromCompanyName": "11",
            "toCompanyName": "11",
            "name":"大黄蜂",
            "selected" : false
        },
        {
            "materialNo":"112",
            "commodityName": 'b10333024586',
            "standard": '25',
            "num": '12',
            "weight": '22',
            "weightUnit": '捆',
            "goodsNum": '341233',
            "fromCompanyName": "11",
            "toCompanyName": "11",
            "name":"大黄蜂",
            "selected" : false
        },
        {
            "materialNo":"1331",
            "commodityName": 'b100244444586',
            "standard": '25',
            "num": '12',
            "weight": '22',
            "weightUnit": '捆',
            "goodsNum": '341233',
            "fromCompanyName": "11",
            "toCompanyName": "11",
            "name":"大黄蜂",
            "selected" : false
        }

    ];
    return transportationChildList;
});


chuanyang.factory('orderList', function () {
    var orderList = {};
    orderList.data = [

        {
            "orderNo": 'E10024586',
            "order_Person": '李四',
            "order_startime": '2016-10-12',
            "order_endtime": '2016-10-22',
            "weigh": '10',
            "num": '34',
            "startPoint": "上海",
            "endPoint": "苏州"
        },
        {
            "orderNo": 'E10024536',
            "order_Person": '李四',
            "order_startime": '2016-10-09',
            "order_endtime": '2016-10-22',
            "weigh": '10',
            "num": '33',
            "startPoint": "青岛",
            "endPoint": "苏州"
        },
        {
            "orderNo": 'E10053786',
            "order_Person": '张三',
            "order_startime": '2016-10-01',
            "order_endtime": '2016-10-18',
            "weigh": '312',
            "num": '11',
            "startPoint": "杭州",
            "endPoint": "苏州"
        },
        {
            "orderNo": 'E12453789',
            "order_Person": '王五',
            "order_startime": '2016-09-22',
            "order_endtime": '2016-12-12',
            "weigh": '10',
            "num": '55',
            "startPoint": "北京",
            "endPoint": "苏州"
        }
    ];
    return orderList;
});
