/**
 * Created by W on 2017/3/7.
 */
angular.module('chuanyang')
    .directive('tips',function () {
        return {
            restrict: 'AE',
            scope:false,
            template: "<div class='tipBoxShadow' ng-hide='hideTips'> " +
                        "<div class='tipBox'>" +
                       "<div class='clearfix' style='border-bottom:1px #ddd dashed;padding-bottom:10px;'><span class='font-bold pull-left m-l m-t'>友情提示</span><a href='javascript:;' ng-click='colseAlert()' class='glyphicon glyphicon-remove pull-right m-r m-t'></a></div>" +
                       "<div><p class='text-center m-t-lg text-2x'>你的信用额度为&nbsp;<i style='font-style:normal' class='text-danger font-bold' ng-bind='remainOverdraft'></i></p></div>"+
                        "<div><p class='text-center m-t-md'><span ng-bind='timeReduce'></span>&nbsp;秒后自动关闭</p></div>"+
                        "</div></div>",
            replace: true,
            controller: function($scope,$rootScope) {
                $rootScope.hideTips = true;
                $rootScope.remainOverdraft = 0;
                $rootScope.timeReduce = 10;
                $scope.colseAlert =function(){
                    $rootScope.hideTips = true;
                }
            }
        };
    });