/**
 * Created by admin on 2016/9/21.
 */
angular.module('chuanyang')
    .directive('startTime', ['$location', 'toaster', '$filter', function ($location, toaster, $filter) {
        return {
            restrict: 'AE',
            scope: false,
            template: "<input type='date' class='input-sm form-control' id='starTime'" +
            " ng-change='selectStartTime()' ng-model='placeOrders.startTime'/>",
            link: function (scope, el, attr) {
                scope.selectStartTime = function () {
                    scope.placeOrder.startTime = $filter('date')(scope.placeOrders.startTime, 'yyyy-MM-dd');
                    var d = new Date();
                    var strDate = getDateStr(d);

                    function getDateStr(date) {
                        var date = $filter('date')(date, 'yyyy-MM-dd');
                        return date;
                    }

                    if (scope.placeOrder.startTime < strDate) {
                        scope.placeOrders.startTime = "";
                        toaster.pop('warning', '提示', '填写的出发日期必须大于当前日期');
                    }
                };
            }
        };
    }]);

angular.module('chuanyang')
    .directive('endTime', ['$location', 'toaster', '$filter', function ($location, toaster, $filter) {
        return {
            restrict: 'AE',
            scope: false,
            template: "<input type='date' class='input-sm form-control' id='endTime'" +
            " ng-change='selectEndTime()' ng-model='placeOrders.endTime'/>",
            link: function (scope, el, attr) {
                scope.selectEndTime = function () {
                    scope.placeOrder.endTime = $filter('date')(scope.placeOrders.endTime, 'yyyy-MM-dd');
                    var d = new Date();
                    var strDate = getDateStr(d);

                    function getDateStr(date) {
                        var date = $filter('date')(date, 'yyyy-MM-dd');
                        return date;
                    }

                    if (scope.placeOrder.endTime < strDate) {
                        scope.placeOrders.endTime = "";
                        toaster.pop('warning', '提示', '填写的结束日期必须大于当前日期');
                        scope.placeOrder.endTime = $filter('date')(scope.placeOrders.endTime, 'yyyy-MM-dd');
                        if (scope.placeOrder.endTime < scope.placeOrder.startTime) {
                            scope.placeOrders.endTime = "";
                            toaster.pop('warning', '提示', '填写的结束日期必须大于开始日期');
                        }
                    }
                };
            }
        };
    }]);

angular.module('chuanyang')
    .directive('expiredTime', ['$location', 'toaster', '$filter', function ($location, toaster, $filter) {
        return {
            restrict: 'AE',
            scope: false,
            template: "<input type='date' class='input-sm form-control' id='expiredTime'" +
            "ng-model='placeOrders.expiredTime' placeholder='过期时间'/> ",
            link: function (scope, el, attr) {


            }
        };
    }]);