/**
 * Created by fangqiang on 16/9/18.
 */
angular.module('chuanyang')
    .directive('loading', function () {
        return {
            restrict: 'AE',
            scope :false,
            template: "<div  style='position: relative' ng-hide='hideLoading'>" +
            "<div class=\"alert-coverT\"> " +
            "<div class=\"alert-wrap off-center\">" +
            " <div class=\"alert\" style='text-align: center'> " +
            "<span style='text-align: center'>" +
            "<div> <img class='center-block' src=\"img/1.gif\" style='width: 100px;height: 66px;'> </div>" +
            "<div><b class=\"\">数据正在加载</b> <div>" +
            "</span> " +
            "</div> " +
            "</div> " +
            "</div> </div>",
            replace: true,
            link: function(scope, element, attr) {
                scope.hideLoading = false;
            }
        };
    });