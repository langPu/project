var isIE6 = !-[1,] && !window.XMLHttpRequest,
	isIE = !!window.ActiveXObject,
	isIE7 = isIE && navigator.appVersion.split(";")[1].replace(/[ ]/g,"")=="MSIE7.0";

// 禁止浏览器默认行为
function stopDefault(e) {
	var e= e || event;
	if (e.preventDefault) {
		e.preventDefault();
	} else {
		window.event.returnValue = false;
	}

	return false;
}

//
//图片占满 ////
//
function imgFull(imgParent) {
	/***** 图片尺寸自适应父级容器，不变形
	 * 不固定尺寸图片，确保在父级撑满
	 * 如：图片高度比例小，则高度撑满，宽度超出截取
	 * imgParent: 需要自适应的图片的父容器，也可为一组图片的祖先容器
	 * 图片只撑满父级，非祖先级别
	 */

		// 获取图片，如未传入参数，则获取data-img=full的图片
	var $imgArr = imgParent ? $(imgParent).find("img") : $("[data-img=full]"),
		len = $imgArr.length,
		i = 0;

	// 图片压缩(拉伸)裁剪
	function init() {
		var width = $(this).width(),
			height = $(this).height(),
			$parent = $(this).parent(),
			parentWidth = $parent.width(),
			parentHeight = $parent.height();

		// 判断长宽比例
		if (width/parentWidth < height/parentHeight) {

			$(this).width(parentWidth);
			$(this).height("auto");
			//alert(this.src);
			$(this).css({"position": "absolute", "left": "0", "top": -($(this).height() - parentHeight)/2});
		} else {

			$(this).width("auto");
			$(this).height(parentHeight);
			$(this).css({"position": "absolute", "top": "0", "left": -($(this).width()- parentWidth)/2});
		}

		// 判断是否加载完，隐藏loading图标
		if (++i == len) {
			removeLoading();
		}

	}

	$imgArr.each(function() {
		var $parent = $(this).parent(),
			img = new Image(),
			$self = $(this);

		// 初始化父级超出隐藏
		$parent.css({"overflow": "hidden"});

		if ($parent.css("position") != "absolute") {

			$parent.css({"position": "relative"});
		}
		init.call($self[0]);
		// 图片加载完成执行压缩
		img.onload = img.onComplete = function() {

			init.call($self[0]);
			this.onload = this.onerror = null;
			img = null;
		};

		img.onerror = function() {

			img.onload = img.onerror = null;
			img = null;
		}

		img.src = $(this).attr("src");
	});
}


//  loading移除
function removeLoading() {
	$("body").css("overflow", "visible");
	$("#loading").fadeOut();
};

$(function() {
	if ($("#loading")[0]) {
		$("body").css("overflow", "hidden");
	}
});


/***全屏滚动****/

$(function() {
	//packupHeader();
	var $indexWrap = $("#indexWrap"),
		$viewportCont = $(".viewport-cont"),
		$fixedView = $(".col-md-7 ul li"),
		$fixedViewIco = $(".fixed-view-ico a"),
		viewportHeight = $(window).height(),
		VIEWPORT_LEN = 5,	// viewport 的个数
		curIndex = 0,
		canMousewheel = true,
		lazyScroll;

	// 滚动到 viewport, target 为滚动到的viewport的索引
	function viewportGo(target) {
		var direction;	// 滚动方向，down 向下滚, up向上滚

		// 判断target是否超出
		target = Math.max(0, Math.min(VIEWPORT_LEN, target));
		// 判断目标viewport和当前的是否是同一个
		if (target == curIndex) {
			return;
		}
		canMousewheel = false;

		if (target == VIEWPORT_LEN) {

			$indexWrap.stop().animate({"scrollTop": "+=282"},  1500, 'easeInOutExpo', function() {

				canMousewheel = true;
			});
			curIndex = VIEWPORT_LEN;
			return;
		}
		if (curIndex == VIEWPORT_LEN && target == VIEWPORT_LEN - 1) {

			$indexWrap.stop().animate({"scrollTop": "-=282"},  1500, 'easeInOutExpo', function() {

				canMousewheel = true;
			});
			curIndex = VIEWPORT_LEN - 1;
			return;
		}



		// 判断indexWrap滚动的方向
		direction = target > curIndex ? "down" : "up";

		// 执行入场出场动画
		if (curIndex != VIEWPORT_LEN) {
			viewportOut(curIndex, direction);
		}
		viewportIn(target, direction);
		//第三屏动画
		if (target == 2) {
			$(".i-about-con .box").stop().addClass("img-scale-cur");
		}else{
		}


		// 更新浏览器右侧选中
		setTimeout(function() {
			$fixedViewIco.removeClass("cur").eq(target).addClass("cur");
		}, 400);
		curIndex = target;
	};
	//导航与点相关
	$(".col-md-7 li a").click(function(){
		var n=$(".col-md-7 li a").index(this);
		/*document.title=n;*/
		$(".fixed-view-ico a").removeClass("cur").eq(n).addClass("cur");
	});




	// viewport出去
	function viewportOut(viewportIndex, direction) {
		var viewportMarginTop,
			$viewport = $viewportCont.eq(viewportIndex),
			$children = $viewport.data("children"),
			len = $children.length;

		// 判断indexWrap是向上还是向下滚动 down 向下滚, up向上滚
		viewportMarginTop = (direction == "down" ? "-" : "+") + "=150";

		$viewport.stop().animate({"margin-top": viewportMarginTop}, 800, 'easeInOutCubic');

		// 子元素移动
		$children.each(function() {
			var targetTop = direction == "down" ? -(len - $(this).index())*150 : ($(this).index() + 1)*150;

			$(this).stop().animate({"top": targetTop}, 800, 'easeInOutCubic', function() {
				$(this).css("top", 0);
			});
		});
	};

	// viewport进来
	function viewportIn(viewportIndex, direction) {
		var viewportMarginTop,
			$viewport = $viewportCont.eq(viewportIndex),
			$children = $viewport.data("children"),
			len = $children.length;

		// 判断indexWrap是向上还是向下滚动 down 向下滚, up向上滚
		if (direction == "down") {
			viewportMarginTop = "-=150";
			viewportInitMarginTop = $viewport.data("defaultMarginTop") + 150;
		} else {
			viewportMarginTop = "+=150";
			viewportInitMarginTop = $viewport.data("defaultMarginTop") - 150;
		};

		// 滚动indexWrap
		$indexWrap.stop().animate({"scrollTop": viewportIndex * viewportHeight},  1200, 'easeInOutCubic');

		// 初始化$viewport 并运动
		$viewport.css("margin-top", viewportInitMarginTop).stop().delay(380).animate({"margin-top": viewportMarginTop}, 800, 'easeInOutCubic', function() {
			canMousewheel = true;
		});

		// 初始化子元素并运动
		$children.each(function(index) {
			$(this).css("top", function(index) {
				return (direction == "down" ? index * 150 : -index*150);
			}).stop().delay(380).animate({"top": 0}, 800, 'easeInOutCubic')
		});
	};

	// 鼠标滚动事件
	function fnMousewheel(e) {
		var direction,
			e = e || event;

		if (!canMousewheel) {
			return;
		}
		clearTimeout(lazyScroll);

		// 获取滚轮方向
		if (e.wheelDelta)  {//IE/Opera/Chrome 
			direction = e.wheelDelta;
		} else if (e.detail) {//Firefox 
			direction = e.detail * (-1);
		}

		lazyScroll = setTimeout(function() {
			// 判断滚动方向
			if (direction < 0) {
				viewportGo(curIndex + 1);
			} else {

				viewportGo(curIndex - 1);
			}
		}, 100);
	}

	// 初始化页面
	var $viewNext = $(".view-next"),
		$viewPrev = $(".view-prev"),
		$overviewView = $(".overview-view"),
		$historyView = $(".history-view");
	$(".view-bg").find("img").css("margin", 0);
	function initViewport() {

		if( viewportHeight <= 768){
			$viewportCont.find(".view-tit").css({"padding-top":"130px"});
			$viewportCont.find(".view-tit h2").css({"font-size":"34px"});
			$viewportCont.find(".view-tit h2").css({"line-height":"70px"});
			$viewportCont.find(".honor-box").css({"margin-top":"20px"});
			$viewportCont.find(".i-about-con").css({"padding-top":"50px"});
		} else {
			$viewportCont.find(".view-tit").css({"padding-top":"180px"});
			$viewportCont.find(".view-tit h2").css({"font-size":"46px"});
			$viewportCont.find(".view-tit h2").css({"line-height":"100px"});
			$viewportCont.find(".honor-box").css({"margin-top":"50px"});
			$viewportCont.find(".i-about-con").css({"padding-top":"80px"});
		}

		$indexWrap.css({"overflow": "hidden", "height": viewportHeight});
		$indexWrap.scrollTop(curIndex*viewportHeight);
		$(".viewport").css("overflow", "hidden");
		$fixedViewIco.eq(curIndex).addClass("cur");

		// $(".view-bg").height(viewportHeight-70);
		imgFull($(".view-bg"));

		$(".banner").height(viewportHeight);
		imgFull($(".banner"));
	}

	initViewport();
	// 初始化缓存
	$viewportCont.each(function() { // 保存默认的margin-top，缓存children()
		var defaultMarginTop = parseInt($(this).css("margin-top")),
			$children = $(this).children();

		$(this).data({"defaultMarginTop": defaultMarginTop, "children": $children});
		//$children.css({"position": "relative"});
	});


	// 右侧小点绑定点击事件
	$fixedViewIco.on("click", function() {
		var index = $(this).index();
		viewportGo(index);
	});

	//导航绑定点击事件
	$fixedView.on("click", function() {
		var index = $(this).index();
		viewportGo(index);
	});

	// 下一屏按钮添加事件
	$(".view-next").each(function(index) {
		$(this).on("click", function() {
			viewportGo(index+1);
		});
	});
	// 上一屏按钮添加事件
	$(".view-prev").each(function(index) {
		$(this).on("click", function() {
			viewportGo(index);
		});
	});

	$(".view-last").each(function(index) {
		$(this).on("click", function() {
			viewportGo(index);
		});
	});

	//绑定滚轮事件
	if ($indexWrap[0].addEventListener) {//ff3.5以下
		$indexWrap[0].addEventListener("DOMMouseScroll", function(e) {
			fnMousewheel(e);
		}, false);
	}
	$indexWrap[0].onmousewheel = function(e) {
		fnMousewheel(e);
	};

	// 默认进入页面停留位置
	(function() {
		curIndex = parseInt(location.hash.split("=")[1]) || 0;

		$indexWrap.scrollTop(curIndex*viewportHeight);
		$fixedViewIco.removeClass("cur").eq(curIndex).addClass("cur");

		if (curIndex > 0) {
			packupHeader();
		}



	})();

	// 改变窗口大小事件
	$(window).on("resize", function() {

		viewportHeight = $(window).height();
		initViewport();

		$(".banner").height(viewportHeight);
		//window.location.reload();


	});

	$("#overviewGoNext").on("click", function() {
		viewportGo(1);
	});
});

/******************************************
 ***										***
 ***				页面效果				***
 ***										***
 ******************************************/
$(function() {


	//banner 切换
	var scrollW , listN ;
	init2();
	$(window).resize(function(){
		init2();
		var indexNum = $(".ban-num span.on").index();
		$(".banner ul").css({"left":-indexNum*scrollW})
	})
	function init2(){
		scrollW = parseInt($(window).width());
		if (scrollW<960) {
			scrollW = 960
		};
		listN = $(".banner li").length;
		$(".banner li").width(scrollW);
		$(".banner ul").width(scrollW*listN);
	}

	var $img = $(".banner img:eq(0)");
	var img = new Image();
	img.onload = function(){
		banner(".banner",".ban-num");
	};
	img.src = $img.attr("src");

	// banner(".banner",".ban-num");
	function banner(wrap,number){
		var $wrap = $(wrap),
			$number = $(number),
			$Li = $wrap.find("li"),
			$Ul = $wrap.find("Ul"),
			$prev = $wrap.find(".prev"),
			$next = $wrap.find(".next"),
			sw = 0;
		if(listN==1){
			$number.hide();
		}

		$(".banner ul img").fadeIn();
		$number.find("span").eq(0).addClass("on");
		$number.find("span").mouseover(function(){
			sw = $number.find("span").index(this);
			myShow(sw);
		});
		//执行效果
		function myShow(sw){
			$Ul.stop().animate({left:-sw*scrollW},1500,"easeInOutExpo");
			$number.find("span").eq(sw).addClass("on").siblings("span").removeClass("on");
		}
		$prev.hover(function(){
			$(this).animate({left:10},500);
		},function(){
			$(this).animate({left:-1},500);
		})
		$next.hover(function(){
			$(this).animate({right:10},500);
		},function(){
			$(this).animate({right:-1},500);
		})
		$next.click(function(){
			if(sw==listN-1){
				sw = -1;
			}
			myShow(sw+1);
			sw++;
		})
		$prev.click(function(){
			if(sw==0){
				sw = listN;
			}
			myShow(sw-1);
			sw--;
		})
		//滑入停止动画，滑出开始动画
		$wrap.hover(function(){
			if(myTime){
				clearInterval(myTime);
			}
		},function(){
			clearInterval(myTime);
			myTime = setInterval(function(){
				myShow(sw);
				sw++;
				if(sw==listN){sw=0;}
			} , 4000);
		});
		//自动开始
		var myTime = setInterval(function(){
			myShow(sw);
			sw++;
			if(sw==listN){sw=0;}
		} , 4000);

	};
});

