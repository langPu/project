/**
 * Created by WAHOO on 2016/10/14.
 */
chuanyang.controller('welcomeCtrl', ['$scope','$localStorage', function ($scope,$localStorage) {
    if (ROOTCONFIG.debug) {
        console.log("into WelcomeCtrl...");
    }
}]);