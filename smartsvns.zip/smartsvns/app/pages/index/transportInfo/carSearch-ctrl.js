/**
 * Created by W on 2016/11/16.
 */
'use strict';

chuanyang.controller('carSearchCtrl',['$scope','$modal','$localStorage','urls','$filter','toaster','$state',
    function($scope,$modal,$localStorage,urls,$filter,toaster,$state){

        $scope.currentPage=1;
        $scope.pageSize=10;
        $scope.total=0;
        $scope.carInfo={};
        $scope.carInfo.personcarHad=false;
        $scope.carInfo.fleetcarHad=false;
        $scope.carInfo.personcarList=[];
        $scope.carInfo.fleetcarList=[];

        //司机

        $scope.getPersoncar=function(){
            toaster.pop('wait','提示','正在加载...',6000);
            var getPersoncarUrl=ROOTCONFIG.basePath+"info/driver/selectDriverNofleetList";
            $scope.getPersoncarParam={
                "page":$scope.currentPage,
                "length":$scope.pageSize,
                "startCity":$scope.carInfo.startAddr,
                "targetCity":$scope.carInfo.targetAddr,
                "Scapacity":$scope.carInfo.Scapacity,
                "Ecapacity":$scope.carInfo.Ecapacity,
                "carType":$scope.carInfo.carType,
                "driverType":$scope.carInfo.driverType
            };
            console.log(angular.toJson($scope.getPersoncarParam,true));
            urls.sendRequest('POST', angular.toJson($scope.getPersoncarParam), getPersoncarUrl, '').success(function (response) {
                if(response.code==100){
                    toaster.clear();
                    console.log(angular.toJson(response,true));
                    if(response.data.data.length!=0){
                        $scope.carInfo.personcarHad=false;
                    }else{
                        $scope.carInfo.personcarHad=true;
                    }
                    angular.copy(response.data.data,$scope.carInfo.personcarList);
                    $scope.total=response.data.total;
                }
            })
        }

        //车队
        $scope.getFleetcar=function(){
            toaster.pop('wait','提示','正在加载...',6000);
            var getFleetcarUrl=ROOTCONFIG.basePath+"info/driverWeb/selectFleetList";
            $scope.getFleetcarParam={
                "page":$scope.currentPage,
                "length":$scope.pageSize,
                "startCity":$scope.carInfo.startAddr,
                "targetCity":$scope.carInfo.targetAddr,
                "Scapacity":$scope.carInfo.Scapacity,
                "Ecapacity":$scope.carInfo.Ecapacity,
                "fleetType":$scope.carInfo.fleetType
            };
            console.log(angular.toJson($scope.getFleetcarParam,true));
            urls.sendRequest('POST', angular.toJson($scope.getFleetcarParam), getFleetcarUrl, '').success(function (response) {
                if(response.code==100){
                    toaster.clear();
                    console.log(angular.toJson(response,true));
                    if(response.data.data.length!=0){
                        $scope.carInfo.fleetcarHad=false;
                    }else{
                        $scope.carInfo.fleetcarHad=true;
                    }
                    angular.copy(response.data.data,$scope.carInfo.fleetcarList);
                    $scope.total=response.data.total;
                }
            })
        }

        $scope.getCarInfo=function(flag){

            if(flag==='1'){
                $state.go('index.carSearch.personcar');
                $scope.currentPage=1;
                $scope.driverSelect=flag;
                $scope.carInfo.driverType='2';
                $scope.getPersoncar();
                //分页
                $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
                    $scope.currentPage = page;
                    $scope.getPersoncar();
                    console.log(page);
                    console.log(pageSize);
                };
            }else if(flag==='2'){
                $state.go('index.carSearch.fleetcar');
                $scope.currentPage=1;
                $scope.carInfo.fleetType='2';
                $scope.driverSelect=flag;
                $scope.getFleetcar();

                //分页
                $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
                    $scope.currentPage = page;
                    $scope.getFleetcar();
                    console.log(page);
                    console.log(pageSize);
                };
            }else if(flag==='3'){
                $state.go('index.carSearch.personship');
                $scope.currentPage=1;
                $scope.carInfo.driverType='3';
                $scope.getPersoncar();
                //分页
                $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
                    $scope.currentPage = page;
                    $scope.getPersoncar();
                    console.log(page);
                    console.log(pageSize);
                };
            }else if(flag==='4'){
                $state.go('index.carSearch.fleetship');
                $scope.currentPage=1;
                $scope.carInfo.fleetType='3';
                $scope.getFleetcar();
                //分页
                $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
                    $scope.currentPage = page;
                    $scope.getFleetcar();
                    console.log(page);
                    console.log(pageSize);
                };
            }
        }
        $scope.getCarInfo('1');


        //查询
        $scope.searchCarDetail=function(){
           console.log($scope.carInfo.startAddr,$scope.carInfo.targetAddr,$scope.carInfo.carType);
            if($scope.driverSelect==='1'){
                $scope.getPersoncar();

            }else if($scope.driverSelect==='2'){
                $scope.getFleetcar();
            }
        }
   //咨询
        $scope.getQrCode=function(data){
            if($localStorage.chuanYangloginMessege == undefined){
                $state.go('index.login');
            }else{
                var modalInstance=$modal.open({
                    templateUrl: 'pages/index/qrCode.html',
                    size:'sm'
                });
            }

        };

    }])