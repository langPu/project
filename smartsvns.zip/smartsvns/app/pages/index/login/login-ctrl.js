/**
 * Created by fangqiang on 16/11/24.
 */
    'use strict';
    angular.module('chuanyang').controller('loginNewController', loginNewController);
    loginNewController.$inject = ['$scope','$http','$state','toaster','urls','$localStorage','$rootScope','$interval'];
    function loginNewController($scope,$http,$state,toaster,urls,$localStorage,$rootScope,$interval) {
        console.log("进入");
        var vm= this;
        vm.loginData = {

        };
        angular.element("#carPerson").css("background","#5bc0de");
        angular.element("#goodsPerson").css("background","#5bc0de");
        angular.element("#companyPerson").css("background","#5bc0de");
        vm.selectPerson = function (params) {
            console.log(params);
            switch (params) {
                case 1:
                    angular.element("#carPerson").css("background","#189ec8");
                    angular.element("#goodsPerson").css("background","#5bc0de");
                    angular.element("#companyPerson").css("background","#5bc0de");
                    vm.loginData.userType = 2;
                    break;
                case 2:
                    angular.element("#carPerson").css("background","#5bc0de");
                    angular.element("#goodsPerson").css("background","#189ec8");
                    angular.element("#companyPerson").css("background","#5bc0de");
                    vm.loginData.userType = 1;

                    break;
                case 3:
                    angular.element("#carPerson").css("background","#5bc0de");
                    angular.element("#goodsPerson").css("background","#5bc0de");
                    angular.element("#companyPerson").css("background","#189ec8");
                    vm.loginData.userType = 3;
                    break;
            }

        };
        vm.login = function () {
            if (vm.loginData.userType == undefined) {
                toaster.pop('info', '提示', '请选择登录角色',2000);
                return;
            }

            console.log(angular.toJson(vm.loginData,true));
            var urlLogin = ROOTCONFIG.basePath4 + "info/user/signIn";
            toaster.pop('wait', '提示', '正在登录', 60000);
            urls.sendRequest('POST', angular.toJson(vm.loginData), urlLogin, '').success(function (response) {
                toaster.clear();
                console.log(angular.toJson($localStorage.chuanYangloginMessege, true));
                if (ROOTCONFIG.debug) {
                    console.log(angular.toJson(response, true));
                }
                if (response.code == '100') {
                    toaster.pop('success', '提示', '登陆成功');
                    $localStorage.chuanYangloginMessege = response.data;
                    $rootScope.userSettings.user = response.data;
                    //根据用户类型跳转界面
                     var getRemainOverdraftUrl = ROOTCONFIG.basePath + "info/account/getAccountById";

                    if (vm.loginData.userType == 1) {
                            vm.custId = response.data.userId;
                            vm.accountType = 1;
                        getRemainOverdraft(vm.custId,vm.accountType,getRemainOverdraftUrl);
                        $state.go('home.shipperList');
                        $localStorage.chuanYangloginMessege.selected = 'shipper';
                    } else if (vm.loginData.userType == 2) {
                        $state.go('index.goodsSearch');
                        $localStorage.chuanYangloginMessege.selected = 'driver';//暂时driver改为logistic
                    } else if (vm.loginData.userType == 3) {
                        vm.custId = response.data.companys[0].companyID;
                        vm.accountType = 2;
                        getRemainOverdraft(vm.custId,vm.accountType,getRemainOverdraftUrl);
                        $state.go('home.allocationOrder');
                        $localStorage.chuanYangloginMessege.selected = 'logistic';
                    }

                    /*----------------------------------------*/
                } else {
                    toaster.pop('error', '提示', response.msg);
                }
            });

        };

        function getRemainOverdraft(custId,accountType,url){
            urls.sendRequest('GET', '', url+'?custId='+custId+'&accountType='+accountType, '').success(function (response) {
                function notify(){
                    $rootScope.hideTips = true;
                    $rootScope.timeReduce = 10;
                }
                if(response.code==100){
                    $rootScope.hideTips = false;
                    $rootScope.remainOverdraft = response.data.accounts[0].remainOverdraft;
                   var timer =  $interval(function(){
                       $rootScope.timeReduce--
                   },1000,10);
                    timer.then(notify);
                }
            })
        };
    }
