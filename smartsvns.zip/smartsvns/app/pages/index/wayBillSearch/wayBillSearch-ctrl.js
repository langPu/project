/**
 * Created by W on 2016/11/18.
 */
'use strict';

chuanyang.controller('wayBillSearchCtrl',['$scope','$modal','$localStorage','$stateParams','urls','$filter','toaster','$state',
    function($scope,$modal,$localStorage,$stateParams,urls,$filter,toaster,$state) {
        $scope.orderMessage = $stateParams.orderMessage;
        console.log(angular.toJson($scope.orderMessage,true));
         $scope.wayBill={};
        $scope.wayBill.orderInfoList=[];
        $scope.wayBill.wayBillInfoList=[];

        $scope.currentPage = 1;
        $scope.pageSize = 10;//每页条数
        $scope.total =0;

        //订单查
        //$scope.spread = para;
        //console.log(angular.toJson(para));
        $scope.wayBill.getOrderInfo=function(){
            var orderInfoUrl=ROOTCONFIG.basePath + "info/waybill/selectByOrderId/";
            $scope.orderInfoParam={
                "orderNo":$scope.orderMessage //,
            //    "page":$scope.currentPage,
             //   "length":$scope.pageSize
            };
            console.log(angular.toJson($scope.orderInfoParam));
            if(!$scope.orderMessage){
                toaster.pop('warning','提示','请输入订单号');
                return;
            }
            urls.sendRequest('POST', angular.toJson($scope.orderInfoParam),orderInfoUrl).success(function (response) {
                if(response.code==100){
                    console.log(angular.toJson(response));
                    if(response.data.data.length!=0){
                        angular.copy(response.data.data,$scope.wayBill.orderInfoList);
                    }else{
                        toaster.pop('message','提示','没有查到相关的运单信息!');
                    }
                  //  $scope.total=response.data.total;

                }else{
                    toaster.pop('message','提示',response.msg);
                }
            })
        }

        //运单查
        $scope.wayBill.getWayBillInfo=function(){
            var wayBillInfoUrl=ROOTCONFIG.basePath + "info/waybill/selWaybillDriver";
            $scope.wayBillInfoParam={
                "waybillNo":$scope.orderMessage
            };
            console.log(angular.toJson($scope.wayBillInfoParam));
            if(!$scope.orderMessage){
                toaster.pop('warning','提示','请输入运单号');
                return;
            }

            urls.sendRequest('POST', angular.toJson($scope.wayBillInfoParam),wayBillInfoUrl).success(function (response) {
                if(response.code==100){
                    console.log(angular.toJson(response));
                    if(response.data.data.length!=0){
                        angular.copy(response.data.data,$scope.wayBill.wayBillInfoList);
                    }else{
                        toaster.pop('message','提示','没有查到相关的运单信息!');
                    }
                   // $scope.total=response.data.total;


                }else{
                    toaster.pop('message','提示',response.msg);
                }
            })
        }

        $scope.getSearch=function(flag){
            if(flag==='1'){
                $state.go('index.wayBillSearch.orderInfo');
                //分页
                $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
                    $scope.currentPage = page;
                    $scope.wayBill.getOrderInfo();
                    console.log(page);
                    console.log(pageSize);
                };

            }else if(flag==='2'){
                $state.go('index.wayBillSearch.wayBillInfo');
                //分页
                $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
                    $scope.currentPage = page;
                    $scope.wayBill.getWayBillInfo();
                    console.log(page);
                    console.log(pageSize);
                };
            }

        }
    }])