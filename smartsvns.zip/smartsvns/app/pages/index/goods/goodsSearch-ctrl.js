/**
 * Created by W on 2016/11/17.
 */
'use strict';

chuanyang.controller('goodsSearchCtrl', ['$scope', '$modal', '$localStorage', 'urls', '$filter', 'toaster', '$state', '$interval',
    function ($scope, $modal, $localStorage, urls, $filter, toaster, $state, $interval) {
        //$scope.goodsSelected=true;
        $scope.goodsInfoList = [];
        $scope.orderType = 1;
        $scope.timeOver = [];
        $scope.goodsInfo = {};
        $scope.goodsInfoDetailShow = false;
        $scope.goodsInfo.bidOrder = false;
        $scope.goodsInfo.matchOrder = false;
        var timer;
        $scope.total = 0;
        $scope.currentPage = 1;//当前页
        $scope.pageSize = 10;//每页多少条数据
        $scope.goodsInfoListParam = {};
        $scope.goodsTimeShow=false;
        /*$scope.price = [
         {
         "type":"desc","name":"降序"
         },
         {
         "type":"asc","name":"升序"
         }
         ]*/
        //时间
        $scope.timeType = true;
        $scope.timeSort = function (type) {
            $scope.timeType = !$scope.timeType;
            $scope.goodsInfoListParam.property = "order_time";
            $scope.getGoodsInfoList(type);
        }
        //价格
        $scope.priceType = true;
        $scope.priceSort = function (type) {
            $scope.priceType = !$scope.priceType;
            $scope.goodsInfoListParam.property = "order_Amount";
            $scope.getGoodsInfoList(type);
        }


        //列表
        $scope.getGoodsInfoList = function (type) {
            //toaster.pop('wait','提示','正在加载...',6000);

            $scope.goodsInfoListParam.sort = type;
            $scope.goodsInfoListParam.orderType = $scope.orderType;
            $scope.goodsInfoListParam.page = $scope.currentPage;
            $scope.goodsInfoListParam.length = $scope.pageSize;
            $scope.goodsInfoListParam.startTime = $scope.goodsInfo.startTime;
            $scope.goodsInfoListParam.endTime = $scope.goodsInfo.endTime;
            $scope.goodsInfoListParam.orderTime = $scope.goodsInfo.orderTime;
            $scope.goodsInfoListParam.startAddr = $scope.goodsInfo.startAddr;
            $scope.goodsInfoListParam.targetAddr = $scope.goodsInfo.targetAddr;
            $scope.goodsInfoListParam.MinWeight = $scope.goodsInfo.MinWeight;
            $scope.goodsInfoListParam.MaxWeight = $scope.goodsInfo.MaxWeight;

            console.log(angular.toJson($scope.goodsInfoListParam, true));
            var getGoodsInfoUrl = ROOTCONFIG.basePath + "info/driverWeb/selectOrderListMsg";
            urls.sendRequest('POST', angular.toJson($scope.goodsInfoListParam), getGoodsInfoUrl).success(function (response) {
                if (response.code == 100) {
                    //    toaster.clear();
                    $scope.goodsInfo.bidOrder = false;
                    $scope.goodsInfo.matchOrder = false;
                    angular.copy(response.data.data, $scope.goodsInfoList);
                    $scope.total = response.data.total;
                    console.log('%c' + angular.toJson($scope.goodsInfoList, true), ['color:#00f'].join(';'));

                    if ($scope.goodsInfoList.length) {

                        for (var i = 0; i < $scope.goodsInfoList.length; i++) {
                            $scope.nowTime = Date.parse(new Date());
                            $scope.timeOver[i] = $scope.goodsInfoList[i].expiredTime * 1000 - $scope.nowTime;
                        }
                        $interval.cancel(timer);
                        timer = $interval(function () {
                            for (var j = 0; j < $scope.timeOver.length; j++) {
                                $scope.timeOver[j] -= 1000;
                                //竟时完结
                                if ($scope.timeOver[j] == 0) {
                                    $scope.getGoodsInfoList();
                                    /*  for(var k=0;k<$scope.goodsInfoList.length;k++){
                                     if($scope.goodsInfoList[j].orderId==$scope.goodsInfoList[k].orderId){
                                     $scope.goodsInfoList.splice(k,1);
                                     }
                                     }*/

                                }
                            }
                        }, 1000);


                    } else {
                        if ($scope.orderType == 1) {
                            $scope.goodsInfo.bidOrder = true;
                        } else {
                            $scope.goodsInfo.matchOrder = true;
                        }

                    }

                }
            })

        }


        $scope.getGoodsInfo = function (flag) {
            if (flag === '1') {
                $scope.goodsSelected = true;
                $scope.orderType = flag;
                $scope.currentPage = 1;
                $scope.getGoodsInfoList();


            } else if (flag === '2') {
                $scope.goodsSelected = false;
                $scope.orderType = flag;
                $scope.currentPage = 1;
                $scope.getGoodsInfoList();
            }
        }
        $scope.getGoodsInfo('1');


        //查询

        $scope.getDate = function () {

        };

        $scope.goodsInfo.refer = function () {
            console.log($scope.goodsInfo.startTime, $scope.goodsInfo.endTime, $scope.goodsInfo.orderTime);
            $scope.getGoodsInfoList();
        };

        //
        $scope.getQrCode = function (data) {
            console.log(angular.toJson(data, true));
            if ($localStorage.chuanYangloginMessege == undefined) {
                $state.go('index.login');
            } else if ($localStorage.chuanYangloginMessege.selected == 'driver') {

                var url = ROOTCONFIG.basePath4 + "info/driver/selectUser";
                var params = {
                    driverId: $localStorage.chuanYangloginMessege.userId
                };
                // toaster.pop('wait', '提示', '正在校验运力', 60000);
                urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {
                    // toaster.clear();
                    if (response.code == '100') {
                        if (response.data.driver.driverType == 2 && data.transPortWay == 1) {
                            if (response.data.fleet) {
                                if (response.data.fleet.capacity >= data.orderGoodsMsgs[0].goodsWeight) {
                                    $scope.items = {
                                        "title": "确定对该单进行竞价?",
                                        "data": [
                                            {name: '请出价', type: 'text', filter: 'text'}

                                        ]
                                    };
                                    var modalInstance = $modal.open({
                                        templateUrl: 'changeConpany.html',
                                        controller: 'repeatModelCtrl',
                                        resolve: {
                                            items: function () {
                                                return $scope.items;
                                            }
                                        }
                                    });
                                    modalInstance.result.then(function (selectedItem) {
                                        console.log(angular.toJson(selectedItem, true));

                                        if (selectedItem.data[0].model == undefined) {

                                        } else {
                                            var url = ROOTCONFIG.basePath4 + "info/bid/addBid";
                                            var params = {
                                                orderId: data.orderId,
                                                userId: response.data.driver.driverId,
                                                bid: selectedItem.data[0].model,
                                                bidStatus: 1,
                                                bidType: 2,
                                                price: data.orderAmount
                                            };
                                            if (selectedItem.data[0].model < data.orderAmount) {
                                                console.log(angular.toJson(params, true));
                                                urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {

                                                    if (response.code == 100) {

                                                        toaster.pop('success', '提示', '竞价成功');

                                                    } else {
                                                        toaster.pop('error', '提示', response.msg);

                                                    }
                                                })
                                            } else {
                                                toaster.pop('warning', '提示', '竞价不能够低于底价');

                                            }
                                        }

                                    }, function () {

                                    });

                                } else {
                                    toaster.pop('warning', '提示', '运力不符合要求');

                                }
                            } else {
                                if (response.data.driver.capacity >= data.orderGoodsMsgs[0].goodsWeight) {
                                    $scope.items = {
                                        "title": "确定对该单进行竞价?",
                                        "data": [
                                            {name: '请出底价', type: 'text', filter: 'text'}

                                        ]
                                    };
                                    var modalInstance = $modal.open({
                                        templateUrl: 'changeConpany.html',
                                        controller: 'repeatModelCtrl',
                                        resolve: {
                                            items: function () {
                                                return $scope.items;
                                            }
                                        }
                                    });
                                    modalInstance.result.then(function (selectedItem) {
                                        console.log(angular.toJson(selectedItem, true));

                                        if (selectedItem.data[0].model == undefined) {

                                        } else {
                                            var url = ROOTCONFIG.basePath4 + "info/bid/addBid";
                                            var params = {
                                                orderId: data.orderId,
                                                userId: response.data.driver.driverId,
                                                bid: selectedItem.data[0].model,
                                                bidStatus: 1,
                                                bidType: 1,
                                                price: data.orderAmount
                                            };
                                            if (selectedItem.data[0].model < data.orderAmount) {
                                                console.log(angular.toJson(params, true));
                                                urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {

                                                    if (response.code == 100) {

                                                        toaster.pop('success', '提示', '竞价成功');

                                                    } else {
                                                        toaster.pop('error', '提示', response.msg);

                                                    }
                                                })
                                            } else {
                                                toaster.pop('warning', '提示', '竞价不能够高于底价');

                                            }
                                        }

                                    }, function () {

                                    });

                                } else {
                                    toaster.pop('warning', '提示', '运力不符合要求');

                                }
                            }
                        }else if(response.data.driver.driverType == 3 && data.transPortWay == 2){
                            if (response.data.fleet) {
                                if (response.data.fleet.capacity >= data.orderGoodsMsgs[0].goodsWeight) {
                                    $scope.items = {
                                        "title": "确定对该单进行竞价?",
                                        "data": [
                                            {name: '请出底价', type: 'text', filter: 'text'},
                                            {name: '备注', type: 'text', filter: 'text'}

                                        ]
                                    };
                                    var modalInstance = $modal.open({
                                        templateUrl: 'changeConpany.html',
                                        controller: 'repeatModelCtrl',
                                        resolve: {
                                            items: function () {
                                                return $scope.items;
                                            }
                                        }
                                    });
                                    modalInstance.result.then(function (selectedItem) {
                                        console.log(angular.toJson(selectedItem, true));

                                        if (selectedItem.data[0].model == undefined) {

                                        } else {
                                            var url = ROOTCONFIG.basePath4 + "info/bid/addBid";
                                            var params = {
                                                orderId: data.orderId,
                                                userId: response.data.driver.driverId,
                                                bid: selectedItem.data[0].model,
                                                bidStatus: 1,
                                                bidType: 2,
                                                price: data.orderAmount,
                                                bidRemark:selectedItem.data[1].model
                                            };
                                            if (selectedItem.data[0].model <= data.orderAmount) {
                                                console.log(angular.toJson(params, true));
                                                urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {

                                                    if (response.code == 100) {

                                                        toaster.pop('success', '提示', '竞价成功');

                                                    } else {
                                                        toaster.pop('error', '提示', response.msg);

                                                    }
                                                })
                                            } else {
                                                toaster.pop('warning', '提示', '竞价不能够低于底价');

                                            }
                                        }

                                    }, function () {

                                    });

                                } else {
                                    toaster.pop('warning', '提示', '运力不符合要求');

                                }
                            } else {
                                if (response.data.driver.capacity >= data.orderGoodsMsgs[0].goodsWeight) {
                                    $scope.items = {
                                        "title": "确定对该单进行竞价?",
                                        "data": [
                                            {name: '请出底价', type: 'text', filter: 'text'},
                                            {name: '备注', type: 'text', filter: 'text'}
                                        ]
                                    };
                                    var modalInstance = $modal.open({
                                        templateUrl: 'changeConpany.html',
                                        controller: 'repeatModelCtrl',
                                        resolve: {
                                            items: function () {
                                                return $scope.items;
                                            }
                                        }
                                    });
                                    modalInstance.result.then(function (selectedItem) {
                                        console.log(angular.toJson(selectedItem, true));

                                        if (selectedItem.data[0].model == undefined) {

                                        } else {
                                            var url = ROOTCONFIG.basePath4 + "info/bid/addBid";
                                            var params = {
                                                orderId: data.orderId,
                                                userId: response.data.driver.driverId,
                                                bid: selectedItem.data[0].model,
                                                bidStatus: 1,
                                                bidType: 1,
                                                price: data.orderAmount,
                                                bidRemark:selectedItem.data[1].model
                                            };
                                            if (selectedItem.data[0].model <= data.orderAmount) {
                                                console.log(angular.toJson(params, true));
                                                urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {

                                                    if (response.code == 100) {

                                                        toaster.pop('success', '提示', '竞价成功');

                                                    } else {
                                                        toaster.pop('error', '提示', response.msg);

                                                    }
                                                })
                                            } else {
                                                toaster.pop('warning', '提示', '竞价不能够高于底价');

                                            }
                                        }

                                    }, function () {

                                    });

                                } else {
                                    toaster.pop('warning', '提示', '运力不符合要求');

                                }
                            }
                        } else {
                            toaster.pop('warning', '提示', '承运不符合要求');
                        }

                        console.log(angular.toJson(response, true));
                    } else {

                    }
                });
            }
            else {
                $scope.items =true;
                var modalInstance = $modal.open({
                    templateUrl: 'qrCode.html',
                    size: 'sm',
                    controller: 'repeatModelCtrl',
                    resolve: {
                        items: function () {
                            return $scope.items;
                        }
                    }
                });
            }


        };


        //分页
        $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
            $scope.currentPage = page;
            $scope.getGoodsInfoList();
            console.log(page);
            console.log(pageSize);
        };
    }]);