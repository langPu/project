/**
 * Created by fangqiang on 16/11/23.
 */
    'use strict';
    angular.module('chuanyang').controller('helpController', helpController);
    helpController.$inject = ['$http', '$state', '$scope'];
    function helpController($http, $state, $scope) {
        console.log("进入");
        var vm = this;
        vm.howLogin = function () {
            $state.go("index.newMember.gettingStart")
        }

    }
