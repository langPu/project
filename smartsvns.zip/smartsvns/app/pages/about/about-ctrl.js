/**
 * Created by fangqiang on 16/10/22.
 */
(function () {
    'use strict';
    angular.module('chuanyang').controller('aboutController', aboutController);
    aboutController.$inject = ['$http','$state','$scope'];
    function aboutController($http,$state,$scope) {
        console.log("绅士");
        $scope.functionName = $state.current.url;

        var vm = this;
        vm.select = function (size) {
            console.log(size);
            switch (size) {
                case 1:
                    $state.go("index.about.aboutUs");
                    $scope.functionName = "/aboutUs";

                    break;
                case 2:
                    $state.go("index.about.recruit");
                    $scope.functionName = "/recruit";

                    break;
                case 3:
                    $state.go("index.about.contact");
                    $scope.functionName = "/contact";

                    break;
            }

        };
    }
})();