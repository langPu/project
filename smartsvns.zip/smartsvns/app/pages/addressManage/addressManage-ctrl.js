/**
 * Created by W on 2017/1/10.
 */
'use strict';
chuanyang.controller('addressManageCtrl', ['$scope',
    '$http',
    '$timeout',
    '$state',
    '$modal',
    '$log',
    '$filter',
    '$localStorage',
    'toaster',
    'urls', function ($scope,
                      $http,
                      $timeout,
                      $state,
                      $modal,
                      $log,
                      $filter,
                      $localStorage,
                      toaster,
                      urls) {
        $scope.currentPage = 1;
        $scope.pageSize = 6;//每页条数
        $scope.total = 0;
        $scope.addressLineList = [];
        $scope.noData = false;
        if ($localStorage.chuanYangloginMessege == undefined) {
            $state.go('index.login');
        } else {
            $scope.user_type = $localStorage.chuanYangloginMessege.userType;
        }
        $scope.addressLineShow = function () {
            var addressLineUrl = ROOTCONFIG.basePath + "info/shipperLine/selectByUser";
            if ($scope.user_type == 1) {
                $scope.addressLineParam = {
                    "shipperId": $localStorage.chuanYangloginMessege.userId,
                    "page": $scope.currentPage,
                    "length": $scope.pageSize
                };
            } else if ($scope.user_type == 3) {
                $scope.addressLineParam = {
                    "shipperId": $localStorage.chuanYangloginMessege.userId,
                    "companyId": $localStorage.chuanYangloginMessege.companys[0].companyID,
                    "page": $scope.currentPage,
                    "length": $scope.pageSize
                };
            }
            urls.sendRequest('POST', angular.toJson($scope.addressLineParam), addressLineUrl, '').success(function (res) {
                console.log(res);
                if (res.code == 100) {
                    $scope.noData = false;
                    $scope.total = res.data.total;
                    angular.copy(res.data.data, $scope.addressLineList);
                } else {
                    $scope.noData = true;
                    $scope.addressLineList = [];

                }
            })
        }
        $scope.addressLineShow();

        $scope.addAddress = function () {
            $scope.items = {
                title: "装卸货地址添加",
                data: []
            };
            var modalInstance = $modal.open({
                templateUrl: "pages/addressManage/addressModal.html",
                controller: 'addressModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var addAddrUrl = ROOTCONFIG.basePath + "info/shipperLine/insert";
                $scope.addAddrParam = {
                    "shipperId": $localStorage.chuanYangloginMessege.userId,
                    "sPoint": selectedItem.data.sAddress,
                    "ePoint": selectedItem.data.eAddress,
                    "shipperPoints": [
                        {
                            "address": "",
                            "detailAdress": selectedItem.data.sAddress,
                            "province": "",
                            "city": selectedItem.data.sCity,
                            "regions": "",
                            "latAndLng": selectedItem.data.sLatAndLng,
                            "contactPerson": selectedItem.data.sPerson,
                            "contactPhone": selectedItem.data.sPhone,
                            "pointType": "s",
                            "guide": "装卸货向导"
                        }, {
                            "address": "",
                            "detailAdress": selectedItem.data.eAddress,
                            "province": "",
                            "city": selectedItem.data.eCity,
                            "regions": "",
                            "latAndLng": selectedItem.data.eLatAndLng,
                            "contactPerson": selectedItem.data.ePerson,
                            "contactPhone": selectedItem.data.ePhone,
                            "pointType": "e",
                            "guide": "装卸货向导"
                        }
                    ]
                };
                console.log($scope.addAddrParam);
                urls.sendRequest('POST', angular.toJson($scope.addAddrParam), addAddrUrl, '').success(function (res) {
                    if (res.code == 100) {
                        $scope.addressLineShow();
                    } else {
                        toaster.pop('error', '提示', res.msg);
                    }
                });
            })
        }

        $scope.deleteAddr = function (data) {
            $scope.items = {
                title: "提示",
                tips: "确定删除该地址?"
            };
            var modalInstance = $modal.open({
                templateUrl: "pages/addressManage/addressModal.html",
                controller: 'addressModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                var deleteAddrUrl = ROOTCONFIG.basePath + "info/shipperLine/delete";
                $scope.deleteAddrParam = {
                    "slId": data.slId,
                    "shipperId": data.shipperId
                };
                console.log($scope.deleteAddrParam);
                urls.sendRequest('POST', angular.toJson($scope.deleteAddrParam), deleteAddrUrl, '').success(function (res) {
                    if (res.code == 100) {
                        $scope.addressLineShow();
                    } else {
                        toaster.pop('error', '提示', res.msg);
                    }
                })
            })
        };
        //分页
        $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
            $scope.currentPage = page;
            $scope.addressLineShow();
        };
    }]);


chuanyang.controller('addressModalCtrl', ['$scope', '$modalInstance', 'items', 'urls', '$localStorage', 'toaster', function ($scope, $modalInstance, items, urls, $localStorage, toaster) {
    $scope.items = items;
    $scope.sLatAndLngShow = false;
    $scope.eLatAndLngShow = false;
    var regPhone = /^1[3|5|8|7][0-9]{9}$/;
    var regTel = /^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,14}$/;
    $scope.checkPhone = function (flag) {
        if (flag == 's') {
            var tempBoolean = regPhone.test($scope.items.data.sPhone);
            var telBoolean = regTel.test($scope.items.data.sPhone);
            if (tempBoolean || telBoolean) {
            }else{
                toaster.pop('warning', '提示', '号码格式不正确!', 3000);
                return;
            }
        } else if (flag == 'e') {
            var tempBoolean = regPhone.test($scope.items.data.ePhone);
            var telBoolean = regTel.test($scope.items.data.sPhone);
            if (tempBoolean || telBoolean) {
            }else{
                toaster.pop('warning', '提示', '号码格式不正确!', 3000);
                return;
            }
        }

    };

    $scope.getLatAndLng = function (flag) {
        var geocoder = new AMap.Geocoder({
            radius: 1000,
            extensions: "all"
        });
        //地理编码
        if (flag == 's') {
            $scope.items.data.sLatAndLng = '';
            var reAddr = $scope.items.data.sAddress;
        } else {
            $scope.items.data.eLatAndLng = '';
            var reAddr = $scope.items.data.eAddress;
        }
        console.log(reAddr);
        geocoder.getLocation(reAddr, function (status, result) {
            if (status === 'complete' && result.info === 'OK') {
                console.log(result);
                if (flag == 's') {
                    $scope.items.data.sLatAndLng = result.geocodes[0].location.lng + ',' + result.geocodes[0].location.lat;
                    $scope.sLatAndLngShow = false;
                } else {
                    $scope.items.data.eLatAndLng = result.geocodes[0].location.lng + ',' + result.geocodes[0].location.lat;
                    $scope.eLatAndLngShow = false;
                }
            } else {
                console.log(result);
                if (flag == 's') {
                    $scope.sLatAndLngShow = true;
                } else {
                    $scope.eLatAndLngShow = true;
                }
            }
        });
    }

    //
    $scope.confirm = function () {
        if ($scope.items.data != null) {
            var tempBooleanStart = regPhone.test($scope.items.data.sPhone);
            var tempBooleanEnd = regPhone.test($scope.items.data.ePhone);
            var telBooleanStart = regTel.test($scope.items.data.sPhone);
            var telBooleanEnd = regTel.test($scope.items.data.ePhone);
            if (!$scope.items.data.sPerson || !$scope.items.data.ePerson || !$scope.items.data.sPhone || !$scope.items.data.ePhone
                || !$scope.items.data.sCity || !$scope.items.data.eCity || !$scope.items.data.ePerson || !$scope.items.data.sAddress
                || !$scope.items.data.eAddress || !$scope.items.data.sLatAndLng || !$scope.items.data.eLatAndLng) {

                toaster.pop('error', '提示', '请将信息填写完整！', 3000);
                return;
            }
            if (tempBooleanStart || telBooleanStart) {
            }else{
                toaster.pop('warning', '提示', '号码格式不正确!', 3000);
                return;
            }
            if (tempBooleanEnd || telBooleanEnd) {
            }else{
                toaster.pop('warning', '提示', '号码格式不正确!', 3000);
                return;
            }
        }

        $scope.selected = items;
        console.log($scope.selected);
        $modalInstance.close($scope.selected);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);

