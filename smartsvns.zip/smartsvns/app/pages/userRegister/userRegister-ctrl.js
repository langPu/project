/**
 * Created by W on 2016/10/28.
 */
'use strict';
chuanyang.controller('userRegisterCtrl',['$scope','$state','urls','toaster','$interval','$timeout',function($scope,$state,urls,toaster,$interval,$timeout){
    $scope.userRegisterItems={
        "username":"",
        "usersex":"",
        "useraddr":"",
        "phone":"",
        "password":"",
        "rePassword":"",
        "userType":"1",
        "validateCode":""
    };
    $scope.numNow=60;
    $scope.codeGet=true;
    $scope.shipperSelected=true;
    var regPhone=/^1[3|5|8|7][0-9]{9}$/g;

    //选择
    $scope.userSelect=function(flag){
        if(flag=='1'){
            $scope.shipperSelected=true;
        }else if(flag=='3'){
            $scope.shipperSelected=false;
        }
    }

//获取验证码
    $scope.getvalidateCode=function(){
        var getvalidateCodeUrl=ROOTCONFIG.basePath+"info/user/getValidateCode";
        console.log($scope.userRegisterItems.phone);
        if($scope.userRegisterItems.phone==""){
            console.log(toaster);
            toaster.clear();
            toaster.pop('warning','提示','手机号不能为空');
            return false;
        }else if(!regPhone.test($scope.userRegisterItems.phone)){
            toaster.clear();
            toaster.pop('warning','提示','手机号格式不正确');
            return false;
        };

        $scope.codeGet=false;
        var countNum=function(){
            if($scope.numNow==1){
                $scope.codeGet=true;
                $scope.numNow=60;
            }else{
                $scope.numNow--;
            }
        };
        $interval(countNum,1000,60);
        urls.sendRequest('GET','',getvalidateCodeUrl + "?phone=" + $scope.userRegisterItems.phone,'').success(function(res){
            console.log(angular.toJson(res));
        });
    };

    //注册
    $scope.userRegister=function(){
       // console.log(angular.toJson($scope.userRegisterItems,true));
          var pswReg=/\S{6,}/;

        if($scope.userRegisterItems.phone==""||$scope.userRegisterItems.password==""
            ||$scope.userRegisterItems.userType==""||$scope.userRegisterItems.validateCode==""
            ||$scope.userRegisterItems.rePassword==""){
            toaster.clear();
            toaster.pop('warning','提示','请将 * 要填写的信息填写完整');
            return false;
        }

        if($scope.userRegisterItems.userType=='1'){

            if($scope.userRegisterItems.username==""||$scope.userRegisterItems.usersex==""||$scope.userRegisterItems.useraddr==""){
                toaster.clear();
                toaster.pop('warning','提示','请将 * 要填写的信息填写完整');
                return false;
            }
            var registerUrl=ROOTCONFIG.basePath+"info/user/reg";
            $scope.registerParam={
                "username":$scope.userRegisterItems.username,
                "userSex":$scope.userRegisterItems.usersex,
                "userAddr":$scope.userRegisterItems.useraddr,
                "userType":$scope.userRegisterItems.userType,
                "phone":$scope.userRegisterItems.phone,
                "validateCode":$scope.userRegisterItems.validateCode,
                "password":$scope.userRegisterItems.password

            };

        }else if($scope.userRegisterItems.userType=='3'){

            var registerUrl=ROOTCONFIG.basePath+"info/user/regUser";
            $scope.registerParam={
                "userType":$scope.userRegisterItems.userType,
                "phone":$scope.userRegisterItems.phone,
                "validateCode":$scope.userRegisterItems.validateCode,
                "password":$scope.userRegisterItems.password
            };

        }

      //  console.log(angular.toJson($scope.userRegisterItems,true));
        console.log(!regPhone.test($scope.userRegisterItems.phone));

        /*if(!regPhone.test($scope.userRegisterItems.phone)){
            toaster.clear();
            toaster.pop('warning','提示','手机号格式不正确');
            return false;
          }else*/ if(!pswReg.test($scope.userRegisterItems.password)){
            toaster.clear();
            toaster.pop('warning','提示','密码格式不正确 ！');

            return false;
           }else if($scope.userRegisterItems.password!=$scope.userRegisterItems.rePassword){
            toaster.clear();
            toaster.pop('warning','提示','密码不一致！');

            return false;
        }

        console.log(angular.toJson($scope.registerParam,true));
        toaster.pop('wait','提示','正在注册，请稍等...',6000);
        urls.sendRequest('POST',angular.toJson($scope.registerParam),registerUrl,'').success(function(response){
            if(response.code==100){
                toaster.clear();
                toaster.pop('wait','提示','注册成功，正在跳转登录界面',6000);
                var goLogin=function(){
                    toaster.clear();
                    $state.go('index.login');
                }
                $timeout(goLogin,3000);
            }else{
                toaster.clear();
                toaster.pop('error','提示',response.msg)
            }
        });

    }

}]);