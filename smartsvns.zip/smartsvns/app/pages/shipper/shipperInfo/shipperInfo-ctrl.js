/**
 * Created by W on 2016/10/24.
 */
chuanyang.controller('shipperInfoCtrl',['$scope','urls','$localStorage','$rootScope',function($scope,urls,$localStorage,$rootScope){
    console.log($localStorage.chuanYangloginMessege);
    console.log($rootScope.userSettings.user);
    $scope.infoData={};
    $scope.userInfos=[];
    $scope.infoData.infoShow=true;
       $scope.switchShipper=function(flag){
            switch(flag){
                case 1:
                    $scope.infoData.infoShow=false;
                    break;
                case 2:
                    $scope.infoData.infoShow=true;
                    break;
            }

       };
    $scope.userInfos=angular.copy($localStorage.chuanYangloginMessege);

}]);