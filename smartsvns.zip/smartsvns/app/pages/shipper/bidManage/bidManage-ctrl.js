
/**
 * Created by W on 2016/12/28.
 */
'use strict';
chuanyang.controller('bidManageCtrl',['$scope',
    '$http',
    '$timeout',
    '$state',
    '$modal',
    '$log',
    '$filter',
    '$localStorage',
    'toaster',
    'urls',function($scope,
                    $http,
                    $timeout,
                    $state,
                    $modal,
                    $log,
                    $filter,
                    $localStorage,
                    toaster,
                    urls){
        $scope.isCollapsed=[];
        $scope.isSelected=[];
        $scope.currentPage = 1;
        $scope.pageSize = 5;//每页条数
        $scope.total = 0;
        $scope.noData=[];
        $scope.noDataFa=false;
        $scope.advancedOrderList=[];
        $scope.selectObjectList=[];
        $scope.advancedPeriodNo="";
        //预招标列表
        if($localStorage.chuanYangloginMessege == undefined){
            $state.go('index.login');
        }else{
            $scope.user_type = $localStorage.chuanYangloginMessege.userType;
        }
        $scope.advancedOrderListShow=function(){
            if( $scope.user_type==1){
                $scope.advancedOrderListParam={
                    "userId":$localStorage.chuanYangloginMessege.userId,
                    "state":$scope.state,
                    "page":$scope.currentPage,
                    "length":$scope.pageSize,
                    "advancedPeriodNo":$scope.advancedPeriodNo
                };
            }else if($scope.user_type==3){
                $scope.advancedOrderListParam={
                    "companyId":$localStorage.chuanYangloginMessege.companys[0].companyID,
                    "state":$scope.state,
                    "page":$scope.currentPage,
                    "length":$scope.pageSize,
                    "advancedPeriodNo":$scope.advancedPeriodNo
                };
            }

            console.log($scope.advancedOrderListParam);
            var advancedOrderListUrl=ROOTCONFIG.basePath +'info/AdvancedOrder/selectAdvancedOrder';
            urls.sendRequest('POST', angular.toJson($scope.advancedOrderListParam), advancedOrderListUrl, '').success(function (response) {
                if(response.code==100){
                    if(response.data.data.length!=0){
                        $scope.noDataFa=false;
                    }else{
                        $scope.noDataFa=true;
                    }
                    angular.copy(response.data.data,$scope.advancedOrderList);
                    $scope.total=response.data.total;
                    console.log($scope.advancedOrderList);
                    for(var i=0;i<response.data.data.length;i++){
                        $scope.isSelected[i]=[];
                        $scope.isCollapsed[i]=false;
                    }
                }
            })

        }



        $scope.chooseStatus=function(flag){
            if(flag==0){
                $scope.bidOrder=true;
                $scope.hadSelected=false;
                $scope.currentPage=1;
                $scope.state=0;
            }else{
                $scope.bidOrder=false;
                $scope.hadSelected=true;
                $scope.currentPage=1;
                $scope.state=2;
            }
            $scope.advancedOrderListShow();
        }
        $scope.chooseStatus(0);

        //查询
        $scope.refer=function(){
            $scope.advancedOrderListShow();
        };
//确认
        $scope.confirmObject=function(indexfa,data){
            $scope.advancedDriverIdlist=[];
            if(!$scope.selectObjectList[indexfa]){
                toaster.pop('warning','提示','你还未选择承运对象',3000);
                return;
            };

            for(var i=0;i<$scope.selectObjectList[indexfa].length;i++){
                if($scope.isSelected[indexfa][i]==true){
                    $scope.advancedDriverIdlist.push($scope.selectObjectList[indexfa][i].id);
                }
            }
             if($scope.advancedDriverIdlist.length===0){
                toaster.pop('warning','提示','你还未选择承运对象',3000);
                return;
             };

            $scope.items = {
                "title": "提示",
                "tips": "确认已经选择的承运对象？"
            }
            var modalInstance = $modal.open({
                templateUrl: 'pages/shipper/shipperModal.html',
                controller: 'bidManageModelCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                  var confirmObjectUrl = ROOTCONFIG.basePath + "info/AdvancedOrder/updateChoosedriver";
                  $scope.confirmObjectParam={
                      "advancedorderId":data.advancedorderId,
                      "advancedDriverIdlist":$scope.advancedDriverIdlist
                  };
                  console.log($scope.confirmObjectParam);
                urls.sendRequest('POST', angular.toJson($scope.confirmObjectParam),confirmObjectUrl, '').success(function (response) {
                    if(response.code==100){
                        $scope.advancedOrderListShow();
                        $scope.selectObject(indexfa,data.advancedorderId);
                        toaster.pop('success','提示','确认有效对象成功！',3000);
                    }else{
                        toaster.pop('error','提示',response.msg,3000)
                    }
                })
            })
        };
//作废
        $scope.deleteBidOrder=function(bidList){
            $scope.items = {
                "title": "提示",
                "tips": "确认作废？"
            }
            var modalInstance = $modal.open({
                templateUrl: 'pages/shipper/shipperModal.html',
                controller: 'bidManageModelCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                var deleteBidOrderUrl = ROOTCONFIG.basePath + "info/AdvancedOrder/updateAdvancedOrder";
                $scope.deleteBidOrderParam={
                        "id":bidList.advancedorderId,
                        "state":3
                };
                urls.sendRequest('POST', angular.toJson($scope.deleteBidOrderParam),deleteBidOrderUrl, '').success(function (response) {
                    if(response.code==100){
                        toaster.pop('success','提示','作废成功！',3000);
                        $scope.advancedOrderListShow();
                    }else{
                        toaster.pop('error','提示',response.msg,3000);
                    }
                })
            })
        };
//下拉列表
        $scope.selectObject=function(index,aoId,state,endTimes){
            toaster.clear();
            if(endTimes){
                var nowTimes = new Date();
                var foryears = nowTimes.getFullYear();
                var currenyDate = Date.parse(nowTimes);
                var endDate = Date.parse(foryears.toString().slice(0,2)+endTimes);
                if(currenyDate<=endDate){
                    toaster.pop('info','提示','竞标时间还未结束，暂不能查看！');
                    return;
                }
            }

            $scope.isCollapsed[index]=!$scope.isCollapsed[index];
            var selectObjectUrl=ROOTCONFIG.basePath +'info/AdvancedOrder/selectAdvancedDriver';
            $scope.selectObjectParam={
                "advancedorderId":aoId,
                "state":0
            };
            console.log($scope.selectObjectParam);
            if(!!aoId){
                urls.sendRequest('POST', angular.toJson($scope.selectObjectParam), selectObjectUrl, '').success(function (response) {
                    if(response.code==100){
                        if(response.data.length!=0){
                            $scope.noData[index]=false;
                        }else{
                            $scope.noData[index]=true;
                        }
                        $scope.selectObjectList[index]=angular.copy(response.data);
                        for(var i=0;i<$scope.advancedOrderList.length;i++){
                            for(var j=0;j<response.data.length;j++){
                                if($scope.isSelected[i][j]==true)continue;
                                $scope.isSelected[i][j]=false;
                            }
                        }
                    }
                })
            }
        }

        //选择司机
        $scope.transportSelect=function(driverId,indexFa,indexChild){
            $scope.isSelected[indexFa][indexChild]=!$scope.isSelected[indexFa][indexChild];

        }
//分页
        $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
            $scope.currentPage = page;
            $scope.advancedOrderListShow();
        };
    }])

//弹窗
chuanyang.controller('bidManageModelCtrl', ['$scope', '$modalInstance', 'items', 'urls', function ($scope, $modalInstance, items, urls) {
    $scope.items = items;
    $scope.add = function () {
        $scope.selected = items;
        console.log($scope.selected);
        $modalInstance.close($scope.selected);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);
