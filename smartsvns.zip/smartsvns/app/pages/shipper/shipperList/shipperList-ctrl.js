/**
 * Created by W on 2016/10/22.
 */
'use strict';

chuanyang.controller('shipperListCtrl', ['$scope', '$modal', '$localStorage', 'urls', '$filter', 'toaster','$timeout','$state', function ($scope, $modal, $localStorage, urls, $filter, toaster,$timeout,$state) {
    $scope.shipperLists = [];
    $scope.showDown = [];
    $scope.showUp = [];
    $scope.isCollapsed = [];
    $scope.noDataShow = false;
    $scope.noChildDataShow = [];
    $scope.orderDetailsList = [];
    $scope.person = {};
    $scope.person.disable = false;
    $scope.currentPage = 1;
    $scope.pageSize = 5;//每页条数
    $scope.total = 5;
    $scope.selPlateNumberShow = false;
    $scope.person.transportWays = [{"key": "1", "name": "车运订单"}, {"key": "2", "name": "船运订单"}];
    $scope.person.payStatusData = [{"key": "0", "name": "支付中"},{"key": "1", "name": "未支付"}, {"key": "2", "name": "已支付"}];
    if($localStorage.chuanYangloginMessege == undefined){
        $state.go('index.login');
    }
    if($localStorage.chuanYangloginMessege.userType==3){
        $state.go('home.allocationOrder');
    }
//日期
    $scope.cacleTask = function () {

    };
    $scope.today = function () {
        $scope.dt = new Date();
    };
    $scope.today();

    $scope.clear = function () {
        $scope.dt = null;
    };

    // Disable weekend selection
    $scope.disabled = function (date, mode) {
        return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
    };

    $scope.toggleMin = function () {
        $scope.minDate = $scope.minDate ? null : new Date();
    };
    $scope.toggleMin();


    $scope.open = function ($event) {
        $event.preventDefault();
        $event.stopPropagation();
        $scope.opened = true;
    };

    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1,
        class: 'datepicker',
        lang: 'zh-cn'
    };

    $scope.initDate = new Date('2016-15-20');
    $scope.formats = ['yyyy-MM-dd'];
    $scope.format = $scope.formats[0];


    $scope.allOrderStatus = [
        {"type": "0", "status": "待摘牌"},
        {"type": "1", "status": "待分配"},
        {"type": "2", "status": "待装货"},
        {"type": "3", "status": "装货中"},
        {"type": "4", "status": "运输中"},
        {"type": "5", "status": "卸货中"},
        {"type": "6", "status": "待确认"},
        {"type": "7", "status": "已完成"},
        {"type": "8", "status": "已取消"},
        {"type": "-1", "status": "已删除"},
        {"type": "-2", "status": "重新下单"},
        {"type": "-3", "status": "人工下单"},
        {"type": "-4", "status": "人工干预"}
    ];
    $scope.allOrder = true;
    $scope.routeOrder = false;
    $scope.finishOrder = false;
    $scope.changechoosed = function (flag) {
        switch (flag) {
            case 'all':
                $scope.person.orderNo = "";
                $scope.person.date = "";
                $scope.person.orderAddressStart = "";
                $scope.person.orderAddressEnd = "";
                $scope.person.name = "";
                $scope.person.number = "";
                $scope.allOrder = true;
                $scope.routeOrder = false;
                $scope.finishOrder = false;
                $scope.person.disable = false;
                $scope.currentPage = 1;
                $scope.shipperOrderShow();
                break;
            case '4':
                $scope.person.orderNo = "";
                $scope.person.date = "";
                $scope.person.orderAddressStart = "";
                $scope.person.orderAddressEnd = "";
                $scope.person.name = "";
                $scope.person.number = flag;
                $scope.allOrder = false;
                $scope.routeOrder = true;
                $scope.finishOrder = false;
                $scope.person.disable = true;
                $scope.currentPage = 1;
                $scope.shipperOrderShow();
                break;
            case '7':
                $scope.person.orderNo = "";
                $scope.person.date = "";
                $scope.person.orderAddressStart = "";
                $scope.person.orderAddressEnd = "";
                $scope.person.name = "";
                $scope.person.number = flag;
                $scope.allOrder = false;
                $scope.routeOrder = false;
                $scope.finishOrder = true;
                $scope.person.disable = true;
                $scope.currentPage = 1;
                $scope.shipperOrderShow();
                break;
        }
    };


    //订单展示
    $scope.shipperOrderShow = function () {
        $scope.shipperLists = [];
        $scope.hideLoading = false;
        var time = $filter('date')($scope.person.date, 'yyyy-MM-dd');
        $scope.shipperOrderParams = {};
        $scope.shipperOrderParams.userId = $localStorage.chuanYangloginMessege.userId;
        $scope.shipperOrderParams.page = $scope.currentPage;
        $scope.shipperOrderParams.length = $scope.pageSize;
        $scope.shipperOrderParams.order_time = time;
        $scope.shipperOrderParams.city = $scope.person.orderAddressStart;
        $scope.shipperOrderParams.endcity = $scope.person.orderAddressEnd;
        $scope.shipperOrderParams.transPortWay = $scope.person.transportWaySelect;
        $scope.shipperOrderParams.orderNo = $scope.person.orderNo;
        $scope.shipperOrderParams.order_status = $scope.person.number;
        $scope.shipperOrderParams.payStatus = $scope.person.payStatus;
        var shipperOrderUrl = ROOTCONFIG.basePath + "info/order/selectWebOrder";
        urls.sendRequest('POST', angular.toJson($scope.shipperOrderParams), shipperOrderUrl, '').success(function (response) {
            $scope.hideLoading = true;
            if (response.code == 100) {
                $scope.selPlateNumberShow = false;
                $scope.shipperLists = angular.copy(response.data.data);
                $scope.total = response.data.total;
                if ($scope.shipperLists == undefined) return false;
                for (var i = 0; i < $scope.shipperLists.length; i++) {
                    $scope.showDown[i] = true;
                    $scope.showUp[i] = false;
                    $scope.isCollapsed[i] = false;
                }

                if ($scope.shipperLists != 0) {
                    $scope.noDataShow = false;
                } else {
                    $scope.noDataShow = true;
                }
            } else {
                toaster.pop('error', '提示', response.msg);
            }
        })
    };
    $scope.shipperOrderShow();
//下拉数据
    $scope.showDetails = function (index, items,temp) {
         if(items.order_status == '0'){
         toaster.pop('info','提示','该条订单处于待摘牌阶段，你可以前往摘牌列表进行相关操作！');
         return;
         }

        $scope.isCollapsed[index] = !$scope.isCollapsed[index];

        if ($scope.isCollapsed[index] == true) {
            $scope.showDown[index] = false;
            $scope.showUp[index] = true;

            $scope.showDetailsParams = {};

            var showDetailsUrl = ROOTCONFIG.basePath + "info/order/selWebOrderWaybill";
            $scope.showDetailsParams.orderId = items.orderID;
            urls.sendRequest('POST', angular.toJson($scope.showDetailsParams), showDetailsUrl, '').success(function (response) {
                if (response.code == 100) {
                    console.log(angular.toJson(response, true) + "123");
                    $scope.orderDetailsList[items.orderID] = angular.copy(response.data);
                    if ($scope.orderDetailsList[items.orderID].length != 0) {
                        $scope.noChildDataShow[index] = false;
                    } else {
                        $scope.noChildDataShow[index] = true;
                    }
                }

            })

        }else{
            $scope.showDown[index] = true;
            $scope.showUp[index] = false;
        }

    };

    //修改货单
    $scope.updateTrainOrder = function (trainOrder,indexFa,itemFa) {
        var modalInstance = $modal.open({
            templateUrl: 'pages/shipper/shipperList/updateOrderDetail.html',
            controller: 'updateOrderDetailCtrl',
            size:'lg',
            resolve: {
                trainOrder : function () {
                    return trainOrder;
                }
            }
        });
        modalInstance.result.then(function (selectedItem) {
            //$scope.showDetails(indexFa,itemFa,temp);
            $scope.showDetailsParams = {};
            var showDetailsUrl = ROOTCONFIG.basePath + "info/order/selWebOrderWaybill";
            $scope.showDetailsParams.orderId = itemFa.orderID;
            urls.sendRequest('POST', angular.toJson($scope.showDetailsParams), showDetailsUrl, '').success(function (response) {
                if (response.code == 100) {
                    $scope.orderDetailsList[itemFa.orderID] = angular.copy(response.data);
                }

            })
        }, function () {
            //$log.info('Modal dismissed at: ' + new Date());
        });

    };
//导入
    $scope.importGoods=function(datas,indexFa,itemFa){
        var modalInstance = $modal.open({
            templateUrl: 'pages/shipper/shipperList/importGoods.html',
            controller: 'importGoodsCtrl',
            size:'lg',
            resolve: {
               items: function () {
                   return datas;
               }
            }
        });
        modalInstance.result.then(function () {
            $scope.showDetailsParams = {};
            var showDetailsUrl = ROOTCONFIG.basePath + "info/order/selWebOrderWaybill";
            $scope.showDetailsParams.orderId = itemFa.orderID;
            urls.sendRequest('POST', angular.toJson($scope.showDetailsParams), showDetailsUrl, '').success(function (response) {
                if (response.code == 100) {
                    $scope.orderDetailsList[itemFa.orderID] = angular.copy(response.data);
                }

            })
        });
    }
    //查看订单详情
    $scope.getOrderDetails = function (data) {
        $scope.items = {
            "orderId": data.orderID
        }
        var modalInstance = $modal.open({
            templateUrl: 'pages/shipper/shipperList/shipperOrderDetail.html',
            controller: 'shipperModelCtrl',
            size: 'lg',
            resolve: {
                items: function () {
                    return $scope.items;
                }
            }
        });
    };

    //查看位置信息
    $scope.getMapLocation = function (flag, ez) {
        sessionStorage.removeItem('lnglat');
        $scope.items = {
            "title": "位置信息",
            "orderId": flag,
            "ez": ez
        }
        var modalInstance = $modal.open({
            templateUrl: 'pages/shipper/mapLocation.html',
            controller: 'mapLocationCtrl',
            size: 'lg',
            resolve: {
                items: function () {
                    return $scope.items;
                }
            }
        });
    }
//查看船
    $scope.getShipLocation=function(dataShip){
        $scope.items={
            "title":"船只信息",
            "frameNumber":dataShip
        }
        var modalInstance=$modal.open({
            templateUrl: 'pages/shipper/shipLocation.html',
            controller: 'shipLocationModelCtrl',
            size:'lg',
            resolve: {
                items: function () {
                    return $scope.items;
                }
            }
        });
    };
    //查看图片
    $scope.goPicture = function (trainOrder) {
        var modalInstance = $modal.open({
            templateUrl: 'pages/shipper/shipperList/shipperOrderPicModal.html',
            controller: 'shipperOrderPicController',
            scope: $scope,
            resolve: {
                orderPictureInfos: function () {
                    return trainOrder;
                }
            }
        });
    }

    //确认订单收货
    $scope.confirmOrder = function (item) {
        $scope.items = {
            "title": "提示",
            "tips": "确定收货？"
        }
        var modalInstance = $modal.open({
            templateUrl: 'pages/shipper/shipperModal.html',
            controller: 'commonModelCtrl',
            resolve: {
                items: function () {
                    return $scope.items;
                }
            }
        });
        modalInstance.result.then(function (selectedItem) {
            var urlConfirmOrder = ROOTCONFIG.basePath + "info/order/signoff";
            var getConfirmOrder = {
                orderId: item.orderID,
                orderStatus: 7
            };
            console.log(angular.toJson(getConfirmOrder));
            urls.sendRequest('POST', angular.toJson(getConfirmOrder), urlConfirmOrder, '').success(function (response) {
                if (ROOTCONFIG.debug) {
                    console.log((response));
                }
                if (response.code == '100') {
                    toaster.pop('success', '提示', "收货成功");
                    $scope.shipperOrderShow();
                } else if (response.code = '101') {
                    toaster.pop('waring', '提示', response.msg);
                } else if (response.code = '110') {
                }
            });
        })
    }

    //确认运单收货
    $scope.confirmTrainOrder = function (item) {
        $scope.items = {
            "title": "提示",
            "tips": "确定收货？"
        }
        var modalInstance = $modal.open({
            templateUrl: 'pages/shipper/shipperModal.html',
            controller: 'commonModelCtrl',
            resolve: {
                items: function () {
                    return $scope.items;
                }
            }
        });
        modalInstance.result.then(function (selectedItem) {
            var urlConfirmOrder = ROOTCONFIG.basePath + "info/driverOrder/updateWaybillStatus";
            var getConfirmOrder = {
                waybillId: item.waybillId,
                waybillStatus: 7
            };
            console.log(angular.toJson(getConfirmOrder));
            urls.sendRequest('POST', angular.toJson(getConfirmOrder), urlConfirmOrder, '').success(function (response) {
                if (ROOTCONFIG.debug) {
                    console.log((response));
                }
                if (response.code == '100') {
                    toaster.pop('success', '提示', "收货成功");
                    $scope.shipperOrderShow();
                } else if (response.code = '101') {
                    toaster.pop('waring', '提示', response.msg);
                } else if (response.code = '110') {
                }
            });
        })
    }

//查询
    $scope.refer = function () {
        $scope.currentPage = 1;
        if ($scope.person.plateNumber) {
            var shipperPlateNumberUrl = ROOTCONFIG.basePath + "info/order/selPlateNumber";
            $scope.shipperPlateNumberParam = {
                "plateNumber": $scope.person.plateNumber,
                "userId": $localStorage.chuanYangloginMessege.userId.toString()
            };
            urls.sendRequest('POST', angular.toJson($scope.shipperPlateNumberParam), shipperPlateNumberUrl, '').success(function (response) {
                $scope.hideLoading = true;

                if (response.code == 100) {
                    console.log(angular.toJson(response, true));
                    $scope.shipperLists = angular.copy(response.data.webOrderUserList);
                    $scope.person.hadSunWeight = response.data.sumGoodsWeight - response.data.sumSurplusWeigth;
                    $scope.person.sumSurplusWeigth = response.data.sumSurplusWeigth;
                    $scope.selPlateNumberShow = true;
                    $scope.total = 0;

                    if ($scope.shipperLists == undefined) return false;
                    for (var i = 0; i < $scope.shipperLists.length; i++) {
                        $scope.showDown[i] = true;
                        $scope.showUp[i] = false;
                        $scope.isCollapsed[i] = false;
                    }
                    if ($scope.shipperLists != 0) {
                        $scope.noDataShow = false;
                    } else {
                        $scope.noDataShow = true;
                    }
                } else {
                    toaster.pop('warning', '提示', response.msg);
                }
            })
        } else {
            $scope.shipperOrderShow();
        }

    }

    //分页
    $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
        $scope.currentPage = page;
        $scope.shipperOrderShow($scope.currentPage);
        console.log(page);
        console.log(pageSize);
    };
}]);

//弹窗控制器
chuanyang.controller('shipperModelCtrl', ['$scope', '$modalInstance', 'items', 'urls', function ($scope, $modalInstance, items, urls) {
    $scope.items = items;
    $scope.noDriver = true;
    $scope.serivce = true;
    $scope.noTransPortType = true;
    $scope.add = function () {
        $scope.selected = items;
        console.log($scope.selected);
        $modalInstance.close($scope.selected);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    //订单详情
    $scope.singleOrderDetails = [];

    var getSingleOrderUrl = ROOTCONFIG.basePath + "info/order/selOrderUsernfd";
    $scope.getSingleOrderParam = {
        "orderId": $scope.items.orderId
    };
    console.log(angular.toJson($scope.getSingleOrderParam));
    urls.sendRequest('POST', angular.toJson($scope.getSingleOrderParam), getSingleOrderUrl, '').success(function (response) {
        if (response.code == 100) {
            console.log('%c' + angular.toJson(response, true), ['color:#f00'].join(','));
            $scope.singleOrderDetails = angular.copy(response.data[0]);
            if (response.data[0].transPortWay == "" || response.data[0].transPortWay == undefined) {
                $scope.noTransPortType = true;
            } else {
                $scope.noTransPortType = false;
            }
        }
    })
}]);

//位置弹窗
chuanyang.controller('mapLocationCtrl', ['$scope', '$modalInstance', 'items', 'urls', 'toaster', function ($scope, $modalInstance, items, urls, toaster) {
    $scope.items = items;
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.getLnglatXY = function () {
        if ($scope.items.ez == 'order') {
            var getLnglatUrl = ROOTCONFIG.basePath + "info/GPS/GetCarCurrentStatusByOrderId";
            var getLnglatParam = {
                "orderId": $scope.items.orderId
            };
        } else if ($scope.items.ez == 'wayBill') {
            var getLnglatUrl = ROOTCONFIG.basePath + "info/GPS/GetCarCurrentStatusByWaybillId";
            var getLnglatParam = {
                "driverId": $scope.items.orderId
            };
        }
        //
        function loactionAddrShow(lnglatXY,lnglatData,map,resultAddress){
            var infoWindow = new AMap.InfoWindow({offset: new AMap.Pixel(0, -30)});
            for (var j = 0, marker; j < lnglatXY.length; j++) {
                var marker = new AMap.Marker({
                    position: lnglatXY[j],
                    map: map
                });
                if(resultAddress){
                    var addrMessage= '<div class="m-t"><b class="m-r-xs">地址:</b>' + resultAddress+ '</div>';
                }else{
                    var addrMessage='';
                }
                marker.content = '<div><b class="m-r-xs">车牌:</b>' + lnglatData[j].carMark+ '</div>' +addrMessage;
                marker.emit('click', {target: marker});
                marker.on('click', function markerClick(e) {
                    infoWindow.setContent(e.target.content);
                    infoWindow.open(map, e.target.getPosition());
                });
            }
            map.setFitView();
        };
        //
        urls.sendRequest('POST', angular.toJson(getLnglatParam), getLnglatUrl, '').success(function (response) {
            if (response.code == 100) {
                console.log(response);
                $scope.lnglatData = angular.copy(response.data);//地图上所标点的坐标
                console.log('%c' + $scope.lnglatData, ['color:#f00'].join(','));
                setTimeout(function () {
                    var map = new AMap.Map('container', {
                        resizeEnable: true
                        //zoom:11
                    });
                    var lnglatXY = [];
                    $scope.locationAddrs = [];
                    for (var i = 0; i < $scope.lnglatData.length; i++) {
                        var temp = [];
                        temp.push($scope.lnglatData[i].last_lon);
                        temp.push($scope.lnglatData[i].last_lat);
                        lnglatXY.push(temp);
                    }
                    console.log(lnglatXY);

                    function getOrderLocation() {
                        if ($scope.items.ez == 'order') {

                            loactionAddrShow(lnglatXY,$scope.lnglatData,map);

                        }else if ($scope.items.ez == 'wayBill') {
                            var geocoder = new AMap.Geocoder({
                                radius: 1000,
                                extensions: "all"
                            });
                            //地理编码
                            geocoder.getAddress(lnglatXY[0], function(status, result) {
                                if (status === 'complete' && result.info === 'OK') {
                                    loactionAddrShow(lnglatXY,$scope.lnglatData,map,result.regeocode.formattedAddress);
                                }else{
                                    loactionAddrShow(lnglatXY,$scope.lnglatData,map);
                                }
                            })

                        }
                    };

                    getOrderLocation();

                }, 1000)
                //
            } else {
                setTimeout(function () {
                    var map = new AMap.Map('container', {
                        resizeEnable: true
                        //zoom:11
                    });
                }, 1000);
                toaster.pop('error', '提示', response.msg || '没有查到相关的位置信息');
            }

        })
    }
    $scope.getLnglatXY();

}]);


//查看图片
chuanyang.controller('shipperOrderPicController', ['$scope', '$state', 'toaster', '$filter', 'urls', '$localStorage', 'orderPictureInfos', '$modalInstance', '$modal',
    function ($scope, $state, toaster, $filter, urls, $localStorage, orderPictureInfos, $modalInstance, $modal) {
        $scope.orderPictureInfos = orderPictureInfos;
        $scope.confirm = function () {
            $modalInstance.dismiss('cancel');
        }
        $scope.bigPicture = function (img) {
            var modalInstance = $modal.open({
                templateUrl: 'pages/shipper/shipperList/shipperOrderBigPic.html',
                controller: 'shipperOrderBigPicController',
             //   size: 'lg',
                scope: $scope,
                resolve: {
                    orderBigPictureInfos: function () {
                        return img;
                    }
                }
            });
        }
    }]);
//大图片
chuanyang.controller('shipperOrderBigPicController', ['$scope', '$state', 'toaster', '$filter', 'urls', '$localStorage', 'orderBigPictureInfos', '$modalInstance', '$modal',
    function ($scope, $state, toaster, $filter, urls, $localStorage, orderBigPictureInfos, $modalInstance, $modal) {
        $scope.img = orderBigPictureInfos;
        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);

//弹窗控制器
chuanyang.controller('commonModelCtrl', ['$scope', '$modalInstance', 'items', 'urls', function ($scope, $modalInstance, items, urls) {
    $scope.items = items;
    $scope.add = function () {
        $scope.selected = items;
        console.log($scope.selected);
        $modalInstance.close($scope.selected);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);

//修改货单
chuanyang.controller('updateOrderDetailCtrl', ['$scope', '$modalInstance', 'trainOrder', '$localStorage', 'urls', 'toaster', function ($scope, $modalInstance, trainOrder, $localStorage, urls, toaster) {
    $scope.aboutdetails = angular.copy(trainOrder.aboutdetails);
    for(var i=0;i<$scope.aboutdetails.length;i++){
        $scope.aboutdetails[i].deleteId = guUUID();
    }
    console.log($scope.aboutdetails);
    $scope.confirm = function () {
        if($scope.aboutdetails.length==0){
            $modalInstance.dismiss('cancel');
            return;
        }
        var urlTransportation = ROOTCONFIG.basePath + "info/waybill/updateWaybillDetailByZHJ";
        var getDetail =
        {
            "plateNumber":trainOrder.plateNumber,
            "waybillNo" : trainOrder.waybillNo,
            "waybillId" : trainOrder.waybillId,
            "entruckingStatus": trainOrder.waybillStatus,
            "orderDetails":[]
        }
        for(var i=0;i<$scope.aboutdetails.length;i++){
            getDetail.orderDetails.push(
                {
                    "blastNo":$scope.aboutdetails[i].blastNo,
                    "goodsMaterial":$scope.aboutdetails[i].goodsMaterial,
                    "goodsName":$scope.aboutdetails[i].goodsName,
                    "goodsNo":$scope.aboutdetails[i].goodsNo,
                    "goodsNum":$scope.aboutdetails[i].detailsNum,
                    "goodsOrigin":$scope.aboutdetails[i].goodsOrigin,
                    "goodsStandard":$scope.aboutdetails[i].goodsStandard,
                    "goodsUnit":$scope.aboutdetails[i].goodsUnit,
                    "goodsWeight":$scope.aboutdetails[i].detailsWeight,
                    "outDoorNo":$scope.aboutdetails[i].blastNo
                }
            );
        }
        urls.sendRequest('POST', angular.toJson(getDetail), urlTransportation, '').success(function (response) {
            if (ROOTCONFIG.debug) {
                console.log((response));
            }
            if (response.code == '100') {
                toaster.pop('success', '提示', '修改成功!');
                $modalInstance.close($scope.items);
            } else if (response.code = '101') {
                 toaster.pop('error','提示',response.msg,3000);
            } else if (response.code = '110') {
                 toaster.pop('error','提示',response.msg,3000);
            }
        });
    };
    $scope.cancel = function () {
        $modalInstance.dismiss();
    }
    $scope.config = {

    }
    $scope.modifyGoods = function(item){
        $scope.config = {
            goodsNo : item.goodsNo,
            goodsName : item.goodsName,
            goodsStandard : item.goodsStandard,
            detailsNum : item.detailsNum,
            detailsWeight : item.detailsWeight,
            goodsUnit : item.goodsUnit,
            goodsOrigin : item.goodsOrigin,
            goodsMaterial : item.goodsMaterial,
            blastNo : item.blastNo,
            deleteId : item.deleteId
        };
    }
    $scope.updateTrainOrder = function(){
        if(!$scope.config.goodsName||!$scope.config.detailsNum||!$scope.config.detailsWeight){
            toaster.pop('warning','提示','品名,数量，重量不能为空！',3000);
            return;
        }
        if(isEmpty($scope.config.deleteId) || $scope.config.deleteId == undefined){
            $scope.aboutdetails.push({
                goodsNo : $scope.config.goodsNo,
                goodsName : $scope.config.goodsName,
                goodsStandard : $scope.config.goodsStandard,
                detailsNum : $scope.config.detailsNum,
                detailsWeight : $scope.config.detailsWeight,
                goodsUnit : $scope.config.goodsUnit,
                goodsOrigin : $scope.config.goodsOrigin,
                goodsMaterial : $scope.config.goodsMaterial,
                blastNo : $scope.config.blastNo,
                deleteId : guUUID()
            });
        }else{
            for(var i=0;i<$scope.aboutdetails.length;i++){
                if($scope.aboutdetails[i].deleteId == $scope.config.deleteId){
                    $scope.aboutdetails[i] = {
                        goodsNo : $scope.config.goodsNo,
                        goodsName : $scope.config.goodsName,
                        goodsStandard : $scope.config.goodsStandard,
                        detailsNum : $scope.config.detailsNum,
                        detailsWeight : $scope.config.detailsWeight,
                        goodsUnit : $scope.config.goodsUnit,
                        goodsOrigin : $scope.config.goodsOrigin,
                        goodsMaterial : $scope.config.goodsMaterial,
                        blastNo : $scope.config.blastNo,
                        deleteId : $scope.aboutdetails[i].deleteId
                    }
                }
            }
        }
        $scope.config ={};
    }
    $scope.delete = function(item){
        for(var i=0;i<$scope.aboutdetails.length;i++){
            if(item.deleteId == $scope.aboutdetails[i].deleteId){
                $scope.aboutdetails.splice(i,1);
            }
        }
    }
}]);

//弹窗控制器
chuanyang.controller('importGoodsCtrl', ['$scope', '$modalInstance','items','toaster', 'urls', function ($scope, $modalInstance,items,toaster, urls) {

    $scope.getGoodsInventory=[];
    $scope.isCollapsed=[];
    $scope.importGoodsInfo=[];
    $scope.hadSelect=[];
    $scope.plateNumber="";
    $scope.mainListingNumber="";
    $scope.orderItemNum="";
    $scope.waybillNew="";
    $scope.getGoodsInventoryList=function() {
        var getGoodsInventoryUrl = ROOTCONFIG.basePath + "info/waybill/getAllInventory";
        $scope.getGoodsInventoryParam = {
            "plateNumber": $scope.plateNumber,
            "mainListingNumber": $scope.mainListingNumber,
            "orderItemNum": $scope.orderItemNum
        };
        urls.sendRequest('POST', angular.toJson($scope.getGoodsInventoryParam), getGoodsInventoryUrl, '').success(function (response) {
            console.log(response);
            if (response.code == 100) {
                if(response.data.length==0){
                    toaster.pop('info','提示','没有查询到数据！',3000);
                }
                angular.copy(response.data, $scope.getGoodsInventory);
                for (var i = 0; i < response.data.length; i++) {
                    $scope.hadSelect[i] = true;
                }
            }else{
                $scope.getGoodsInventory=[];
                toaster.pop('error','提示',response.msg);
            }
        });
    };
    $scope.getGoodsInventoryList();
    $scope.refer=function(){
        $scope.getGoodsInventoryList();
    }
    //单选
    $scope.goodsSelect=function(index,data,flag){
        if(flag!=1){
            $scope.waybillNew=data.waybillId;
            for (var i = 0; i < $scope.getGoodsInventory.length; i++) {
                $scope.hadSelect[i] = true;
            }

        }else{
            $scope.waybillNew="";
        }
        $scope.hadSelect[index]=!$scope.hadSelect[index];

    }

    $scope.goodInfoShow=function(index,data){
        $scope.isCollapsed[index]=!$scope.isCollapsed[index];
        var goodInfoUrl=ROOTCONFIG.basePath + "info/waybill/selectByWaybillId";
        $scope.goodInfoParam={
            "waybillId":data.waybillId
        };
        if($scope.isCollapsed[index]==true){
            urls.sendRequest('POST', angular.toJson($scope.goodInfoParam),goodInfoUrl, '').success(function (response) {
                if(response.code==100){
                    console.log(response);
                    $scope.importGoodsInfo[index] = angular.copy(response.data.data);
                }
            })
        }
    }



    $scope.confirmImport=function(){
        var importGoodsUrl= ROOTCONFIG.basePath + "info/waybill/bindInventory";
        $scope.importGoodsParam={
            "waybillOld":items.waybillId,
            "waybillNew": $scope.waybillNew
        };
        if($scope.waybillNew==''){
            toaster.pop('warning','提示','请先选择要导入的货品！',3000);
            return;
        }
        urls.sendRequest('POST', angular.toJson($scope.importGoodsParam),importGoodsUrl, '').success(function (response) {
               if(response.code==100){
                   toaster.pop('success','提示','导入成功！',3000);
                   $modalInstance.close();
               }else{
                   toaster.pop('error','提示',response.msg,3000);
               }
        })
    }
}]);
