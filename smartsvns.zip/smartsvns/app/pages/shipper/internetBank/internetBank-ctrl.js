/**
 * Created by W on 2017/2/8.
 */
'use strict'
chuanyang.controller('internetBankCtrl',['$scope','$rootScope','$modal','$localStorage','$sessionStorage','$timeout','urls','$filter','toaster','$state','$cookieStore',
    function($scope,$rootScope,$modal,$localStorage,$sessionStorage,$timeout,urls,$filter,toaster,$state,$cookieStore){
        if($localStorage.chuanYangloginMessege == undefined){
            $state.go('index.login');
        }else{
            $scope.user_type = $localStorage.chuanYangloginMessege.userType;
        };
        if( $scope.user_type==1){
            $scope.dealInfo={
                type : true
            };
        }else if($scope.user_type==3) {
            $scope.dealInfo = {
                type: false
            };
        };

        $scope.SubOrderInfo = $cookieStore.get('subOrderInfo');
        $scope.currencyInfo = $cookieStore.get('currencyInfo');
        if(!$scope.SubOrderInfo){
            if( $scope.user_type==1){
                $state.go('home.unpayOrder');
            }else if($scope.user_type==3) {
                $state.go('home.unpayOrderList');
            };
            return;
        };
        $scope.orderDetailInfo = [];
        angular.copy($localStorage.chuanYangloginMessege.orderInfo,$scope.orderDetailInfo);

        $scope.confirmPayMoney=function(){
            var bank_open_url = ROOTCONFIG.basePath + "BocPaymentSample/ReqNB2BRecvOrder?orderNo=" + $scope.SubOrderInfo.paymentOrderNo + "&currency=" + 156
                + "&amount=" + parseInt($scope.SubOrderInfo.amount*100) + "&orderTime=" + $scope.SubOrderInfo.paymentOrderNo.slice(0,14) + "&orderNote=" + $scope.currencyInfo.remark;

            window.open(bank_open_url);

            if( $scope.user_type==1){
                $state.go('home.unpayOrder');
            }else if($scope.user_type==3) {
                $state.go('home.unpayOrderList');
            };
        };

    }])