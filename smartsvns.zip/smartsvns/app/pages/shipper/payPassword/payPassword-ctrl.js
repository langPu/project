/**
 * Created by W on 2016/12/16.
 */
'use strict'
chuanyang.controller('payPswCtrl',['$scope','$modal','$localStorage','urls','$filter','toaster','$state',
    function($scope,$modal,$localStorage,urls,$filter,toaster,$state){
        $scope.setPayPsw=function(){
            var regPswValue=/^\S{6}$/;
            if(!$scope.pswValue||!$scope.rePswValue){
                toaster.pop('warning','提示','密码不能为空!',3000);
                return;
            }
            if(!regPswValue.test($scope.pswValue)){
                toaster.pop('warning','提示','密码格式不正确!',3000);
                return;
            };
            if($scope.pswValue!=$scope.rePswValue){
                toaster.pop('warning','提示','密码不一致!',3000);
                return;
            };

            var setPayPswUrl=ROOTCONFIG.basePath+"info/account/setPayPassword";
            $scope.setPayPswParam={
                "custId":$localStorage.chuanYangloginMessege.custId,
                "accountType":$localStorage.chuanYangloginMessege.accountType,
                "payPassword":$scope.pswValue
            };
            console.log(angular.toJson($scope.setPayPswParam));
            toaster.pop('info','提示','正在设置支付密码...',3000);
            urls.sendRequest('POST', angular.toJson($scope.setPayPswParam), setPayPswUrl, '').success(function (response) {
                toaster.clear();
                console.log(response);
                if(response.code==100){
                    toaster.pop('info','提示','设置支付密码成功!',3000);
                    $state.go('home.orderPay');
                }else{
                    toaster.pop('info','提示',response.msg||'设置支付密码失败!',3000);
                }
            })

        }

    }])