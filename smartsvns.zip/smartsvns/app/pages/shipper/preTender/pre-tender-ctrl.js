/**
 * Created by fangqiang on 16/12/28.
 */
angular.module('chuanyang').controller('preTenderController', preTenderController);
preTenderController.$inject = ['$scope', '$http', '$state', '$localStorage', 'urls', '$modal', 'toaster'];
function preTenderController($scope,
                             $http,
                             $state,
                             $localStorage,
                             urls,
                             $modal,
                             toaster) {

    var vm = this;
    if($localStorage.chuanYangloginMessege == undefined){
        $state.go('index.login');
    }else{
        vm.localSessions = $localStorage.chuanYangloginMessege
    }
    vm.params = {
        "transPortWay": 1,
        "currency": 1
    };
    vm.sendPreTender = function () {
        vm.items = {
            "title": "确认发送预招标单?",
            "data": [
                {type: 'sendPre', filter: 'text'}

            ]

        };
        var modalInstance = $modal.open({
            templateUrl: 'changeConpany.html',
            controller: 'repeatModelCtrl',
            size: 'small',
            resolve: {
                items: function () {
                    return vm.items;
                }
            }
        });
        modalInstance.result.then(function (selectedItem) {
            console.log(angular.toJson(vm.params, true));
            vm.params.userId = vm.localSessions.userId;
            vm.params.state = 1;
            if (vm.localSessions.userType == 3){
                vm.params.companyId = vm.localSessions.companys[0].companyID;
            }
            vm.params.advancedPeriodNo =vm.localSessions.userId  + '-'+ vm.params.advancedPeriodNos;
            var url = ROOTCONFIG.basePath4 + "info/AdvancedOrder/addAdvancedOrder";
            if(vm.params.order_startime > vm.params.order_endtime){
                toaster.pop('warning', '提示', '起始时间不能够在终止时间之前');

            }else {
                toaster.pop('wait', '提示', '正在发送',60000);
                urls.sendRequest('POST', angular.toJson(vm.params), url, '').success(function (response) {
                    toaster.clear();
                    if (response.code == "100") {
                        console.log(angular.toJson(response, true));
                        toaster.pop('success', '提示', '发送成功');

                    } else {
                        toaster.pop('error', '提示', '发送失败');

                    }
                }).error(function () {
                    toaster.clear();
                    toaster.pop('error', '提示', '发送失败');


                });
            }
        }, function () {
        });
        console.log("发送预招标单");
    }
}
