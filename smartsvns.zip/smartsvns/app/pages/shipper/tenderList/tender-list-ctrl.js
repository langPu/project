/**
 * Created by fangqiang on 17/1/12.
 */
angular.module('chuanyang').controller('tenderListController', tenderListController);
tenderListController.$inject = ['$scope', '$http', '$state', '$localStorage', 'urls', '$modal', 'toaster'];
function tenderListController($scope,
                              $http,
                              $state,
                              $localStorage,
                              urls,
                              $modal,
                              toaster) {
    var vm = this;
    if ($localStorage.chuanYangloginMessege == undefined) {
        $state.go('index.login');
    } else {
        vm.localSessions = $localStorage.chuanYangloginMessege
    }
    vm.params = {};
    vm.params.state = 0;
    vm.page = 1;
    vm.length = 10;
    vm.mailsChilds = [];
    vm.isCollapsed = [];
    vm.tenderState = [
        {'key': 0, 'name': '所有状态'},
        {'key': 1, 'name': '初始化'},
        {'key': 2, 'name': '已选择'}
    ];
    vm.allTenders = [];
    vm.selectAdvancedOrder = function () {
        $scope.hideLoading = false;
        vm.allTenders = [];
        vm.mailsChilds = [];
        vm.isCollapsed = [];
        if (vm.localSessions.userType == 3) {
            vm.params.companyId = vm.localSessions.companys[0].companyID;
        } else {
            vm.params.userId = vm.localSessions.userId;
        }
        vm.params.page = vm.page;
        vm.params.length = vm.length;
        var url = ROOTCONFIG.basePath + 'info/AdvancedOrder/selectAdvancedOrder';
        toaster.pop('wait', '提示', '正在查找', 60000);
        urls.sendRequest('POST', angular.toJson(vm.params), url, '').success(function (response) {
            $scope.hideLoading = true;
            toaster.clear();
            if (response.code == "100") {
                console.log(angular.toJson(response, true));
                angular.copy(response.data.data, vm.allTenders);
                if (response.data.data[0] == undefined) {
                    toaster.pop('info', '提示', '没有数据');

                }
                if (response.data.data.length <= 4) {
                    angular.element("#motorcadeList").css('height', '500px');
                } else {
                    angular.element("#motorcadeList").css('height', 'auto');
                }
                vm.total = response.data.total;
                vm.totalPages = response.data.totalPages;

            } else {
                toaster.pop('error', '提示', '查找失败');

            }
        }).error(function () {
            $scope.hideLoading = true;
            toaster.clear();
            toaster.pop('error', '提示', '查找失败');
        });
    };
    vm.selectAdvancedOrder();
    vm.doCtrlPagingAct = function (pageClink, page, pageSize, total) {
        vm.page = page;
        vm.selectAdvancedOrder();
    };

    vm.labelClass = function (label) {
        return {
            'b-l-primary': label == '1',
            'b-l-success': label == '2' || label == '3' || label == undefined
        };
    };
    $scope.selectMotorMember = function (index, motorMember) {//车队成员
        if (vm.isCollapsed[index] == true) {

        } else if (vm.isCollapsed[index] == false) {
            vm.isCollapsed[index] = !vm.isCollapsed[index];
        } else {
            vm.mailsChilds[index] = [];
            vm.isCollapsed[index] = !vm.isCollapsed[index];
            var selectMemberUrl = ROOTCONFIG.basePath4 + "info/order/getOrderByAdvancedOrder";
            var params = {};
            params.advancedOrderId = motorMember.advancedorderId;
            urls.sendRequest('POST', angular.toJson(params), selectMemberUrl, '').success(function (response) {
                console.log(angular.toJson(response, true));
                if (response.code == '101') {
                } else if (response.code == '100') {
                    angular.copy(response.data, vm.mailsChilds[index]);
                }
            }).error(function (status) {
            });
        }
    };

    vm.statusReturn = function (orderStatus) {
        switch (orderStatus) {
            case '0':
                return "初始化";
                break;
            case '2':
                return "待装货";
                break;
            case '3':
                return "装货中";
                break;
            case '4':
                return "运输中";
                break;
            case '5':
                return "卸货中";
                break;
            case '6':
                return "待收货";
                break;
            case '7':
                return "已完成";
                break;
            case '1':
                return "待分配";
                break;
            case undefined:
                return "无状态";
                break;

        }
    };

    vm.selectWills = function (list) {
        console.log(angular.toJson(list, true));
        var url = ROOTCONFIG.basePath + 'info/order/selectWaybill';
        var params = {
            'orderId': list.orderID
        };
        toaster.pop('wait', '提示', '正在查找', 60000);
        urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {
            toaster.clear();
            if (response.code == "100") {
                console.log(angular.toJson(response, true));
                if (response.data[0] == undefined) {
                        toaster.pop('info', '提示', '没有运单');
                    }else{
                    $scope.items = {
                        "title": "查看运单",
                        "name": "查看运单",
                        'data': response.data
                    };
                    var modalInstance = $modal.open({
                        templateUrl: 'selectWaybills.html',
                        controller: 'selectWaybillsController',
                        resolve: {
                            items: function () {
                                return $scope.items;
                            }
                        }
                    });
                    modalInstance.result.then(function (selectedItem) {

                    }, function () {
                    });

                }
            } else {
                toaster.pop('error', '提示', '查找失败');

            }
        }).error(function () {
            toaster.clear();
            toaster.pop('error', '提示', '查找失败');
        });
    }
}
//总模板
angular.module('chuanyang').controller('selectWaybillsController', ['$scope', '$modalInstance', 'items', function ($scope, $modalInstance, items) {
    $scope.items = items;
    $scope.params = {};
    $scope.params.labels = function (orderStatus) {
        switch (orderStatus) {
            case 0:
                return "初始化";
                break;
            case 2:
                return "待装货";
                break;
            case 3:
                return "装货中";
                break;
            case 4:
                return "运输中";
                break;
            case 5:
                return "卸货中";
                break;
            case 6:
                return "待收货";
                break;
            case 7:
                return "已完成";
                break;
            case -1:
                return "运单异常";
                break;
            case undefined:
                return "无状态";
                break;

        }
    };
    $scope.add = function () {
        $scope.selected = items;
        $modalInstance.close($scope.selected);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);