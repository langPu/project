/**
 * Created by W on 2016/11/9.
 */
'use strict'
chuanyang.controller('orderBoardCtrl',['$scope','$modal','$localStorage','urls','$filter','toaster',
    function($scope,$modal,$localStorage,urls,$filter,toaster){
        $scope.allOrderStatus=[{"type":"1","status":"竞价单"},{"type":"2","status":"匹配单"}];
        $scope.doingOrder=true;
        $scope.cancelOrder=false;
        $scope.person={};
        $scope.showDown=[];
        $scope.showUp=[];
        $scope.noDataShow=false;
        $scope.isCollapsed=[];
        $scope.shipperOrderBoardList=[];
        $scope.noChildDataShow=[];
        $scope.person.orderStatus="0";
        $scope.driverGetList=[];//司机竞价 匹配
        $scope.currentPage = 1;
        $scope.pageSize = 5;//每页条数
        $scope.total =5;
        $scope.person.transportWays=[{"key":"1","name":"车运订单"},{"key":"2","name":"船运订单"}];

        if($localStorage.chuanYangloginMessege == undefined){
            $state.go('index.login');
        }else{
            $scope.user_type = $localStorage.chuanYangloginMessege.userType;
        };
        if( $scope.user_type==1){
           $scope.shipperShow=true;
            $scope.logisticShow=false;
        }else if($scope.user_type==3){
            $scope.logisticShow=true;
            $scope.shipperShow=false;
        }
        //日期
        $scope.cacleTask = function () {

        };
        $scope.today = function () {
            $scope.dt = new Date();
        };
        $scope.today();

        $scope.clear = function () {
            $scope.dt = null;
        };

        // Disable weekend selection
        $scope.disabled = function (date, mode) {
            return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
        };

        $scope.toggleMin = function () {
            $scope.minDate = $scope.minDate ? null : new Date();
        };
        $scope.toggleMin();


        $scope.open = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();
            $scope.opened = true;
        };

        $scope.dateOptions = {
            formatYear: 'yy',
            startingDay: 1,
            class: 'datepicker',
            lang: 'zh-cn'
        };

        $scope.initDate = new Date('2016-15-20');
        $scope.formats = ['yyyy-MM-dd'];
        $scope.format = $scope.formats[0];

         //切换
        $scope.changechoosed=function(flag){
            if(flag==="0"){
                $scope.doingOrder=true;
                $scope.cancelOrder=false;
                $scope.currentPage="1";
                $scope.person.orderStatus=flag;
                $scope.person.orderNo="";
                $scope.person.date="";
                $scope.person.orderAddressStart="";
                $scope.person.orderAddressEnd="";
                $scope.person.number="";
                $scope.person.name="";
                $scope.shipperOrderBoardShow();
            }else if(flag==="8"){
                $scope.doingOrder=false;
                $scope.cancelOrder=true;
                $scope.currentPage="1";
                $scope.person.orderNo="";
                $scope.person.date="";
                $scope.person.orderAddressStart="";
                $scope.person.orderAddressEnd="";
                $scope.person.name="";
                $scope.person.number="";
                $scope.person.orderStatus=flag;
                $scope.shipperOrderBoardShow();
            }
        }

        //订单展示
        $scope.shipperOrderBoardShow=function() {
            var time=$filter('date')($scope.person.date,'yyyy-MM-dd');
            $scope.shipperOrderBoardParam = {
                "userId":$localStorage.chuanYangloginMessege.userId,
                "page":$scope.currentPage,
                "length":$scope.pageSize,
                "orderNo":$scope.person.orderNo,
                "order_time":time,
                "city":$scope.person.orderAddressStart,
                "endcity":$scope.person.orderAddressEnd,
                "transPortWay":$scope.person.transportWaySelect,
                "order_type":$scope.person.number,
                "order_status": $scope.person.orderStatus
            };
            console.log(angular.toJson($scope.shipperOrderBoardParam));
            var shipperOrderBoardUrl = ROOTCONFIG.basePath + "info/order/selectWebOrder";
            urls.sendRequest('POST', angular.toJson($scope.shipperOrderBoardParam), shipperOrderBoardUrl, '').success(function (response) {

                if (response.code == 100) {
                    console.log(angular.toJson(response, true));
                    $scope.shipperOrderBoardList = angular.copy(response.data.data);
                      $scope.total=response.data.total;

                    if ($scope.shipperOrderBoardList == undefined) return false;
                    for (var i = 0; i < $scope.shipperOrderBoardList.length; i++) {
                        $scope.showDown[i] = true;
                        $scope.showUp[i] = false;
                        $scope.isCollapsed[i] = false;
                    }

                    if ($scope.shipperOrderBoardList != 0) {
                        $scope.noDataShow = false;
                    } else {
                        $scope.noDataShow = true;
                    }
                } else {
                    toaster.pop('error', '提示', response.msg);
                }
            })
        }

        $scope.shipperOrderBoardShow();

        //查询
        $scope.refer=function(){
            $scope.currentPage = 1;

            $scope.shipperOrderBoardShow();

        }

        //取消订单
        $scope.deleteOrder=function(data){
            $scope.items={
                "title":"提示",
                "tips":"确定要取消该订单？"
            }
            var modalInstance=$modal.open({
                templateUrl: 'pages/shipper/shipperModal.html',
                controller: 'shipperOrderBoardModelCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                console.log($localStorage);
                var deleteOrderUrl= ROOTCONFIG.basePath + "info/order/orderCancelByUser";
                $scope.deleteOrderParam={
                    "orderId":data.orderID,
                    "orderStatus":8,
                    "userId":$localStorage.chuanYangloginMessege.userId
                };
                console.log(angular.toJson($scope.deleteOrderParam));
                urls.sendRequest('POST', angular.toJson($scope.deleteOrderParam), deleteOrderUrl, '').success(function (response) {
                    if(response.code==100){
                        $scope.shipperOrderBoardShow();
                        toaster.success('提示',response.msg,3000);
                    }else{
                        toaster.error('提示',response.msg,3000);
                    }
                })
            })
        }

        //下拉数据
        $scope.showDetails=function(index,items){
            console.log(angular.toJson(items.expiredTime)+"@@@");
            if(items.expiredTime){
                var nowTimes = new Date();
                var currenyDate = Date.parse(nowTimes);
                var endDate = Date.parse(items.expiredTime);
                if(currenyDate<=endDate){
                    toaster.pop('info','提示','竞价时间还未结束，暂不能查看！');
                    return;
                }
            }
            toaster.clear();
            //下架订单
            if(items.order_status==8){
                toaster.pop('warning','提示','该订单已下架！',3000);
                return;
            }
           //
            $scope.isCollapsed[index]=!$scope.isCollapsed[index];
            if( $scope.isCollapsed[index]==true){
                $scope.showDown[index]=false;
                $scope.showUp[index]=true;

                $scope.detailParam={};
                //竞价or匹配
                if(items.order_type==1){
                    $scope.detailParam={
                        "orderId":items.orderID,
                        "property":"star",
                        "collation":"asc"
                    }
                    var detailUrl= ROOTCONFIG.basePath + "info/order/getBidByOrderId";

                }else if(items.order_type==2){
                    $scope.detailParam={
                        "orderId":items.orderID
                    }
                    var detailUrl= ROOTCONFIG.basePath + "info/order/getMatchByOrderId";
                }else if(items.order_type==3){
                    toaster.pop('warning','提示','该订单为指定运输订单',3000);
                    $scope.showDown[index]=true;
                    $scope.showUp[index]=false;
                    $scope.isCollapsed[index]=false;
                    return false;
                }

                console.log(angular.toJson($scope.detailParam,true)+"$$$");
                urls.sendRequest('POST', angular.toJson($scope.detailParam), detailUrl, '').success(function (response) {
                    //
                    if($scope.driverGetList[items.orderID]==""){
                        $scope.noChildDataShow[index]=false;
                    }else{
                        $scope.noChildDataShow[index]=true;
                    }
                    //
                    if(response.code==100){
                        $scope.driverGetList[items.orderID]=angular.copy(response.data);
                        console.log(angular.toJson($scope.driverGetList[items.orderID],true)+"*****");
                        if($scope.driverGetList[items.orderID].length!=0){
                            $scope.noChildDataShow[index]=false;
                        }else{
                            $scope.noChildDataShow[index]=true;
                        }
                    }
                })

            }else{
                $scope.showDown[index]=true;
                $scope.showUp[index]=false;
            }

        };
//选择
        $scope.getSelected=function(index,data,type){

            if(type.order_type==1){   //竞价
                $scope.selectDriverparam={
                    "orderId":data.orderId,
                    "driverId":data.driverId,
                    "amount":data.bid,
                    "type":data.bidType
                };
            }else if(type.order_type==2){  //匹配
                $scope.selectDriverparam={
                    "orderId":data.orderId,
                    "driverId":data.driverId,
                    "amount":type.order_Amount,
                    "type":data.matchType
                };
            }

            console.log(angular.toJson(data)+"&&&");
                 var name= data.name ? data.name:'';
            $scope.items={
                "title":"提示",
                "tips":"确定要选择"+name+"？"
            }
            var modalInstance=$modal.open({
                templateUrl: 'pages/shipper/shipperModal.html',
                controller: 'shipperOrderBoardModelCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                var selectDriverUrl=ROOTCONFIG.basePath + "info/driverOrder/addDriverOrder";

               console.log(angular.toJson($scope.selectDriverparam));
                urls.sendRequest('POST', angular.toJson($scope.selectDriverparam), selectDriverUrl, '').success(function (response) {
                    if(response.code==100){
                        toaster.pop('success','提示','选择成功');
                        $scope.shipperOrderBoardShow();
                    }else{
                        toaster.pop('error','提示',response.msg);
                    }
                })
            });

        }
        //分页
        $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
            $scope.currentPage = page;
            $scope.shipperOrderBoardShow();
            console.log(page);
            console.log(pageSize);
        };


        //
        $scope.getShipLocation=function(dataShip){
            $scope.items={
                "title":"船只信息",
                "frameNumber":dataShip
            }
            var modalInstance=$modal.open({
                templateUrl: 'pages/shipper/shipLocation.html',
                controller: 'shipLocationModelCtrl',
                size:'lg',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
        };
    }])


//弹窗控制器
chuanyang.controller('shipLocationModelCtrl', ['$scope', '$modalInstance', 'items','urls','toaster','$filter',function ($scope, $modalInstance, items,urls,toaster,$filter) {
    $scope.items = items;
   // toaster.pop('error','提示','获取该船舶数据出错!');
//map
    var mapOptions = new shipxyMap.MapOptions();
    var addshipOverlay=[];
    mapOptions.center = new shipxyMap.LatLng(32, 122);
    mapOptions.zoom = 3;
    mapOptions.mapType = shipxyMap.MapType.GOOGLEMAP;
   setTimeout(function(){
       var map = new shipxyMap.Map('mapContainer', mapOptions);
       shipxyMap.mapReady = function () {
            addShip();
       };

       function addShip() {
           //船舶显示样式
           var option = new shipxyMap.ShipOptions();
           /*边框样式*/
           option.strokeStyle.color = 0xff0000;
           option.strokeStyle.alpha = 1;
           option.strokeStyle.thickness = 2;
           /*填充样式*/
           option.fillStyle.color = 0x00ff00;
           option.fillStyle.alpha = 1;
           /*标签样式*/
           //标签线条
           option.labelOptions.border = true; //有边框
           option.labelOptions.borderStyle.color = 0x000000;
           option.labelOptions.borderStyle.alpha = 1;
           //标签文字
           option.labelOptions.fontStyle.name = "Verdana";
           option.labelOptions.fontStyle.size = "12";
           option.labelOptions.fontStyle.color = 0x000000;
           option.labelOptions.fontStyle.bold = true;  //粗体
           option.labelOptions.fontStyle.bold = true;  //斜体
           option.labelOptions.fontStyle.underline = true;  //下划线
           //标签填充
           option.labelOptions.background = true; //有背景
           option.labelOptions.backgroundStyle.color = 0xffff66;  //边框样式
           option.labelOptions.backgroundStyle.alpha = 1;
           option.isShowLabel = true; //是否显示label
           option.isShowMiniTrack = true//船舶自带三分钟轨迹
           option.isSelected = false; //船舶框选
           option.zoomLevels = [1, 18]; //显示级别

           //data
           var frameNumberArr=[];
           var indexType = $scope.items.frameNumber.frameNumber.indexOf(',');
           if(indexType != -1 ){
             var arrTemp = $scope.items.frameNumber.frameNumber.split(',');
               for(var k=0;k<arrTemp.length;k++){
                   frameNumberArr.push(arrTemp[k]);
               }
           }else{
               frameNumberArr.push($scope.items.frameNumber.frameNumber);
           }
           var ships = new shipxyAPI.Ships(frameNumberArr, shipxyAPI.Ships.INIT_SHIPID);
           ships.getShips(function (status) {
               var data = this.data;
               console.log(data.length);
               console.log(status);

               if (status == 0) {
                   if (data && data.length > 0) {
                     //  var d = data[0];
                       console.log(data);
                    //   console.log(d);
                       for(var i=0;i<data.length;i++){
                           addshipOverlay[i] = new shipxyMap.Ship(data[i].MMSI, data[i], option);
                           map.addOverlay(addshipOverlay[i], true);
                            var testWin=null;
                           map.addEventListener(addshipOverlay[i], shipxyMap.Event.CLICK,
                               function(event){
                                   console.log(event);
                                   var layData = map.getOverlayById(event.overlayId);
                                   console.log(layData.data);
                                 if(!testWin||testWin.ishide()){
                                     testWin = new XWin({
                                         modal: false, //指定模态
                                         width: 320,//弹出框的宽度
                                         position: [760, 200], //[left,top]，设置弹出框的弹出位置，若不指定则默认为屏幕中心点
                                         title: '船只详细信息',//窗口的标题，可以是html内容，如：<a href="http://www.***.com">********</a>
                                         content: contentFun(layData.data),//窗口的内容，也可以是html内容
                                         onhide: function () {//关闭窗口后的回调函数，可以在这里处理窗口关闭后的操作

                                         }
                                     });
                                     testWin.show();
                                }else{
                                     testWin.setContent(contentFun(layData.data));
                                 }

                                   //内容
                                   function contentFun(datas){
                                      var times = new Date(datas.lastTime*1000);
                                       var updateTime=$filter('date')(times,'yyyy-MM-dd HH:mm:ss');
                                       console.log(updateTime);
                                       var htmlCon='<div class="text-center padder padder-v clearfix"><div class="col-sm-6 no-padder text-center m-t-sm">船名: '+datas.name+'</div>' +
                                                   '<div class="col-sm-6 no-padder text-center m-t-sm">经度: '+datas.lat+'</div><div class="col-sm-6 no-padder text-center m-t-sm">呼号: '+datas.callsign+'</div>' +
                                                   '<div class="col-sm-6 no-padder text-center m-t-sm">纬度: '+datas.lng+'</div><div class="col-sm-6 no-padder text-center m-t-sm">MMSI: '+datas.MMSI+'</div>' +
                                                   '<div class="col-sm-6 no-padder text-center m-t-sm">船首向: '+datas.heading+'度</div><div class="col-sm-6 no-padder text-center m-t-sm">IMO: '+datas.IMO+'</div>' +
                                                   '<div class="col-sm-6 no-padder text-center m-t-sm">船迹向: '+datas.course+'度</div><div class="col-sm-6 no-padder text-center m-t-sm">船籍: '+datas.country+'</div>' +
                                                   '<div class="col-sm-6 no-padder text-center m-t-sm">航速: '+datas.speed.toFixed(2)+'节</div><div class="col-sm-6 no-padder text-center m-t-sm">类型: '+datas.type+'</div>' +
                                                    '<div class="col-sm-6 no-padder text-center m-t-sm">货物类型: '+datas.cargoType+'</div><div class="col-sm-6 no-padder text-center m-t-sm">目的地: '+datas.dest+'</div>' +
                                                   '<div class="col-sm-6 no-padder text-center m-t-sm">船长: '+datas.length+'米</div><div class="col-sm-6 no-padder text-center m-t-sm">预到时间: '+datas.eta+'</div>' +
                                                   '<div class="col-sm-6 no-padder text-center m-t-sm">船宽: '+datas.beam+'米</div><div class="col-sm-6 no-padder text-center m-t-sm">吃水: '+datas.draught+'米</div>' +
                                                   '<div class="col-sm-6 no-padder text-center m-t-sm">状态: '+datas.status+'</div><div class="col-sm-12 no-padder text-center m-t-sm">更新时间: '+updateTime+'</div></div>';
                                       return htmlCon;
                                   }


                               });
                       }

                   } else {

                       alert('获取该船舶数据出错!');

                   }

               } else {
                   alert('获取该船舶数据出错!');

               }
           });

       }


   },1000);



    $scope.add = function () {
        $scope.selected = items;
        console.log($scope.selected);
        $modalInstance.close($scope.selected);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

}]);
//
chuanyang.controller('shipperOrderBoardModelCtrl', ['$scope', '$modalInstance', 'items','urls',function ($scope, $modalInstance, items,urls) {
    $scope.items = items;
    $scope.add = function () {
        $scope.selected = items;
        console.log($scope.selected);
        $modalInstance.close($scope.selected);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

}]);