/**
 * Created by W on 2016/12/17.
 */
'use strict'
chuanyang.controller('confirmPaymentCtrl',['$scope','$modal','$localStorage','$sessionStorage','$timeout','urls','$filter','toaster','$state','$cookieStore',
    function($scope,$modal,$localStorage,$sessionStorage,$timeout,urls,$filter,toaster,$state,$cookieStore){
        if($localStorage.chuanYangloginMessege == undefined){
            $state.go('index.login');
        }else{
            $scope.user_type = $localStorage.chuanYangloginMessege.userType;
        };
        if( $scope.user_type==1){
            $scope.dealInfo={
                type : true
            };
        }else if($scope.user_type==3) {
            $scope.dealInfo = {
                type: false
            };
        };
        $scope.SubOrderInfo = $cookieStore.get('subOrderInfo');
        $scope.currencyInfo = $cookieStore.get('currencyInfo');
        if(!$scope.SubOrderInfo){
            if( $scope.user_type==1){
                $state.go('home.unpayOrder');
            }else if($scope.user_type==3) {
                $state.go('home.unpayOrderList');
            };
            return;
        };
        $scope.orderDetailInfo = [];
        angular.copy($localStorage.chuanYangloginMessege.orderInfo,$scope.orderDetailInfo);
        //window.onbeforeunload=function(){
        //    return '离开或刷新此页面不会保存相关信息!';
        //};
     //   $scope.orderInfoShow={};
      //  $scope.orderInfoShow.paymentOrderNo=$sessionStorage.subOrderInfo.paymentOrderNo;
      //  $scope.orderInfoShow.amount=$sessionStorage.subOrderInfo.amount;
     //   $scope.orderInfoShow.balance=$sessionStorage.currencyInfo.balance;
     //   $scope.orderInfoShow.currencyTypeId=$sessionStorage.currencyInfo.currencyTypeId;

        $scope.confirmPayMoney=function(){
            var orderPayMoneyUrl = ROOTCONFIG.basePath+"info/orderPay/pay";
            $scope.orderPayMoneyParam={
                userId:$localStorage.chuanYangloginMessege.userId,
                paymentId:$scope.SubOrderInfo.id,
                payPassword:$scope.pswValue
            };
            urls.sendRequest('POST', angular.toJson($scope.orderPayMoneyParam), orderPayMoneyUrl, '').success(function (response) {
                console.log(response);
                if(response.code==100){
                    toaster.pop('success','提示','支付成功!正在跳转订单列表界面...');

                    $timeout(function(){
                       // window.onbeforeunload=null;
                        if( $scope.user_type==1){
                            $state.go('home.shipperList');
                        }else if($scope.user_type==3) {
                            $state.go('home.orderList');
                        };

                    },3000);

                }else{
                    toaster.pop('error','提示',response.msg);
                }
            })
        }
/*
        $scope.orderInfoShow={};

          if(!$sessionStorage.orderInfo){
              $sessionStorage.orderInfo={};
              $sessionStorage.orderInfo.subOrderInfo={};
              $sessionStorage.orderInfo.currencyInfo={};
              angular.copy($state.params.subOrderInfo,$sessionStorage.orderInfo.subOrderInfo);
              angular.copy($state.params.currencyInfo,$sessionStorage.orderInfo.currencyInfo);

          }
        $scope.orderInfoShow.paymentOrderNo=$sessionStorage.orderInfo.subOrderInfo.paymentOrderNo;
        $scope.orderInfoShow.amount=$sessionStorage.orderInfo.subOrderInfo.amount;
        $scope.orderInfoShow.balance=$sessionStorage.orderInfo.currencyInfo.balance;
        $scope.orderInfoShow.currencyTypeId=$sessionStorage.orderInfo.currencyInfo.currencyTypeId;*/
 }])