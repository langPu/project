/**
 * Created by W on 2016/11/8.
 */
'use strict'
chuanyang.controller('orderPayCtrl',['$scope','$modal','$localStorage','urls','$filter','toaster','$sessionStorage','$state','$cookieStore',
    function($scope,$modal,$localStorage,urls,$filter,toaster,$sessionStorage,$state,$cookieStore){
        $scope.showUp=[];
        $scope.showDown=[];
        $scope.noChildDataShow=[];
        $scope.orderDetailsList=[];
        $scope.orderInfoList=[];
        $scope.isCollapsed=[];
        $scope.userOrder={};
        $scope.userOrder.orderValue=[];
        $scope.userOrder.selectdNum=0;
        $scope.userOrder.priceAmount=0;
        $scope.userOrder.infoAcount=0;//信息费
        $scope.userOrder.totalAcount=0;//总金额
        $scope.userOrder.startInfo = true;
        $scope.userOrder.errorInfo = false;
        $scope.userOrder.successInfo = false;
        $scope.orderRemark = '';
        $scope.orderPay={
            "weixin":true,
            "crdit":true,
            "alpay":true,
            "bank":true
        };
       $scope.platformNoShow = true;
        $scope.orderPayWay = '';
        if($localStorage.chuanYangloginMessege == undefined){
            $state.go('index.login');
        }else{
            $scope.user_type = $localStorage.chuanYangloginMessege.userType;
        };
        if( $scope.user_type==1){
            $scope.dealInfo={
                   type : true
            };
            var orderId = 'orderID';
            var orderAmount = 'actualAmount';
        }else if($scope.user_type==3) {
            $scope.dealInfo = {
                type: false
            };
            var orderId = 'id';
            var orderAmount = 'actualAmount';
        }
        //pingtaixiadan
     /*   $scope.saveOrderInfo = $cookieStore.get('saveOrderInfo');
        if($scope.saveOrderInfo){
            var getOrderPayInfoUrl = ROOTCONFIG.basePath+"info/order/getOrderByIds";
              $scope.getOrderPayInfoParam={};
            $scope.getOrderPayInfoParam.orderIds=[];
            angular.copy($scope.saveOrderInfo,$scope.getOrderPayInfoParam.orderIds);
            urls.sendRequest('POST', angular.toJson($scope.getOrderPayInfoParam),getOrderPayInfoUrl, '').success(function (response) {
                $scope.platformNoShow = false;
                if(response.code==100){
                    angular.copy(response.data,$scope.orderInfoList);
                    for(var i=0;i< $scope.orderInfoList.length;i++){
                        $scope.showDown[i]=true;
                        $scope.showUp[i]=false;
                        $scope.isCollapsed[i]=false;
                        $scope.userOrder.orderValue[$scope.orderInfoList[i].orderID]=parseFloat($scope.orderInfoList[i].order_Amount);
                        $scope.userOrder.priceAmount+=$scope.userOrder.orderValue[$scope.orderInfoList[i].orderID];
                    };
                    $scope.userOrder.totalAcount=parseFloat($scope.userOrder.priceAmount);

                }else{
                    toaster.pop('error','提示',response.msg);
                }
                    if($scope.orderInfoList.length==0){
                        $scope.noDataShow=true;
                    }else{
                        $scope.noDataShow=false;
                    }
            })
        }*/
       //   if($localStorage.chuanYangloginMessege.orderInfo){
              $scope.orderInfoList=angular.copy($localStorage.chuanYangloginMessege.orderInfo);
              $scope.userOrder.selectdNum=$scope.orderInfoList.length;
              if($scope.orderInfoList.length==0){
                  $scope.noDataShow=true;
              }else{
                  $scope.noDataShow=false;
              }

              for(var i=0;i< $scope.orderInfoList.length;i++){
                  $scope.showDown[i]=true;
                  $scope.showUp[i]=false;
                  $scope.isCollapsed[i]=false;
                  $scope.userOrder.orderValue[$scope.orderInfoList[i][orderId]]=parseFloat($scope.orderInfoList[i][orderAmount]);
                  $scope.userOrder.priceAmount+=$scope.userOrder.orderValue[$scope.orderInfoList[i][orderId]];
              };
              //  $scope.userOrder.infoAcount=($scope.userOrder.priceAmount*0.03).toFixed(2);//信息费
              $scope.userOrder.totalAcount=parseFloat($scope.userOrder.priceAmount);//+parseFloat($scope.userOrder.infoAcount);
   //      }

        //设置实际打款金额
     /*   $scope.setOrderValue=function(index,flag){

            if($scope.userOrder.orderValue[flag.orderID]==null||$scope.userOrder.orderValue[flag.orderID]<0){
                $scope.userOrder.orderValue[flag.orderID]=0;
            }

            if($scope.userOrder.orderValue[flag.orderID]>flag.over_Amount){
                $scope.userOrder.orderValue[flag.orderID]=parseFloat(flag.over_Amount);
                toaster.pop('warning','提示','所设置的打款不能超过该订单的尾款');
            }
            $scope.userOrder.priceAmount=0;
            for(var i=0;i< $scope.orderInfoList.length;i++){
                $scope.userOrder.priceAmount+=$scope.userOrder.orderValue[$scope.orderInfoList[i].orderID];
            }
            $scope.userOrder.infoAcount=($scope.userOrder.priceAmount*0.03).toFixed(2);
            $scope.userOrder.totalAcount=parseFloat($scope.userOrder.priceAmount)+parseFloat($scope.userOrder.infoAcount);
        }*/


        //删除订单
        $scope.deletePersonOrder=function(index,datas){
            $scope.items={
                "title":"提示",
                "tips":"确定删除订单号为"+datas.orderNo+"的订单？"
            }
            var modalInstance=$modal.open({
                templateUrl: 'pages/shipper/shipperModal.html',
                controller: 'shipperOrderPayModelCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $scope.orderInfoList.splice(index,1);
             //   if($localStorage.chuanYangloginMessege.orderInfo){
                    $localStorage.chuanYangloginMessege.orderInfo=angular.copy($scope.orderInfoList);
                    $scope.userOrder.selectdNum=$scope.orderInfoList.length;
           /*     }else{
                    for(var k = 0;k<$scope.saveOrderInfo.length;k++){
                        if(datas.orderID==$scope.saveOrderInfo[k]){
                            $scope.tempData = [];
                            angular.copy($scope.saveOrderInfo,$scope.tempData);
                            $scope.tempData.splice(k,1);
                            angular.copy($scope.tempData,$scope.saveOrderInfo);
                        }
                    }
                    console.log($scope.tempData);
                    console.log($scope.saveOrderInfo);
                }*/
                $scope.userOrder.priceAmount-=$scope.userOrder.orderValue[datas[orderId]];
              //  $scope.userOrder.infoAcount=($scope.userOrder.priceAmount*0.03).toFixed(2);//信息费
                $scope.userOrder.totalAcount=parseFloat($scope.userOrder.priceAmount);//+parseFloat($scope.userOrder.infoAcount);
                if($scope.orderInfoList.length==0){
                    $scope.noDataShow=true;
                }else{
                    $scope.noDataShow=false;
                }
            })
        }

//字数限制
        $scope.textNumLimit = function(){
            if($scope.orderRemark.length<=60 && $scope.orderRemark.length>0){
                $scope.userOrder.startInfo = false;
                $scope.userOrder.errorInfo = false;
                $scope.userOrder.successInfo = true;
            }else if($scope.orderRemark.length==0){
                $scope.userOrder.startInfo = true;
                $scope.userOrder.errorInfo = false;
                $scope.userOrder.successInfo = false;
            }else{
                $scope.userOrder.startInfo = false;
                $scope.userOrder.errorInfo = true;
                $scope.userOrder.successInfo = false;
                $scope.orderRemark = $scope.orderRemark.slice(0,60);
            }
        }

        //支付方式
        $scope.payWayChoosed=function(flag){
            $scope.orderPayWay = flag;
            switch(flag){
                case '1':
                    $scope.orderPay={
                        "weixin":true,
                        "crdit":true,
                        "alpay":true,
                        "bank":false
                    };
                    break;
                case '2':
                    $scope.orderPay={
                        "weixin":true,
                        "crdit":false,
                        "alpay":true,
                        "bank":true
                    };
                    break;
                case '3':
                    $scope.orderPay={
                        "weixin":true,
                        "crdit":true,
                        "alpay":false,
                        "bank":true
                    };
                    break;
            }
        }

        //提交
        $scope.sendOrderPay=function(){
            console.log($scope.orderPayWay);
            if($scope.orderPayWay==''){
                toaster.pop('warning','提示','请选择支付方式!');
                return;
            };
            if($scope.orderInfoList.length==0){
                toaster.pop('info','提示','你还未选择要结算的订单!',5000);
                return;
            }
            $scope.items={
                "title":"提示",
                "tips":"系统检测到你还未设置支付密码，是否前往设置？"
            };
            //checkPsw
            var checkPayPswUrl=ROOTCONFIG.basePath+"info/account/getAccountById";

            if($scope.user_type==1){
                $scope.custId=$localStorage.chuanYangloginMessege.userId;   //个人货主
                $scope.accountType=1;
            }else if($scope.user_type==3){
                $scope.custId=$localStorage.chuanYangloginMessege.companys[0].companyID; //物流公司
                $scope.accountType=2;
            }
            toaster.pop('info','提示','正在提交，请稍等...!');
            urls.sendRequest('GET','',checkPayPswUrl+'?custId='+ $scope.custId+'&accountType='+$scope.accountType, '').success(function(response){
                toaster.clear();
                console.log(response);
                if(response.code==100){
                    if(response.data.hasPassword!=0||$scope.orderPayWay!=1){
                        //已有psw
                        $scope.currencyData=[];
                        var orderPayInfo = {};
                        orderPayInfo.orderIds=[];
                         for(var i = 0;i<$scope.orderInfoList.length;i++){
                             orderPayInfo.orderIds.push($scope.orderInfoList[i][orderId]);
                         };
                        if($scope.user_type==1){
                            orderPayInfo.userId=$localStorage.chuanYangloginMessege.userId;   //个人货主
                        }else if($scope.user_type==3){
                            orderPayInfo.companyId=$localStorage.chuanYangloginMessege.companys[0].companyID; //物流公司
                            orderPayInfo.userId=$localStorage.chuanYangloginMessege.userId;
                        };
                        if($scope.orderInfoList[0].currencyType=='人民币'){
                            orderPayInfo.currencyType = 1;
                        }else{
                            orderPayInfo.currencyType = 2;
                        };
                        orderPayInfo.amount=$scope.userOrder.totalAcount.toFixed(2);
                        orderPayInfo.remark=$scope.orderRemark;
                        orderPayInfo.payWay=$scope.orderPayWay;
                        orderPayInfo.recBank = 1;
                        for(var j=0;j<response.data.accounts.length;j++){
                            if(orderPayInfo.currencyType==response.data.accounts[j].currencyTypeId){
                                console.log(response.data.accounts[j]);
                                $scope.currencyData = angular.copy(response.data.accounts[j]);
                            }
                         };
                        console.log(JSON.stringify(orderPayInfo));

                            var orderPayInfoUrl=ROOTCONFIG.basePath+"info/orderPay/savePayment";
                            urls.sendRequest('POST', angular.toJson(orderPayInfo), orderPayInfoUrl, '').success(function (res) {
                                console.log(res);
                                if(res.code==100){
                                  //  $sessionStorage.subOrderInfo={};
                                  //      $sessionStorage.currencyInfo={};
                                    if($scope.orderPayWay=='1'){
                                       // angular.copy(res.data,$sessionStorage.subOrderInfo);
                                     //   angular.copy($scope.currencyData,$sessionStorage.currencyInfo);
                                        $state.go('home.confirmPayment');
                                    }else{
                                       // angular.copy(res.data,$sessionStorage.subOrderInfo);
                                      //  angular.copy($scope.currencyData,$sessionStorage.currencyInfo);
                                        $state.go('home.internetBank');
                                    }
                                    $scope.currencyData.remark = $scope.orderRemark;
                                    $cookieStore.put('subOrderInfo',res.data);
                                    $cookieStore.put('currencyInfo',$scope.currencyData);
                                }
                            });


                    }else{
                        //setPsw
                        var modalInstance=$modal.open({
                            templateUrl: 'pages/shipper/shipperModal.html',
                            controller: 'shipperOrderPayModelCtrl',
                            resolve: {
                                items: function () {
                                    return $scope.items;
                                }
                            }
                        });
                        modalInstance.result.then(function (selectedItem) {
                            $localStorage.chuanYangloginMessege.accountType=$scope.accountType;
                            $localStorage.chuanYangloginMessege.custId=$scope.custId;
                            $state.go('home.payPassword');
                        })
                        //
                    }
                }else{
                    toaster.pop('error','提示',response.msg||'提交失败!');
                }
            })

        }

    }])

//弹窗控制器
chuanyang.controller('shipperOrderPayModelCtrl', ['$scope', '$modalInstance', 'items','urls',function ($scope, $modalInstance, items,urls) {
    $scope.items = items;
    $scope.add = function () {
        $scope.selected = items;
        console.log($scope.selected);
        $modalInstance.close($scope.selected);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

}]);


