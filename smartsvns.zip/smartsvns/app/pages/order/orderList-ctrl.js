/**
 * Created by admin on 2016/10/20.
 */

chuanyang.controller('orderListController', ['$scope', '$state', 'toaster', '$filter', 'urls', '$localStorage', '$modal',
    function ($scope, $state, toaster, $filter, urls, $localStorage, $modal) {

        if (ROOTCONFIG.debug) {
            console.log("into orderListController...");
        }
        $scope.config = {
            //查询条件
            userId: "",
            orderId: "",
            startTime: "",
            endTime: "",
            startArea: "",
            endArea: "",
            orderStatus: "",

            openedStart: false,
            openedEnd: false,

            selectOrderInfos: [],
            car: true,
            boat: false,
            trainDesc: "车运订单",
            transPortWay: '1',
            assignment: null,
            noDataShow: false
        };
        $scope.hideLoading = false;
        $scope.changeTrain = function (item) {
            if (item == 'car') {
                $scope.config.car = true;
                $scope.config.boat = false;
                $scope.config.trainDesc = "车运订单";
                $scope.config.transPortWay = '1';
                $scope.searchOrderList();
            } else {
                $scope.config.car = false;
                $scope.config.boat = true;
                $scope.config.trainDesc = "船运订单";
                $scope.config.transPortWay = '2';
                $scope.searchOrderList();
            }
        };
        $scope.formats = ['yyyy-MM-dd'];
        $scope.format = $scope.formats[0];
        $scope.functionName = $state.current.url;
        $scope.pageSize = 10;//每页条数
        $scope.total = 0;//总条数
        $scope.currentPage = 1;

        $scope.isCollapsed = [];
        $scope.orderList = [];
        // for (var i = 0; i < transportationList.data.length; i++) {
        //     $scope.isCollapsed[i] = true;
        //     $scope.orderList[i] = {};
        // }
        $scope.transportationList = [];//获取订单列表
        $scope.trainOrders = [];
        $scope.getOrderInformation = function (index, item) {
            $scope.orderList[index] = [];
            var urlTransportationList = ROOTCONFIG.basePath + "info/order/selWebOrderWaybill";
            var order = {
                "orderId": item.id
                // "orderId":1538
            };
            if ($scope.isCollapsed[index] == true) {
                $scope.isCollapsed[index] = !$scope.isCollapsed[index];

            } else {
                toaster.pop("wait", "提示", "正在查询相关运单...", 60000);


                urls.sendRequest('POST', angular.toJson(order), urlTransportationList, '').success(function (response) {
                    toaster.clear();
                    if (ROOTCONFIG.debug) {
                        console.log((response));
                    }
                    if (response.code == '100') {
                        $scope.trainOrders[index] = response.data;
                        if ($scope.trainOrders[index].length > 0) {
                            $scope.isCollapsed[index] = !$scope.isCollapsed[index];
                        } else {
                            toaster.pop("waring", "提示", "暂无运单!");
                            return;
                        }
                        for (var i = 0; i < $scope.trainOrders[index].length; i++) {
                            if ($scope.trainOrders[index][i].waybillStatus == '0') {
                                $scope.trainOrders[index][i].waybillStatusDesc = '初始化';
                            } else if ($scope.trainOrders[index][i].waybillStatus == '1') {
                                $scope.trainOrders[index][i].waybillStatusDesc = '待分配';
                            } else if ($scope.trainOrders[index][i].waybillStatus == '2') {
                                $scope.trainOrders[index][i].waybillStatusDesc = '待装货';
                            } else if ($scope.trainOrders[index][i].waybillStatus == '3') {
                                $scope.trainOrders[index][i].waybillStatusDesc = '装货中';
                            } else if ($scope.trainOrders[index][i].waybillStatus == '4') {
                                $scope.trainOrders[index][i].waybillStatusDesc = '运输中';
                            } else if ($scope.trainOrders[index][i].waybillStatus == '5') {
                                $scope.trainOrders[index][i].waybillStatusDesc = '卸货中';
                            } else if ($scope.trainOrders[index][i].waybillStatus == '6') {
                                $scope.trainOrders[index][i].waybillStatusDesc = '待收货';
                            } else if ($scope.trainOrders[index][i].waybillStatus == '7') {
                                $scope.trainOrders[index][i].waybillStatusDesc = '已完成';
                            } else if ($scope.trainOrders[index][i].waybillStatus == '8') {
                                $scope.trainOrders[index][i].waybillStatusDesc = '已取消';
                            } else if ($scope.trainOrders[index][i].waybillStatus == '-1') {
                                $scope.trainOrders[index][i].waybillStatusDesc = '已删除';
                            }
                            for (var j = 0; j < $scope.trainOrders[index][i].waybillUnlaodImgs.length; j++) {
                                $scope.trainOrders[index][i].waybillUnlaodImgs[j].imgAdd = $scope.trainOrders[index][i].waybillUnlaodImgs[j].image
                                    + '?x-oss-process=image/resize,m_fixed,h_100,w_100';
                            }
                        }
                    } else if (response.code = '101') {
                        toaster.pop("waring", "提示", response.msg);
                    } else if (response.code = '110') {

                    }
                });


            }
        };

        //查询订单状态
        $scope.allOrderStatus = [
            {"type": "0", "status": "初始化"},
            {"type": "1", "status": "待分配"},
            {"type": "2", "status": "待装货"},
            {"type": "3", "status": "装货中"},
            {"type": "4", "status": "运输中"},
            {"type": "5", "status": "卸货中"},
            {"type": "6", "status": "待收货"},
            {"type": "7", "status": "已完成"},
            // {"type": "8", "status": "已取消"},
            // {"type": "-1", "status": "已删除"}
        ];
        //分页
        $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
            $scope.currentPage = page;
            $scope.searchOrderList();
            console.log("分页点击：" + text);
        };

        function serverFormateDate(dateObject) {
            if (angular.isUndefined(dateObject) || dateObject == null) {
                return '';
            }
            return $filter('date')(dateObject, 'yyyy-MM-dd');
        };
        //查询  waring success error
        $scope.searchOrderList = function () {
            // toaster.pop('waring', '提示', '请选择货主');
            // toaster.pop("wait","提示","正在加载...",1000);
            var getPlan = {
                "userId": $localStorage.chuanYangloginMessege.userId,
                "orderNo": $scope.config.orderId,
                "orderStartime": serverFormateDate($scope.config.startTime),
                "orderEndtime": serverFormateDate($scope.config.endTime),
                "spCity": $scope.config.startArea,
                "epCity": $scope.config.endArea,
                "flow": $scope.config.endArea,
                "page": $scope.currentPage,
                "length": $scope.pageSize,
                "orderStatus": $scope.config.orderStatus,
                "transPortWay": $scope.config.transPortWay,
                "assignment": $scope.config.assignment
            };
            searchOrderListData(getPlan);
        }
        $scope.searchOrderList();
        function searchOrderListData(getPlan) {
            var urlTransportationList = ROOTCONFIG.basePath + "info/tPlanInfo/selectOrderInfo";
            urls.sendRequest('POST', angular.toJson(getPlan), urlTransportationList, '').success(function (response) {
                if (ROOTCONFIG.debug) {
                    console.log((response));
                }
                if (response.code == '100') {
                    $scope.hideLoading = true;
                    $scope.total = response.data.total;
                    $scope.transportationList = response.data.data;
                    $scope.transportationinfo = response.data;
                    $scope.isCollapsed = [];
                    if ($scope.transportationList.length == 0) {
                        $scope.config.noDataShow = true;
                        toaster.pop('waring', '提示', '暂无数据');
                    }else{
                        $scope.config.noDataShow = false;
                    }
                    for (var i = 0; i < $scope.transportationList.length; i++) {
                        // $scope.transportationList[i].createTime = $filter('date')(new Date($scope.transportationList[i].createTime), 'yyyy-MM-dd hh:mm:ss');
                        $scope.isCollapsed[i] = false;
                        if ($scope.transportationList[i].orderStatus == '0') {
                            $scope.transportationList[i].orderStatusDesc = '初始化';
                        } else if ($scope.transportationList[i].orderStatus == '1') {
                            $scope.transportationList[i].orderStatusDesc = '待分配';
                        } else if ($scope.transportationList[i].orderStatus == '2') {
                            $scope.transportationList[i].orderStatusDesc = '待装货';
                        } else if ($scope.transportationList[i].orderStatus == '3') {
                            $scope.transportationList[i].orderStatusDesc = '装货中';
                        } else if ($scope.transportationList[i].orderStatus == '4') {
                            $scope.transportationList[i].orderStatusDesc = '运输中';
                        } else if ($scope.transportationList[i].orderStatus == '5') {
                            $scope.transportationList[i].orderStatusDesc = '卸货中';
                        } else if ($scope.transportationList[i].orderStatus == '6') {
                            $scope.transportationList[i].orderStatusDesc = '待收货';
                        } else if ($scope.transportationList[i].orderStatus == '7') {
                            $scope.transportationList[i].orderStatusDesc = '已完成';
                        } else if ($scope.transportationList[i].orderStatus == '8') {
                            $scope.transportationList[i].orderStatusDesc = '已取消';
                        } else if ($scope.transportationList[i].orderStatus == '-1') {
                            $scope.transportationList[i].orderStatusDesc = '已删除';
                        } else if ($scope.transportationList[i].orderStatus == '-3') {
                            $scope.transportationList[i].orderStatusDesc = '超 时';
                        }
                    }
                } else if (response.code = '101') {
                    toaster.pop('waring', '提示', response.msg);
                } else if (response.code = '110') {

                }
            });
        }

        $scope.isCollapsedTwo = [];
        $scope.getOrderInformationTwo = function (trainOrder) {
            console.log(trainOrder);
            trainOrder.isCollapsedTwo = !trainOrder.isCollapsedTwo;
            var urlTransportationList = ROOTCONFIG.basePath + "info/order/selectAboutOrd";
            var getDetail = {
                waybillId: trainOrder.waybillId
            }
            urls.sendRequest('POST', angular.toJson(getDetail), urlTransportationList, '').success(function (response) {
                if (ROOTCONFIG.debug) {
                    console.log((response));
                }
                if (response.code == '100') {
                    trainOrder.transportationDetail = response.data;
                } else if (response.code = '101') {

                } else if (response.code = '110') {

                }
            });
        }
        //弹窗显示物品详情
        $scope.getOrderInformationTwoModal = function (trainOrder) {
            var modalInstance = $modal.open({
                templateUrl: 'pages/order/orderGoodsDetail.html',
                controller: 'orderTrainDetailController',
                size: 'lg',
                scope: $scope,
                resolve: {
                    orderDetailInfos: function () {
                        return trainOrder;
                    }
                }
            });
        }
        //选择时间的
        $scope.open = function ($event, item) {
            $event.preventDefault();
            $event.stopPropagation();
            if (item == 'start') {
                $scope.config.openedStart = true;
            } else {
                $scope.config.openedEnd = true;

            }
        };
        $scope.goMap = function (order, item) {
            if (item == 'order') {
                var info = {
                    id: order.id,
                    desc: 'order'
                }
            } else {
                var info = {
                    id: order.driverId,
                    desc: 'train'
                }
            }
            var modalInstance = $modal.open({
                templateUrl: 'pages/order/orderInGps.html',
                controller: 'orderMapController',
                size: 'sm',
                scope: $scope,
                resolve: {
                    orderId: function () {
                        return info;
                    }
                }
            });
        }
        $scope.goPicture = function (trainOrder) {
            var modalInstance = $modal.open({
                templateUrl: 'pages/order/orderPictureModal.html',
                controller: 'orderPictureController',
                size: 'lg',
                scope: $scope,
                resolve: {
                    orderPictureInfos: function () {
                        return trainOrder;
                    }
                }
            });
        }

        //确认订单收货
        $scope.confirmOrder = function (item) {
            $scope.items = {
                "title": "提示",
                "tips": "确定收货？"
            }
            var modalInstance = $modal.open({
                templateUrl: 'pages/order/confirmOrderModal.html',
                controller: 'commonModelOrderCtrl',
                size: 'sm',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                var urlConfirmOrder = ROOTCONFIG.basePath + "info/order/signoff";
                var getConfirmOrder = {
                    orderId: item.id,
                    orderStatus: 7
                };
                urls.sendRequest('POST', angular.toJson(getConfirmOrder), urlConfirmOrder, '').success(function (response) {
                    if (ROOTCONFIG.debug) {
                        console.log((response));
                    }
                    if (response.code == '100') {
                        toaster.pop('success', '提示', "收货成功");
                        $scope.searchOrderList();
                    } else if (response.code = '101') {
                        toaster.pop('waring', '提示', response.msg);
                    } else if (response.code = '110') {
                    }
                });
            })
        }
        //确认运单收货
        $scope.confirmTrainOrder = function (item) {
            $scope.items = {
                "title": "提示",
                "tips": "确定收货？"
            }
            var modalInstance = $modal.open({
                templateUrl: 'pages/order/confirmOrderModal.html',
                controller: 'commonModelOrderCtrl',
                size: 'sm',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                var urlConfirmOrder = ROOTCONFIG.basePath + "info/driverOrder/updateWaybillStatus";
                var getConfirmOrder = {
                    waybillId: item.waybillId,
                    waybillStatus: 7
                };
                urls.sendRequest('POST', angular.toJson(getConfirmOrder), urlConfirmOrder, '').success(function (response) {
                    if (ROOTCONFIG.debug) {
                        console.log((response));
                    }
                    if (response.code == '100') {
                        toaster.pop('success', '提示', "收货成功");
                        $scope.searchOrderList();
                    } else if (response.code = '101') {
                        toaster.pop('waring', '提示', response.msg);
                    } else if (response.code = '110') {
                    }
                });
            })
        }
        //装船清单
        $scope.updateTrainOrder = function (trainOrder) {
            var modalInstance = $modal.open({
                templateUrl: 'pages/order/updateTrainOrder.html',
                controller: 'updateTrainOrderCtrl',
                size: 'lg',
                resolve: {
                    trainOrder: function () {
                        return trainOrder;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                $scope.searchOrderList();
            }, function () {
                //$log.info('Modal dismissed at: ' + new Date());
            });
        };
        //导入
        $scope.importGoods = function (datas) {
            var modalInstance = $modal.open({
                templateUrl: 'pages/shipper/shipperList/importGoods.html',
                controller: 'importGoodsOrderListCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return datas;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                $scope.searchOrderList();
            }, function () {
                //$log.info('Modal dismissed at: ' + new Date());
            });
        }
        //查看订单详情
        $scope.getOrderDetails = function (data) {
            $scope.items = {
                "orderId": data.id
            }
            var modalInstance = $modal.open({
                templateUrl: 'pages/shipper/shipperList/shipperOrderDetail.html',
                controller: 'shipperModelCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
        };
    }]);
chuanyang.controller('orderMapController', ['$scope', '$state', 'toaster', '$filter', 'urls', '$localStorage', 'orderId', '$modalInstance',
    function ($scope, $state, toaster, $filter, urls, $localStorage, orderId, $modalInstance) {
        if (orderId.desc == 'order') {
            var urlMap = ROOTCONFIG.basePath + "info/GPS/GetCarCurrentStatusByOrderId";
            var getMap = {orderId: orderId.id};
        } else {
            var urlMap = ROOTCONFIG.basePath + "info/GPS/GetCarCurrentStatusByWaybillId";
            var getMap = {driverId: orderId.id};
        }
        urls.sendRequest('POST', angular.toJson(getMap), urlMap, '').success(function (response) {
            if (ROOTCONFIG.debug) {
                console.log((response));
            }
            //[116.396574, 39.992706]
            if (response.code == '100') {
                $scope.gpsMapInfo = response.data;
                for (var i = 0; i < $scope.gpsMapInfo.length; i++) {
                    $scope.regeocoder($scope.gpsMapInfo[i]);
                }
            } else if (response.code = '101') {
                toaster.pop('waring', '提示', response.msg);
            } else if (response.code = '110') {
            }
        });
        $scope.add = function () {
            $modalInstance.dismiss('cancel');
        }
        $scope.regeocoder = function (item) {  //逆地理编码
            var geocoder = new AMap.Geocoder({
                radius: 1000,
                extensions: "all"
            });
            var lnglatXY = [item.last_lon, item.last_lat];
            geocoder.getAddress(lnglatXY, function (status, result) {
                if (status === 'complete' && result.info === 'OK') {
                    geocoder_CallBack(result);
                }
            });
            var marker = new AMap.Marker({  //加点
                map: map,
                position: lnglatXY
            });
            map.setZoomAndCenter(14, lnglatXY);
            marker.content = "车牌号:" + item.carMark;
            marker.on('click', markerClick);
            map.setFitView();
        }
        function geocoder_CallBack(data) {
            var address = data.regeocode.formattedAddress; //返回地址描述
            document.getElementById("result").innerHTML = address;
        }

        function markerClick(e) {
            infoWindow.setContent(e.target.content);
            infoWindow.open(map, e.target.getPosition());
        }
    }]);
//运单详情
chuanyang.controller('orderTrainDetailController', ['$scope', '$state', 'toaster', '$filter', 'urls', '$localStorage', 'orderDetailInfos',
    function ($scope, $state, toaster, $filter, urls, $localStorage, orderDetailInfos) {
        var urlTransportationList = ROOTCONFIG.basePath + "info/order/selectAboutOrd";
        var getDetail = {
            // waybillId: orderDetailInfos.waybillId
            waybillId: orderDetailInfos.waybillId
        }
        urls.sendRequest('POST', angular.toJson(getDetail), urlTransportationList, '').success(function (response) {
            if (ROOTCONFIG.debug) {
                console.log((response));
            }
            if (response.code == '100') {
                $scope.transportationDetail = response.data;
                if ($scope.transportationDetail.length == 0) {
                    toaster.pop('waring', '提示', '暂无运单');
                }
            } else if (response.code = '101') {

            } else if (response.code = '110') {

            }
        });
    }]);


//查看图片
chuanyang.controller('orderPictureController', ['$scope', '$state', 'toaster', '$filter', 'urls', '$localStorage', 'orderPictureInfos', '$modalInstance', '$modal',
    function ($scope, $state, toaster, $filter, urls, $localStorage, orderPictureInfos, $modalInstance, $modal) {
        $scope.orderPictureInfos = orderPictureInfos;
        $scope.confirm = function () {
            $modalInstance.dismiss('cancel');
        }
        $scope.bigPicture = function (img) {
            var modalInstance = $modal.open({
                templateUrl: 'pages/order/orderBigPictureModal.html',
                controller: 'orderBigPictureController',
                size: 'lg',
                scope: $scope,
                resolve: {
                    orderBigPictureInfos: function () {
                        return img;
                    }
                }
            });
        }
    }]);

//大图片
chuanyang.controller('orderBigPictureController', ['$scope', '$state', 'toaster', '$filter', 'urls', '$localStorage', 'orderBigPictureInfos', '$modalInstance', '$modal',
    function ($scope, $state, toaster, $filter, urls, $localStorage, orderBigPictureInfos, $modalInstance, $modal) {
        $scope.img = orderBigPictureInfos;
        $scope.confirm = function () {
            $modalInstance.dismiss('cancel');
        }
    }]);
//装船清单
chuanyang.controller('updateTrainOrderCtrl', ['$scope', '$modalInstance', 'trainOrder', '$localStorage', 'urls', 'toaster', function ($scope, $modalInstance, trainOrder, $localStorage, urls, toaster) {
    $scope.aboutdetails = angular.copy(trainOrder.aboutdetails);
    for (var i = 0; i < $scope.aboutdetails.length; i++) {
        $scope.aboutdetails[i].deleteId = guUUID();
    }
    console.log($scope.aboutdetails);
    $scope.confirm = function () {
        if ($scope.aboutdetails.length < 1) {
            toaster.pop('waring', '提示', '此运单没有货物!');
            return;
        }
        var urlTransportation = ROOTCONFIG.basePath + "info/waybill/updateWaybillDetailByZHJ";
        var getDetail =
        {
            "plateNumber": trainOrder.plateNumber,
            "waybillNo": trainOrder.waybillNo,
            "waybillId": trainOrder.waybillId,
            "entruckingStatus": trainOrder.waybillStatus,
            "orderDetails": []
        }
        for (var i = 0; i < $scope.aboutdetails.length; i++) {
            getDetail.orderDetails.push(
                {
                    "blastNo": $scope.aboutdetails[i].blastNo,
                    "goodsMaterial": $scope.aboutdetails[i].goodsMaterial,
                    "goodsName": $scope.aboutdetails[i].goodsName,
                    "goodsNo": $scope.aboutdetails[i].goodsNo,
                    "goodsNum": $scope.aboutdetails[i].detailsNum,
                    "goodsOrigin": $scope.aboutdetails[i].goodsOrigin,
                    "goodsStandard": $scope.aboutdetails[i].goodsStandard,
                    "goodsUnit": $scope.aboutdetails[i].goodsUnit,
                    "goodsWeight": $scope.aboutdetails[i].detailsWeight,
                    "outDoorNo": $scope.aboutdetails[i].blastNo
                }
            );
        }
        urls.sendRequest('POST', angular.toJson(getDetail), urlTransportation, '').success(function (response) {
            if (ROOTCONFIG.debug) {
                console.log((response));
            }
            if (response.code == '100') {
                toaster.pop('success', '提示', '修改成功!');
                $modalInstance.dismiss('cancel');
            } else if (response.code = '101') {

            } else if (response.code = '110') {

            }
        });
        $modalInstance.close($scope.items);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss();
    }
    $scope.config = {}
    $scope.modifyGoods = function (item) {
        $scope.config = {
            goodsNo: item.goodsNo,
            goodsName: item.goodsName,
            goodsStandard: item.goodsStandard,
            detailsNum: item.detailsNum,
            detailsWeight: item.detailsWeight,
            goodsUnit: item.goodsUnit,
            goodsOrigin: item.goodsOrigin,
            goodsMaterial: item.goodsMaterial,
            blastNo: item.blastNo,
            deleteId: item.deleteId
        };
    }
    $scope.updateTrainOrder = function () {
        if (isEmpty($scope.config.deleteId) || $scope.config.deleteId == undefined) {
            $scope.aboutdetails.push({
                goodsNo: $scope.config.goodsNo,
                goodsName: $scope.config.goodsName,
                goodsStandard: $scope.config.goodsStandard,
                detailsNum: $scope.config.detailsNum,
                detailsWeight: $scope.config.detailsWeight,
                goodsUnit: $scope.config.goodsUnit,
                goodsOrigin: $scope.config.goodsOrigin,
                goodsMaterial: $scope.config.goodsMaterial,
                blastNo: $scope.config.blastNo,
                deleteId: guUUID()
            });
        } else {
            for (var i = 0; i < $scope.aboutdetails.length; i++) {
                if ($scope.aboutdetails[i].deleteId == $scope.config.deleteId) {
                    $scope.aboutdetails[i] = {
                        goodsNo: $scope.config.goodsNo,
                        goodsName: $scope.config.goodsName,
                        goodsStandard: $scope.config.goodsStandard,
                        detailsNum: $scope.config.detailsNum,
                        detailsWeight: $scope.config.detailsWeight,
                        goodsUnit: $scope.config.goodsUnit,
                        goodsOrigin: $scope.config.goodsOrigin,
                        goodsMaterial: $scope.config.goodsMaterial,
                        blastNo: $scope.config.blastNo,
                        deleteId: $scope.aboutdetails[i].deleteId
                    }
                }
            }
        }
        $scope.config = {};
    }
    $scope.delete = function (item) {
        for (var i = 0; i < $scope.aboutdetails.length; i++) {
            if (item.deleteId == $scope.aboutdetails[i].deleteId) {
                $scope.aboutdetails.splice(i, 1);
            }
        }
    }
}]);

//弹窗控制器
chuanyang.controller('commonModelOrderCtrl', ['$scope', '$modalInstance', 'items', 'urls', function ($scope, $modalInstance, items, urls) {
    $scope.items = items;
    $scope.add = function () {
        $scope.selected = items;
        console.log($scope.selected);
        $modalInstance.close($scope.selected);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);


//弹窗控制器
chuanyang.controller('importGoodsOrderListCtrl', ['$scope', '$modalInstance', 'items', 'toaster', 'urls', function ($scope, $modalInstance, items, toaster, urls) {

    $scope.getGoodsInventory = [];
    $scope.isCollapsed = [];
    $scope.importGoodsInfo = [];
    $scope.hadSelect = [];
    $scope.plateNumber = "";
    $scope.mainListingNumber = "";
    $scope.orderItemNum = "";
    $scope.waybillNew = "";
    $scope.getGoodsInventoryList = function () {
        var getGoodsInventoryUrl = ROOTCONFIG.basePath + "info/waybill/getAllInventory";
        $scope.getGoodsInventoryParam = {
            "plateNumber": $scope.plateNumber,
            "mainListingNumber": $scope.mainListingNumber,
            "orderItemNum": $scope.orderItemNum
        };
        urls.sendRequest('POST', angular.toJson($scope.getGoodsInventoryParam), getGoodsInventoryUrl, '').success(function (response) {
            console.log(response);
            if (response.code == 100) {
                if (response.data.length == 0) {
                    toaster.pop('info', '提示', '没有查询到数据！', 3000);
                }
                angular.copy(response.data, $scope.getGoodsInventory);
                for (var i = 0; i < response.data.length; i++) {
                    $scope.hadSelect[i] = true;
                }
            } else {
                $scope.getGoodsInventory = [];
                toaster.pop('error', '提示', response.msg);
            }
        });
    };
    $scope.getGoodsInventoryList();
    $scope.refer = function () {
        $scope.getGoodsInventoryList();
    }
    //单选
    $scope.goodsSelect = function (index, data, flag) {
        if (flag != 1) {
            $scope.waybillNew = data.waybillId;
            for (var i = 0; i < $scope.getGoodsInventory.length; i++) {
                $scope.hadSelect[i] = true;
            }

        } else {
            $scope.waybillNew = "";
        }
        $scope.hadSelect[index] = !$scope.hadSelect[index];

    }

    $scope.goodInfoShow = function (index, data) {
        $scope.isCollapsed[index] = !$scope.isCollapsed[index]
        var goodInfoUrl = ROOTCONFIG.basePath + "info/waybill/selectByWaybillId";
        $scope.goodInfoParam = {
            "waybillId": data.waybillId
        };
        if ($scope.isCollapsed[index] == true) {
            urls.sendRequest('POST', angular.toJson($scope.goodInfoParam), goodInfoUrl, '').success(function (response) {
                if (response.code == 100) {
                    console.log(response);
                    angular.copy(response.data.data, $scope.importGoodsInfo);
                }
            })
        }
    }


    $scope.confirmImport = function () {
        var importGoodsUrl = ROOTCONFIG.basePath + "info/waybill/bindInventory";
        $scope.importGoodsParam = {
            "waybillOld": items.waybillId,
            "waybillNew": $scope.waybillNew
        };
        if ($scope.waybillNew == '') {
            toaster.pop('warning', '提示', '请先选择要导入的货品！', 3000);
            return;
        }
        urls.sendRequest('POST', angular.toJson($scope.importGoodsParam), importGoodsUrl, '').success(function (response) {
            if (response.code == 100) {
                toaster.pop('success', '提示', '导入成功！', 3000);
                $modalInstance.close();
            } else {
                toaster.pop('error', '提示', response.msg, 3000);
            }
        })
    }
}]);