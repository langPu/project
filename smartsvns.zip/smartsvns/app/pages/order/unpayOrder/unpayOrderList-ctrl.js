/**
 * Created by W on 2016/12/20.
 */
/**
 * Created by W on 2016/10/22.
 */
'use strict';

chuanyang.controller('unpayOrderListCtrl',['$scope','$modal','$localStorage','urls','$filter','toaster','$state','$cookieStore',function($scope,$modal,$localStorage,urls,$filter,toaster,$state,$cookieStore){
    $scope.shipperLists=[];
    $scope.showDown=[];
    $scope.showUp=[];
    $scope.isCollapsed=[];
    $scope.noDataShow=false;
    $scope.noChildDataShow=[];
    $scope.orderDetailsList=[];
    $scope.person={};
    $scope.person.disable=false;
    $scope.shipperOrder={};//订单用户
    $scope.allOrderSelected=false;
    $scope.singleSelected=[];//选择与否
    $scope.shipperOrder.orderNum=0;
    $scope.shipperOrder.orderAmount=0;
    $scope.orderSelectedList=[];//已选择的订单
    $localStorage.chuanYangloginMessege.orderInfo=[];
    $scope.sumAmount=0;
    $scope.currentPage = 1;
    $scope.person.payStatus=1;
    $scope.person.transportWays=[{"key":"1","name":"车运订单"},{"key":"2","name":"船运订单"}];
    $scope.person.pageNum = [{key:1,name:5},{key:2,name:20},{key:3,name:50},{key:4,name:100}];
    $scope.person.unpay_show = true;
    $scope.allOrderStatus = [
        {"type": "0", "status": "待摘牌"},
        {"type": "1", "status": "待分配"},
        {"type": "2", "status": "待装货"},
        {"type": "3", "status": "装货中"},
        {"type": "4", "status": "运输中"},
        {"type": "5", "status": "卸货中"},
        {"type": "6", "status": "待确认"},
        {"type": "7", "status": "已完成"},
        {"type": "8", "status": "已取消"},
        {"type": "-1", "status": "已删除"},
        {"type": "-2", "status": "重新下单"},
        {"type": "-3", "status": "人工下单"},
        {"type": "-4", "status": "人工干预"}
    ];
//日期
    $scope.cacleTask = function () {

    };
    $scope.today = function () {
        $scope.dt = new Date();
    };
    $scope.today();

    $scope.clear = function () {
        $scope.dt = null;
    };

    // Disable weekend selection
    $scope.disabled = function (date, mode) {
        return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
    };

    $scope.toggleMin = function () {
        $scope.minDate = $scope.minDate ? null : new Date();
    };
    $scope.toggleMin();


    $scope.open = function ($event,flag) {
        $event.preventDefault();
        $event.stopPropagation();
        if(flag==='start'){
            $scope.openedStart = true;
        }else{
            $scope.openedEnd = true;
        }

    };

    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1,
        class: 'datepicker',
        lang: 'zh-cn'
    };

    $scope.initDate = new Date('2016-15-20');
    $scope.formats = ['yyyy-MM-dd'];
    $scope.format = $scope.formats[0];

    if($localStorage.chuanYangloginMessege == undefined){
        $state.go('index.login');
    }else{
        $scope.user_type = $localStorage.chuanYangloginMessege.userType;
    };

    //订单展示
    $scope.shipperOrderShow=function(){
        $scope.shipperLists=[];
        $scope.hideLoading = false;
        var startTime=$filter('date')($scope.person.startDate,'yyyy-MM-dd');
        var endTime=$filter('date')($scope.person.endDate,'yyyy-MM-dd');
        if($localStorage.pageNumStore){
            $scope.pageNumValue = $localStorage.pageNumStore;
            $scope.person.pageNumKey = $localStorage.pageNumStore;
        }else{
            $scope.person.pageNumKey = 5;
            $scope.pageNumValue = $scope.person.pageNumKey;
        }

        $scope.shipperOrderParams={
            "userId":$localStorage.chuanYangloginMessege.userId,
            "transPortWay":$scope.person.transportWaySelect,
            "page":$scope.currentPage,
            "length":$scope.pageNumValue,
            "orderNo":$scope.person.orderNo,
            "orderStatus":7,
            "payStatus":$scope.person.payStatus,
            "startDate":startTime,
            "endDate":endTime
        };
        var shipperOrderUrl=ROOTCONFIG.basePath+"info/tPlanInfo/selectOrderInfo";

        console.log(angular.toJson($scope.shipperOrderParams));
        urls.sendRequest('POST', angular.toJson($scope.shipperOrderParams), shipperOrderUrl, '').success(function (response) {
            $scope.hideLoading = true;
            if(response.code==100){
                $scope.shipperLists=angular.copy(response.data.data);
                $scope.total=response.data.totalPages;

                if($scope.shipperLists==undefined) return false;
                for(var i=0;i<$scope.shipperLists.length;i++){
                    $scope.showDown[i]=true;
                    $scope.showUp[i]=false;
                    $scope.isCollapsed[i]=false;
                    if(!$scope.singleSelected[$scope.shipperLists[i].id]){
                        $scope.singleSelected[$scope.shipperLists[i].id]=false;
                    }

                }

                for(var n=0;n<$scope.shipperLists.length;n++){
                    if($scope.singleSelected[$scope.shipperLists[n].id]!=true){
                        $scope.allOrderSelected=false;
                        break;
                    }
                    $scope.allOrderSelected=true;
                }
                console.log($scope.allOrderSelected+"ppp");
                if($scope.shipperLists!=0){
                    $scope.noDataShow=false;
                }else{
                    $scope.noDataShow=true;
                }
            }else{
                toaster.pop('error','提示',response.msg);
            }
        })
    };
    $scope.changechoosed=function(flag){
     switch(flag){
     case '1':
     $scope.person.orderNo="";
     $scope.person.date="";
     $scope.person.orderAddressStart="";
     $scope.person.orderAddressEnd="";
     $scope.person.name="";
     $scope.person.number="";
     $scope.allOrder=true;
     $scope.routeOrder=false;
     $scope.finishOrder=false;
     $scope.person.payStatus=1;
     $scope.currentPage = 1;
     $scope.person.unpay_show = true;
     $scope.shipperOrderShow();
     break;
     case '2':
     $scope.person.orderNo="";
     $scope.person.date="";
     $scope.person.orderAddressStart="";
     $scope.person.orderAddressEnd="";
     $scope.person.name="";
     $scope.person.payStatus=0;
     $scope.allOrder=false;
     $scope.routeOrder=true;
     $scope.finishOrder=false;
     $scope.currentPage = 1;
     $scope.person.unpay_show = false;
     $scope.shipperOrderShow();
     break;
     case '3':
     $scope.person.orderNo="";
     $scope.person.date="";
     $scope.person.orderAddressStart="";
     $scope.person.orderAddressEnd="";
     $scope.person.name="";
     $scope.person.payStatus=2;
     $scope.allOrder=false;
     $scope.routeOrder=false;
     $scope.finishOrder=true;
     $scope.currentPage = 1;
     $scope.person.unpay_show = false;
     $scope.shipperOrderShow();
     break;
     }
     };
     $scope.changechoosed('1');
    //选择付款
    $scope.getSelected=function(status,items){
        if(status==false){
            $scope.singleSelected[items.id]=true;
            $scope.shipperOrder.orderNum++;
            $scope.orderSelectedList.push(items);
            $scope.sumAmount+=parseFloat(items.actualAmount);//

            for(var n=0;n<$scope.shipperLists.length;n++){
                if($scope.singleSelected[$scope.shipperLists[n].id]!=true){
                    $scope.allOrderSelected=false;
                    break;
                }

                $scope.allOrderSelected=true;
            }

        }else if(status==true){
            $scope.singleSelected[items.id]=false;
            $scope.allOrderSelected=false;
            if($scope.shipperOrder.orderNum==0) {
                $scope.shipperOrder.orderNum=0;
            }else{
                $scope.shipperOrder.orderNum--;
            }

            if($scope.sumAmount==0) {
                $scope.sumAmount=0;
            }else{
                $scope.sumAmount-=parseFloat(items.actualAmount);//
            }

            for(var i=0;i<$scope.orderSelectedList.length;i++){
                if(items.id==$scope.orderSelectedList[i].id){
                    $scope.orderSelectedList.splice(i,1);
                }
            }

        }else if(status=='all'){
            if($scope.allOrderSelected==false){
                $scope.allOrderSelected = true;
                for(var j=0;j<$scope.shipperLists.length;j++) {

                    if($scope.singleSelected[$scope.shipperLists[j].id] != true){//之前未选
                        $scope.orderSelectedList.push($scope.shipperLists[j]);
                        $scope.sumAmount += parseFloat($scope.shipperLists[j].actualAmount);//

                        $scope.shipperOrder.orderNum +=1;
                    }
                    $scope.singleSelected[$scope.shipperLists[j].id] = true;
                }

            }else{
                $scope.allOrderSelected = false;
                for(var k=0;k<$scope.shipperLists.length;k++){
                    $scope.sumAmount -= parseFloat($scope.shipperLists[k].actualAmount);//
                    $scope.singleSelected[$scope.shipperLists[k].id]=false;

                    /*   for(var m=0;m<$scope.orderSelectedList.length;m++){
                     if($scope.shipperLists[k].id==$scope.orderSelectedList[m].id){
                     $scope.orderSelectedList.splice(m,1);
                     }
                     }*/
                    $scope.orderSelectedList = [];
                }
                $scope.shipperOrder.orderNum -= Number($scope.shipperLists.length);
            }

        }
        $scope.shipperOrder.orderAmount=$scope.sumAmount.toFixed(2);
        $localStorage.chuanYangloginMessege.orderInfo=angular.copy($scope.orderSelectedList);

    }

    //去付款
    $scope.payOrder=function(){
        if($scope.orderSelectedList.length==0){
            toaster.pop('warning','提示','请选择要结算的订单！',5000);
            return;
        }
        for(var x=0;x<$scope.orderSelectedList.length;x++){
            for(var y=x+1;y<$scope.orderSelectedList.length;y++){
                if($scope.orderSelectedList[x].currency!=$scope.orderSelectedList[y].currency){
                    toaster.pop('warning','提示','请将货币类型不同的订单分开来结算！',5000);
                    return;
                }
            }
        };
        /* $scope.saveOrderInfo = $cookieStore.get('saveOrderInfo');
         if($scope.saveOrderInfo) $cookieStore.put('saveOrderInfo',null);*/
        $state.go('home.orderPay');
    }


    //查看
    $scope.getOrderDetails=function(data){
        $scope.items={
            "orderId":data.id
        }
        var modalInstance=$modal.open({
            templateUrl: 'pages/shipper/shipperList/shipperOrderDetail.html',
            controller: 'unpayOrderModelCtrl',
            size:'lg',
            resolve: {
                items: function () {
                    return $scope.items;
                }
            }
        });
    };


//查询
    $scope.refer=function(){
        $scope.currentPage = 1;
        $scope.shipperOrderShow();

    }
//页数控制
    $scope.pageChanged = function(){
        $localStorage.pageNumStore = $scope.person.pageNumKey;
        $scope.shipperOrderShow();
    };
    //分页
    $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
        $scope.currentPage = page;
        $scope.shipperOrderShow($scope.currentPage);
        console.log(page);
        console.log(pageSize);
    };
}]);

//弹窗控制器
chuanyang.controller('unpayOrderModelCtrl', ['$scope', '$modalInstance', 'items', 'urls', function ($scope, $modalInstance, items, urls) {
    $scope.items = items;
    $scope.noDriver = true;
    $scope.serivce = true;
    $scope.noTransPortType = true;
    $scope.add = function () {
        $scope.selected = items;
        console.log($scope.selected);
        $modalInstance.close($scope.selected);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    //订单详情
    $scope.singleOrderDetails = [];

    var getSingleOrderUrl = ROOTCONFIG.basePath + "info/order/selOrderUsernfd";
    $scope.getSingleOrderParam = {
        "orderId": $scope.items.orderId
    };
    console.log(angular.toJson($scope.getSingleOrderParam));
    urls.sendRequest('POST', angular.toJson($scope.getSingleOrderParam), getSingleOrderUrl, '').success(function (response) {
        if (response.code == 100) {
            console.log('%c' + angular.toJson(response, true), ['color:#f00'].join(','));
            $scope.singleOrderDetails = angular.copy(response.data[0]);
            if (response.data[0].transPortWay == "" || response.data[0].transPortWay == undefined) {
                $scope.noTransPortType = true;
            } else {
                $scope.noTransPortType = false;
            }
        }
    })


}]);

//弹窗控制器
//chuanyang.controller('unpayOrderCommonModelCtrl', ['$scope', '$modalInstance', 'items','urls',function ($scope, $modalInstance, items,urls) {
//    $scope.items = items;
//    $scope.add = function () {
//        $scope.selected = items;
//        console.log($scope.selected);
//        $modalInstance.close($scope.selected);
//    };
//    $scope.cancel = function () {
//        $modalInstance.dismiss('cancel');
//    };
//}]);