/**
 * Created by admin on 2016/10/23.
 */

chuanyang.controller('allocationOrderController', ['$scope', 'transportationList', 'transportationChildList', 'orderList', 'urls', '$state', '$modal', 'toaster', '$filter', '$localStorage',
    function ($scope, transportationList, transportationChildList, orderList, urls, $state, $modal, toaster, $filter, $localStorage) {
        if (ROOTCONFIG.debug) {
            console.log("into twiceAllocationController...");
            console.log(angular.toJson($state.current.url, true));
        }
        $scope.config = {
            //查询条件
            orderCode: "",
            orderId: "",
            startTime: "",
            endTime: "",
            startArea: "",
            endArea: "",

            openedStart: false,
            openedEnd: false,

            selectOrderInfos: []
        };
        $scope.functionName = $state.current.url;
        $scope.pageSize = 10;
        $scope.total = 0;
        $scope.currentPage = 1;

        $scope.formats = ['yyyy-MM-dd'];
        $scope.format = $scope.formats[0];

        $scope.cancleOrder = function(){
            $scope.rootConfig = {
                orderNum: 0,
                orderDetail: []
            };
            $scope.config.selectOrderInfos = [];
            $scope.searchOrderList();
        }
        //
        if($localStorage.chuanYangloginMessege == undefined){
            $state.go('index.login');
        }else{
            $scope.user_type = $localStorage.chuanYangloginMessege.userType;
        }

        //查询  waring success error
        $scope.searchOrderList = function () {
            var getPlan = {
                "userId": $localStorage.chuanYangloginMessege.userId,
                "noticeNo": $scope.config.orderCode,
                "startTime": serverFormateDate($scope.config.startTime),
                "endTime": serverFormateDate($scope.config.endTime),
                "fromCity": $scope.config.startArea,
                "toCity": $scope.config.endArea,
                // "flow": $scope.config.endArea,
                "page": $scope.currentPage,
                "length": $scope.pageSize,
                "commodityName" : $scope.config.commodityName,
                "leftDeliWare" : $scope.config.leftDeliWare,
                "rightDeliWare" : $scope.config.rightDeliWare,
                "deliwareHouse" : $scope.config.deliwareHouse

            };
            searchOrderListData(getPlan);
        }
        $scope.searchOrderList();
        function searchOrderListData(getPlan) {
            toaster.pop("wait", "提示", "正在查询...", 60000);
            var urlTransportationList = ROOTCONFIG.basePath + "info/tPlanInfo/select";
            urls.sendRequest('POST', angular.toJson(getPlan), urlTransportationList, '').success(function (response) {
                toaster.clear();
                if (ROOTCONFIG.debug) {
                    console.log((response));
                }
                if (response.code == '100') {
                    $scope.total = response.data.plans.total;
                    $scope.weightAdd = response.data.sumWeight;
                    $scope.weightAddOrder = response.data.sumDownOrder;
                    $scope.transportationList = response.data.plans.data;
                    $scope.isCollapsed = [];
                    for (var i = 0; i < $scope.transportationList.length; i++) {
                        if ($scope.transportationList[i].surplusWeight <= 0 ) {
                            $scope.transportationList[i].hideButton = true;
                        } else {
                            $scope.transportationList[i].hideButton = false;
                        }
                        $scope.transportationList[i].goOrderButton = false;
                        $scope.transportationList[i].selected == false;
                        $scope.isCollapsed[i] = true;
                        $scope.transportationChildList.push([]);
                    }
                } else if (response.code = '101') {
                    toaster.pop('waring', '提示', response.msg);
                } else if (response.code = '110') {

                }
            });
        }

        function searchOrderNumListData(item, add, index) {
            var urlTransportationChildList = ROOTCONFIG.basePath + "info/tPlanInfo/selectTPlanGoodsRelate?planId=" + item.planId;
            urls.sendRequest('get', '', urlTransportationChildList, '').success(function (response) {
                if (ROOTCONFIG.debug) {
                    console.log((response));
                }
                if (response.code == '100') {
                    $scope.transportationChildList[index] = response.data;
                // || $scope.transportationChildList[index][i].surplusNum <= 0
                    for (var i = 0; i < $scope.transportationChildList[index].length; i++) {
                        if ($scope.transportationChildList[index][i].surplusWeight <= 0 ) {
                            $scope.transportationChildList[index][i].showSelectd = true;
                        } else {
                            $scope.transportationChildList[index][i].showSelectd = false;
                        }
                    }
                    if (item.selected === true) {
                        var addInfo = [];
                        for (var i = 0; i < $scope.transportationChildList[index].length; i++) {
                            $scope.transportationChildList[index][i].selected = true;
                            if ($scope.transportationChildList[index][i].showSelectd != true) {
                                addInfo.push($scope.transportationChildList[index][i]);
                            }
                        }
                        if (add != 'no') {
                            $scope.config.selectOrderInfos.push({
                                transOrder: item,
                                proOrder: angular.copy(addInfo),
                                proOrderDetail: []
                            });
                        }
                    } else {
                        for (var i = 0; i < $scope.transportationChildList[index].length; i++) {
                            $scope.transportationChildList[index][i].selected = false;
                        }
                    }
                    $scope.rootConfig.orderDetail = $scope.config.selectOrderInfos;
                    $scope.rootConfig.orderNum = 0;
                    console.log($scope.rootConfig.orderDetail);
                    for (var i = 0; i < $scope.rootConfig.orderDetail.length; i++) {
                        $scope.rootConfig.orderNum += $scope.rootConfig.orderDetail[i].proOrder.length;
                    }
                } else if (response.code = '101') {
                    toaster.pop('waring', '提示', response.msg);
                } else if (response.code = '110') {

                }
            });
        }

        $scope.isCollapsed = [];
        $scope.orderList = [];
        $scope.transportationList = [];
        $scope.transportationChildList = [];
        for (var i = 0; i < $scope.transportationList.length; i++) {
            $scope.isCollapsed[i] = true;
        }

        $scope.getAllocationPlan = function (index, item) {
            $scope.isCollapsed[index] = !$scope.isCollapsed[index];
            if ($scope.isCollapsed[index] === false) {
                searchOrderNumListData(item, 'no', index);
            }
            if ($scope.transportationList[index].selected === true) {
                for (var i = 0; i < $scope.transportationChildList.length; i++) {
                    $scope.transportationChildList[i].selected = true;
                }
            }
        };

        //选择全选
        $scope.selectOrCancle = function (item, index) {
            for (var i = 0; i < $scope.config.selectOrderInfos.length; i++) {
                if ($scope.config.selectOrderInfos[i].transOrder.flow != item.flow) {
                    toaster.pop('waring', '提示', '流向不同,无法新建分配');
                    return;
                }
            }
            console.log(angular.toJson(item, true));
            item.selected = !item.selected;
            //全选状态
            if (item.selected === true) {
                var flagOrder = 0;
                for (var i = 0; i < $scope.config.selectOrderInfos.length; i++) {
                    if ($scope.config.selectOrderInfos[i].transOrder.planId === item.planId) {
                        $scope.config.selectOrderInfos.splice(i, 1);
                    }
                }
                if (flagOrder === 0) {
                    searchOrderNumListData(item, 'add', index);
                }
            } else {
                for (var i = 0; i < $scope.config.selectOrderInfos.length; i++) {
                    if ($scope.config.selectOrderInfos[i].transOrder.planId === item.planId) {
                        $scope.config.selectOrderInfos.splice(i, 1);
                    }
                }
                searchOrderNumListData(item, 'less', index);
            }
        }
        //选择单选
        $scope.selectOrCancleChild = function (item, data) {
            for (var i = 0; i < $scope.config.selectOrderInfos.length; i++) {
                if ($scope.config.selectOrderInfos[i].transOrder.flow != item.flow) {
                    toaster.pop('waring', '提示', '流向不同,无法新建分配');
                    return;
                }
            }
            data.selected = !data.selected;
            //单个选中
            if (data.selected === true) {
                var flag = 0;
                var flagGoods = 0;
                for (var i = 0; i < $scope.config.selectOrderInfos.length; i++) {
                    console.log(item);
                    if ($scope.config.selectOrderInfos[i].transOrder.planId === item.planId) {
                        console.log(item.planId);
                        flagGoods = 1;
                        $scope.config.selectOrderInfos[i].proOrder.push(data);
                        for (var j = 0; j < $scope.config.selectOrderInfos[i].proOrder.length; j++) {
                            if ($scope.config.selectOrderInfos[i].proOrder[j].selected === false) {
                                flag = 1;
                            }
                        }
                    }
                }
                if (flag === 1) {
                    item.selected = false;
                }
                if (flagGoods === 0) {
                    $scope.config.selectOrderInfos.push({
                        transOrder: item,
                        proOrder: [data],
                        proOrderDetail: []
                    });
                }
            } else {
                item.selected = false;
                for (var i = 0; i < $scope.config.selectOrderInfos.length; i++) {
                    if ($scope.config.selectOrderInfos[i].transOrder.noticeNo === item.noticeNo) {
                        for (var j = 0; j < $scope.config.selectOrderInfos[i].proOrder.length; j++) {
                            if ($scope.config.selectOrderInfos[i].proOrder[j].relateId == data.relateId) {
                                $scope.config.selectOrderInfos[i].proOrder.splice(j, 1);
                            }
                        }
                    }
                }
            }
            $scope.rootConfig.orderDetail = $scope.config.selectOrderInfos;
            $scope.rootConfig.orderNum = 0;
            console.log($scope.rootConfig.orderDetail);
            for (var i = 0; i < $scope.rootConfig.orderDetail.length; i++) {
                $scope.rootConfig.orderNum += $scope.rootConfig.orderDetail[i].proOrder.length;
            }
        }
        //选择时间的
        $scope.open = function ($event, item) {
            $event.preventDefault();
            $event.stopPropagation();
            if (item == 'start') {
                $scope.config.openedStart = true;
            } else {
                $scope.config.openedEnd = true;

            }
        };
        function serverFormateDate(dateObject) {
            if (angular.isUndefined(dateObject) || dateObject == null) {
                return '';
            }
            return $filter('date')(dateObject, 'yyyy/MM/dd');
        };

        $scope.selectTransPortWay = function () {
            var modalInstance = $modal.open({
                templateUrl: 'creatOrUpdateOrderModal.html',
                controller: 'creatOrUpdateOrderCtrl',
                size: 'lg',
                scope: $scope
            });
        }

        //分页
        $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
            $scope.currentPage = page;
            $scope.searchOrderList();
            console.log("分页点击：" + text + page + pageSize + total);
        };
        $scope.deletePro = function () {
            $scope.orderInfo = {
                "title": "提示",
                "tips": "确定删除？"
            }
            var modalInstance = $modal.open({
                templateUrl: 'orderModal.html',
                controller: 'orderModelCtrl',
                size: 'sm',
                resolve: {
                    orderInfo: function () {
                        return $scope.orderInfo;
                    }
                }
            });
        }
        $scope.seeCreatOrUpdateOrderModal = function () {
            if ($scope.rootConfig.orderNum == 0) {
                toaster.pop('waring', '提示', '请选择分配的货物!');
                return;
            }
            var modalInstance = $modal.open({
                templateUrl: 'pages/order/creatOrUpdateOrderModal.html',
                controller: 'creatOrUpdateOrderCtrl',
                size: 'lg',
                scope: $scope,
                resolve:{
                    user_type:function() {
                        return $scope.user_type;
                    }
                }
            });
            modalInstance.result.then(function (info) {
                    $scope.searchOrderList();
            });
        }
        $scope.goOrder = function(){
            // var arr = [];
            // for(var i=0;i<$scope.transportationList.length;i++){
            //     if($scope.transportationList[i].goOrderButton == true){
            //         arr.push($scope.transportationList[i].noticeNo);
            //     }
            // }
            // if(arr.length < 1){
            //     toaster.pop("waring", "提示", "请选择发货通知单号!");
            //     return;
            // }
            // for(var i=0;i<arr.length;i++){
            //     if(arr[i] != arr[0]){
            //         toaster.pop("waring", "提示", "发货通知单号不通,不能下单!");
            //         return;
            //     }
            // }
            // var orderTrainMessage = arr[0];
            // console.log(orderTrainMessage);
            // $state.go('home.platformOrder',{orderTrainMessage: orderTrainMessage,planId : $scope.transportationList[0].planId});
            $state.go('home.platformOrder',{orderTrainMessage: '',planId : ''});
        }
        $scope.selectGoOrder = function(item){
            item.goOrderButton = !item.goOrderButton;
            var urlTransportationChildList = ROOTCONFIG.basePath + "info/tPlanInfo/selectTPlanGoodsRelate?planId=" + item.planId;
            urls.sendRequest('get', '', urlTransportationChildList, '').success(function (response) {
                if (response.code == '100') {
                    if(response.data.length > 0){
                        item.noticeNo = response.data[0].noticeNo;
                    }
                    console.log(item);
                } else if (response.code = '101') {

                } else if (response.code = '110') {

                }
            });
        }
    }]);


chuanyang.controller('creatOrUpdateOrderCtrl', ['$scope', '$modalInstance', 'urls', '$modal', '$state', '$localStorage', '$filter', 'toaster','user_type', function ($scope, $modalInstance, urls, $modal, $state, $localStorage, $filter, toaster,user_type) {
    $scope.config = {
        money: null,
        mark: '',
        transCar: null,
        transBoat: null,
        Logistics: null,
        flow: null,
        stevedoreDay: null,
        demurrage: null,
        loadDate: null,
        orderType: null,
        transPortWay: 1,
        expiredTime: null,
        payWay: null,
        consignationMode: null,
        otherService: null,
        services: null
    };
    $scope.config.flow = $scope.rootConfig.orderDetail[0].transOrder.flow;
    for (var i = 0; i < $scope.rootConfig.orderDetail.length; i++) {
        if ($scope.rootConfig.orderDetail[i].proOrder.length < 1) {
            $scope.rootConfig.orderDetail.splice(i, 1);
        }
    }
    var item = {"listId": []};
    for (var i = 0; i < $scope.rootConfig.orderDetail.length; i++) {
        for (var j = 0; j < $scope.rootConfig.orderDetail[i].proOrder.length; j++) {
            item.listId.push($scope.rootConfig.orderDetail[i].proOrder[j].relateId);
        }
    }
    //获取产品信息列表
    var urlOrderList = ROOTCONFIG.basePath + "info/planGoodAddress/planGoodAddressList";
    urls.sendRequest('POST', angular.toJson(item), urlOrderList, '').success(function (response) {
        if (ROOTCONFIG.debug) {
            console.log((response));
        }
        if (response.code == '100') {
            $scope.orderDetailCopy = angular.copy($scope.rootConfig.orderDetail);
            console.log($scope.orderDetailCopy);
            $scope.viewArray = {};
            $scope.viewArray.arrayFlag = [];
            var proDetailInfo = response.data;
            for (var i = 0; i < $scope.orderDetailCopy.length; i++) {
                $scope.viewArray.arrayFlag[i] = [];
                for (var j = 0; j < $scope.orderDetailCopy[i].proOrder.length; j++) {
                    for (var k = 0; k < proDetailInfo.length; k++) {
                        if (proDetailInfo[k].id == $scope.orderDetailCopy[i].proOrder[j].relateId) {
                            $scope.orderDetailCopy[i].proOrderDetail.push(proDetailInfo[k]);
                        }
                    }
                }

                for (var h = 0; h < $scope.orderDetailCopy[i].proOrderDetail.length; h++) {
                    $scope.viewArray.arrayFlag[i][h] = $scope.orderDetailCopy[i].proOrderDetail[h].surplusWeight
                }
            }
        } else if (response.code = '101') {

        } else if (response.code = '110') {

        }
    });
    //初始化数据
    $scope.showSelectMotorcade = [];

    //初始化运输方式 车队  物流
    $scope.orderParam = {};
    $scope.selectTransPortWay = function (select) {
        //初始化数据
        $scope.showSelectMotorcade = [];
        if (select === "motorcade") {
            $scope.orderParam.transPortWay = 'motorcade';
            $scope.boatMotorcade = false;
            $scope.carMotorcade = true;
            $scope.motorcade = false;
        } else if (select === "boat") {
            $scope.orderParam.transPortWay = 'boat';
            $scope.boatMotorcade = true;
            $scope.carMotorcade = false;
            $scope.motorcade = false;
        } else {
            $scope.orderParam.transPortWay = 'logistics';
            $scope.boatMotorcade = false
            $scope.carMotorcade = false;
            $scope.motorcade = true;
        }
    };
    $scope.selectTransPortWay('motorcade');
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    //获取车队 列表
    var param = {
        "userId": $localStorage.chuanYangloginMessege.userId,
        // "userId": 151

        "page": 1,
        "length": 10000,
        "fleetType": '2'
    };
    var urlTransportationList = ROOTCONFIG.basePath + "info/transportPlanning/getFleetByUserId";
    urls.sendRequest('POST', angular.toJson(param), urlTransportationList, '').success(function (response) {
        if (ROOTCONFIG.debug) {
            console.log((response));
        }
        if (response.code == '100') {
            $scope.motorcadeCompanyList = response.data;
        } else if (response.code = '101') {

        } else if (response.code = '110') {

        }
    });
    //获取船队 列表
    var paramBoat = {
        "userId": $localStorage.chuanYangloginMessege.userId,
        // "userId": 151

        "page": 1,
        "length": 10000,
        "fleetType": '3'
    };
    var urlTransportationListBoat = ROOTCONFIG.basePath + "info/transportPlanning/getFleetByUserId";
    urls.sendRequest('POST', angular.toJson(paramBoat), urlTransportationListBoat, '').success(function (response) {
        if (ROOTCONFIG.debug) {
            console.log((response));
        }
        if (response.code == '100') {
            $scope.motorcadeCompanyListBoat = response.data;
        } else if (response.code = '101') {

        } else if (response.code = '110') {

        }
    });
    //获取物流公司
    var urlLogisticsList = ROOTCONFIG.basePath + "info/lgCompany/getCooperateCompany";
    urls.sendRequest('POST', angular.toJson(param), urlLogisticsList, '').success(function (response) {
        if (ROOTCONFIG.debug) {
            console.log((response));
        }
        if (response.code == '100') {
            $scope.logisticsCompanyList = response.data.data;
        } else if (response.code = '101') {

        } else if (response.code = '110') {

        }
    });

    //选择 某一个车队
    $scope.selectMotorcade = function (select, item) {
        $scope.showSelectMotorcade = [];
        for (var i = 0; i < $scope.motorcadeCompanyList.length; i++) {
            if (i === select) {
                $scope.showSelectMotorcade[i] = true;
            } else {
                $scope.showSelectMotorcade[i] = false;
            }
        }
        $scope.config.transCar = item;
    };
    //选择 某一个chuan队
    $scope.selectMotorcadeBoat = function (select, item) {
        $scope.showSelectMotorcadeBoat = [];
        for (var i = 0; i < $scope.motorcadeCompanyListBoat.length; i++) {
            if (i === select) {
                $scope.showSelectMotorcadeBoat[i] = true;
            } else {
                $scope.showSelectMotorcadeBoat[i] = false;
            }
        }
        $scope.config.transBoat = item;
        console.log($scope.config.transBoat);
    };
    //选择 某一个物流公司
    $scope.selectLogistics = function (select, item) {
        $scope.showSelectLogistics = [];
        for (var i = 0; i < $scope.logisticsCompanyList.length; i++) {
            if (i === select) {
                $scope.showSelectLogistics[i] = true;
            } else {
                $scope.showSelectLogistics[i] = false;
            }
        }
        $scope.config.Logistics = item;
    };
    $scope.open = function ($event, item) {
        $event.preventDefault();
        $event.stopPropagation();
        if (item == 'start') {
            $scope.config.openedStart = true;
        } else {
            $scope.config.openedEnd = true;
        }
    };
    $scope.deletePro = function (order, pro) {
        $scope.orderInfo = {
            "title": "提示",
            "tips": "确定删除？"
        }
        var modalInstance = $modal.open({
            templateUrl: 'orderModal.html',
            controller: 'orderModelCtrl',
            size: 'sm',
            resolve: {
                orderInfo: function () {
                    return $scope.orderInfo;
                }
            }
        });
        modalInstance.result.then(function (deleteInfo) {
            if (deleteInfo == "delete") {
                for (var i = 0; i < $scope.orderDetailCopy.length; i++) {
                    if (order.transOrder.noticeNo == $scope.orderDetailCopy[i].transOrder.noticeNo) {
                        for (var j = 0; j < $scope.orderDetailCopy[i].proOrderDetail.length; j++) {
                            if (pro.id === $scope.orderDetailCopy[i].proOrderDetail[j].id) {
                                $scope.orderDetailCopy[i].proOrderDetail.splice(j, 1);
                                $scope.viewArray.arrayFlag[i].splice(j, 1);
                            }
                        }
                    }
                }
            }
        }, function () {
        });
    };
    $scope.checkDate = function (indexFa, indexCh, data) {
        console.log(indexFa, indexCh, data);
        if (parseFloat(data) > $scope.orderDetailCopy[indexFa].proOrderDetail[indexCh].surplusWeight) {
            toaster.pop("waring", "提示", "重量必须低于或者等于总重量!");
            $scope.viewArray.arrayFlag[indexFa][indexCh] = $scope.orderDetailCopy[indexFa].proOrderDetail[indexCh].surplusWeight;
        } else if (parseFloat(data) <= 0) {
            toaster.pop("waring", "提示", "重量必须大于0!");
            $scope.viewArray.arrayFlag[indexFa][indexCh] = $scope.orderDetailCopy[indexFa].proOrderDetail[indexCh].surplusWeight;
        }
        $scope.changePrice('s');
        $scope.changeNum();
    };
    //选择订单类型
    $scope.selectOrderType = function (type) {
        switch (type) {
            case 1://竞价订单
                $scope.config.orderType = "1";
                $("#one").css({"background-color": "", "color": "#000000"});
                $("#two").css({"background-color": "", "color": "#000000"});
                $("#three").css({"background-color": "#EC6E69", "border-color": "#FFFFFF", "color": "#FFFFFF"});
                $("#four").css({"background-color": "", "color": "#000000"});
                break;
            case 2://匹配订单
                $scope.config.orderType = "2";
                $("#one").css({"background-color": "#EC6E69", "border-color": "#FFFFFF", "color": "#FFFFFF"});
                $("#two").css({"background-color": "", "color": "#000000"});
                $("#three").css({"background-color": "", "color": "#000000"});
                $("#four").css({"background-color": "", "color": "#000000"});
                break;
            case 3://专线推送
                $scope.config.orderType = "3";
                $("#one").css({"background-color": "", "color": "#000000"});
                $("#two").css({"background-color": "#EC6E69", "border-color": "#FFFFFF", "color": "#FFFFFF"});
                $("#three").css({"background-color": "", "color": "#000000"});
                $("#four").css({"background-color": "", "color": "#000000"});
                $scope.selectTransPortWay('motorcade');
                break;
            case 4://计划单
                $scope.config.orderType = "4";
                $("#one").css({"background-color": "", "color": "#000000"});
                $("#two").css({"background-color": "", "color": "#000000"});
                $("#three").css({"background-color": "", "color": "#000000"});
                $("#four").css({"background-color": "#EC6E69", "border-color": "#FFFFFF", "color": "#FFFFFF"});
                $scope.selectTransPortWay('logistics');
                break;
        }
    };
    // $scope.selectOrderType(4);
    //支付方式
    $scope.selectPayMethod = function (payNum) {
        switch (payNum) {
            case 0:
                $scope.config.payWay = "0";
                $("#payOne").css({"background-color": "#EC6E69", "color": "#FFFFFF"});
                $("#payTwo").css({"background-color": "", "color": "#000000"});
                break;
            case 1:
                $scope.config.payWay = "1";
                $("#payOne").css({"background-color": "", "color": "#000000"});
                $("#payTwo").css({"background-color": "#EC6E69", "color": "#FFFFFF"});
                break;
        }
    };
    //委托方式
    $scope.entrustWay = function (Num) {
        switch (Num) {
            case 1:
                $scope.config.consignationMode = "1";
                $("#entrustWayOne").css({"background-color": "#EC6E69", "color": "#FFFFFF"});
                $("#entrustWayTwo").css({"background-color": "", "color": "#000000"});
                break;
            case 2:
                $scope.config.consignationMode = "2";
                $("#entrustWayOne").css({"background-color": "", "color": "#000000"});
                $("#entrustWayTwo").css({"background-color": "#EC6E69", "color": "#FFFFFF"});
                break;
        }
    };
    //其他服务
    $scope.selectX = false;
    $scope.selectD = false;
    $scope.selectK = false;
    $scope.selectG = false;
    $scope.trainSelect = [
        {train: false, name: '全挂', id: 1},
        {train: false, name: '半挂', id: 2},
        {train: false, name: '自卸', id: 3},
        {train: false, name: '箱式', id: 4},
        {train: false, name: '平板', id: 5},
        {train: false, name: '集装箱', id: 6},
        {train: false, name: '特殊', id: 7},
        {train: false, name: '普通', id: 8},
        {train: false, name: '其他', id: 9}
    ]
    $scope.selectTrain = function (id) {
        for (var i = 0; i < $scope.trainSelect.length; i++) {
            if (id == $scope.trainSelect[i].id) {
                $scope.trainSelect[i].train = true;
            } else {
                $scope.trainSelect[i].train = false;
            }
        }
    }
    $scope.selectOther = function (item) {
        if (item == '1') {
            $scope.config.otherService = "需要装卸";
            $scope.selectX = !$scope.selectX;
        } else if (item == '2') {
            $scope.config.otherService = "需要回单";
            $scope.selectD = !$scope.selectD;
        } else if (item == '3') {
            $scope.config.otherService = "代收货款";
            $scope.selectK = !$scope.selectK;
        } else if (item == '4') {
            $scope.config.otherService = "运输工具";
            $scope.selectG = !$scope.selectG;
            if ($scope.selectG == false) {
                for (var i = 0; i < $scope.trainSelect.length; i++) {
                    $scope.trainSelect[i].train = false;
                }
            }
        }
    }
    $scope.payOrder = function () {
        toaster.pop("wait", "提示", "正在加载...", 60000);
        var services = [];
        if ($scope.selectX == true) {
            services.push('需要装卸');
        }
        if ($scope.selectD == true) {
            services.push('需要回单');
        }
        if ($scope.selectK == true) {
            services.push('代收货款');
        }
        if ($scope.selectG == true) {
            for (var i = 0; i < $scope.trainSelect.length; i++) {
                if ($scope.trainSelect[i].train == true) {
                    services.push($scope.trainSelect[i].name);
                }
            }
        }
        if (services.length > 0) {
            $scope.config.services = services.join(',');
        }
        if ($scope.config.orderType == null) {
            toaster.pop("waring", "提示", "请选择订单类型!");
            return;
        }
        if ($scope.config.price == null) {
            toaster.pop("waring", "提示", "请输入吨价!");
            return;
        }
        if ($scope.config.orderType == "1" && $scope.config.expiredTime == null) {
            toaster.pop("waring", "提示", "请输入过期时间!");
            return;
        }
        if ($scope.carMotorcade === true) {
            if ($scope.config.orderType == "3") {
                if ($scope.config.transCar == null) {
                    toaster.pop("waring", "提示", "请选择车队!");
                    return;
                }
            }
            for (var i = 0; i < $scope.orderDetailCopy.length; i++) {
                for (var j = 0; j < $scope.orderDetailCopy[i].proOrderDetail.length; j++) {
                    if ($scope.orderDetailCopy[i].proOrderDetail[j].endCity != $scope.orderDetailCopy[0].proOrderDetail[0].endCity) {
                        toaster.pop("waring", "提示", "所选货品的目的地不同!");
                        return;
                    }
                }
            }
            //车队  订单
            if ($scope.config.transCar == null || $scope.config.transBoat == '') {
                var fleetId = '';
            } else {
                var fleetId = $scope.config.transCar.id;
            }
            var infosOrderTrain = {
                "passPoint": [
                    {
                        "address": $scope.orderDetailCopy[0].proOrderDetail[0].address,
                        "city": $scope.orderDetailCopy[0].proOrderDetail[0].city,
                        "contactPerson": $scope.orderDetailCopy[0].proOrderDetail[0].name,
                        "contactPhone": $scope.orderDetailCopy[0].proOrderDetail[0].phone,
                        "detailAdress": $scope.orderDetailCopy[0].proOrderDetail[0].detailAdress,
                        "latAndLng": $scope.orderDetailCopy[0].proOrderDetail[0].latAndLng,
                        "pointType": "e",
                        "province": $scope.orderDetailCopy[0].proOrderDetail[0].province,
                        "regions": ""
                    }
                ],
                "flow": $scope.orderDetailCopy[0].transOrder.flow,
                "orderPerson": $localStorage.chuanYangloginMessege.userId,
                "remark": $scope.config.mark,
                "orderAmount": $scope.config.orderAmount,
                "price": $scope.config.price,
                "endTime": $filter('date')(new Date(), 'yyyy-MM-dd'),
                "startTime": $filter('date')(new Date(), 'yyyy-MM-dd'),
                "orderDetails": [],
                "sPoint": $scope.orderDetailCopy[0].transOrder.sPoint.id,
                "orderType": $scope.config.orderType,
                "fleetId": fleetId,
                "transPortWay": "1",
                "payWay": $scope.config.payWay,
                "orderStatus": "0",
                "consignationMode": $scope.config.consignationMode,
                "expiredTime": $scope.config.expiredTime,
                "services": $scope.config.services,
                "currency" : $scope.config.currency,
                "assignment" : $scope.config.assignment
            }
            for (var i = 0; i < $scope.orderDetailCopy.length; i++) {
                for (var j = 0; j < $scope.orderDetailCopy[i].proOrderDetail.length; j++) {
                    infosOrderTrain.orderDetails.push({
                        "id": $scope.orderDetailCopy[i].proOrderDetail[j].id,
                        "noticeNo": $scope.orderDetailCopy[i].proOrderDetail[j].noticeNo,
                        "orderItemNum" :$scope.orderDetailCopy[i].proOrderDetail[j].orderItemNum,
                        "material": $scope.orderDetailCopy[i].proOrderDetail[j].material,
                        "commodityName": $scope.orderDetailCopy[i].proOrderDetail[j].commodityName,
                        "goodsNo": $scope.orderDetailCopy[i].proOrderDetail[j].materialNo,
                        "number": $scope.orderDetailCopy[i].proOrderDetail[j].surplusNum,
                        "goodsOrigin": $scope.orderDetailCopy[i].proOrderDetail[j].goodsOrigin + $scope.orderDetailCopy[i].proOrderDetail[j].material,
                        "standard": $scope.orderDetailCopy[i].proOrderDetail[j].standard,
                        "pack": $scope.orderDetailCopy[i].proOrderDetail[j].pack,
                        "weight": $scope.viewArray.arrayFlag[i][j],
                        "planId": $scope.orderDetailCopy[i].transOrder.planId

                    });
                }
            }
            /*---1---*/
            if(user_type==1){
                infosOrderTrain.custId = $localStorage.chuanYangloginMessege.userId;
            }else if(user_type==3){
                infosOrderTrain.custId = $localStorage.chuanYangloginMessege.companys[0].companyID;
            }
            var urlOrderSave = ROOTCONFIG.basePath + "info/order/saveOrderByPlan";
            urls.sendRequest('POST', angular.toJson(infosOrderTrain), urlOrderSave, '').success(function (response) {
                toaster.clear();
                if (ROOTCONFIG.debug) {
                    console.log(angular.toJson(response, true));
                }
                if (response.code == '100') {
                    toaster.pop("success", "提示", response.msg);
                } else if (response.code = '101') {
                    toaster.pop("error", "提示", response.msg);
                } else if (response.code = '110') {
                    toaster.pop("error", "提示", response.msg);
                }
            });
            $scope.rootConfig = {
                orderNum: 0,
                orderDetail: []
            }
            $modalInstance.close('new');
        } else if ($scope.boatMotorcade === true) {
            if ($scope.config.orderType == "3") {
                if ($scope.config.transBoat == null) {
                    toaster.pop("waring", "提示", "请选择船队");
                    return;
                }
            }
            if ($scope.config.stevedoreDay == null || $scope.config.stevedoreDay == "") {
                toaster.pop("waring", "提示", "请选择装卸货期限");
                return;
            }
            if ($scope.config.demurrage == null || $scope.config.demurrage == "") {
                toaster.pop("waring", "提示", "请选择滞期费");
                return;
            }
            if ($scope.config.loadDate == null || $scope.config.loadDate == "") {
                toaster.pop("waring", "提示", "请输入受载日期");
                return;
            }
            for (var i = 0; i < $scope.orderDetailCopy.length; i++) {
                for (var j = 0; j < $scope.orderDetailCopy[i].proOrderDetail.length; j++) {
                    if ($scope.orderDetailCopy[i].proOrderDetail[j].endCity != $scope.orderDetailCopy[0].proOrderDetail[0].endCity) {
                        toaster.pop("waring", "提示", "所选货品的目的地不同!");
                        return;
                    }
                }
            }
            //船运  订单
            if ($scope.config.transBoat == null || $scope.config.transBoat == '') {
                var fleetId = '';
            } else {
                var fleetId = $scope.config.transBoat.id;
            }
            var infosOrderTrain = {
                "passPoint": [
                    {
                        "address": $scope.orderDetailCopy[0].proOrderDetail[0].address,
                        "city": $scope.orderDetailCopy[0].proOrderDetail[0].city,
                        "contactPerson": $scope.orderDetailCopy[0].proOrderDetail[0].name,
                        "contactPhone": $scope.orderDetailCopy[0].proOrderDetail[0].phone,
                        "detailAdress": $scope.orderDetailCopy[0].proOrderDetail[0].detailAdress,
                        "latAndLng": $scope.orderDetailCopy[0].proOrderDetail[0].latAndLng,
                        "pointType": "e",
                        "province": $scope.orderDetailCopy[0].proOrderDetail[0].province,
                        "regions": ""
                    }
                ],
                "flow": $scope.orderDetailCopy[0].transOrder.flow,
                "orderPerson": $localStorage.chuanYangloginMessege.userId,
                "remark": $scope.config.mark,
                "orderAmount": $scope.config.orderAmount,
                "price": $scope.config.price,
                "endTime": $filter('date')(new Date(), 'yyyy-MM-dd'),
                "startTime": $filter('date')(new Date(), 'yyyy-MM-dd'),
                "orderDetails": [],
                "sPoint": $scope.orderDetailCopy[0].transOrder.sPoint.id,
                "orderType": $scope.config.orderType,
                "fleetId": fleetId,
                "transPortWay": "2",
                "payWay": $scope.config.payWay,
                "orderStatus": "0",
                "stevedoreDay": $scope.config.stevedoreDay,
                "demurrage": $scope.config.demurrage,
                "loadDate": $filter('date')($scope.config.loadDate, 'yyyy-MM-dd hh:mm:ss'),
                "consignationMode": $scope.config.consignationMode,
                "expiredTime": $scope.config.expiredTime,
                "currency" : $scope.config.currency,
                "assignment" : $scope.config.assignment
            }
            for (var i = 0; i < $scope.orderDetailCopy.length; i++) {
                for (var j = 0; j < $scope.orderDetailCopy[i].proOrderDetail.length; j++) {
                    infosOrderTrain.orderDetails.push({
                        "id": $scope.orderDetailCopy[i].proOrderDetail[j].id,
                        "noticeNo": $scope.orderDetailCopy[i].proOrderDetail[j].noticeNo,
                        "orderItemNum" :$scope.orderDetailCopy[i].proOrderDetail[j].orderItemNum,
                        "material": $scope.orderDetailCopy[i].proOrderDetail[j].material,
                        "commodityName": $scope.orderDetailCopy[i].proOrderDetail[j].commodityName,
                        "goodsNo": $scope.orderDetailCopy[i].proOrderDetail[j].materialNo,
                        "number": $scope.orderDetailCopy[i].proOrderDetail[j].surplusNum,
                        "goodsOrigin": $scope.orderDetailCopy[i].proOrderDetail[j].goodsOrigin + $scope.orderDetailCopy[i].proOrderDetail[j].material,
                        "standard": $scope.orderDetailCopy[i].proOrderDetail[j].standard,
                        "pack": $scope.orderDetailCopy[i].proOrderDetail[j].pack,
                        "weight": $scope.orderDetailCopy[i].proOrderDetail[j].weight,
                        "planId": $scope.orderDetailCopy[i].transOrder.planId

                    });
                }
            }
            /*---2----*/
            if(user_type==1){
                infosOrderTrain.custId = $localStorage.chuanYangloginMessege.userId;
            }else if(user_type==3){
                infosOrderTrain.custId = $localStorage.chuanYangloginMessege.companys[0].companyID;
            }
            var urlOrderSave = ROOTCONFIG.basePath + "info/order/saveOrderByPlan";
            urls.sendRequest('POST', angular.toJson(infosOrderTrain), urlOrderSave, '').success(function (response) {
                toaster.clear();
                if (ROOTCONFIG.debug) {
                    console.log(angular.toJson(response, true));
                }
                if (response.code == '100') {
                    toaster.pop("success", "提示", response.msg);
                } else if (response.code = '101') {
                    toaster.pop("error", "提示", response.msg);
                } else if (response.code = '110') {
                    toaster.pop("error", "提示", response.msg);
                }
            });
            $scope.rootConfig = {
                orderNum: 0,
                orderDetail: []
            }
            $modalInstance.close('new');
        } else {
            if ($scope.config.Logistics == null) {
                toaster.pop("waring", "提示", "请选择物流");
                return;
            }
            //物流  计划单
            var infosOrder = {
                "flow": $scope.orderDetailCopy[0].transOrder.flow,
                "fromCompanyId": $localStorage.chuanYangloginMessege.companys[0].companyID,
                "toCompanyId": $scope.config.Logistics.id,
                "created": $localStorage.chuanYangloginMessege.userId,
                "createTime": $filter('date')(new Date(), 'yyyy-MM-dd'),
                "remark": $scope.config.mark,
                "orderAmount": $scope.config.orderAmount,
                "price": $scope.config.price,
                "wizardId": '',
                "assignment" : $scope.config.assignment,
                "sPoint": {
                    "address": $scope.orderDetailCopy[0].transOrder.sPoint.address,
                    "detailAdress": $scope.orderDetailCopy[0].transOrder.sPoint.detailAdress,
                    "province": $scope.orderDetailCopy[0].transOrder.sPoint.province,
                    "city": $scope.orderDetailCopy[0].transOrder.sPoint.city,
                    "regions": $scope.orderDetailCopy[0].transOrder.sPoint.regions,
                    "latAndLng": $scope.orderDetailCopy[0].transOrder.sPoint.latAndLng
                },
                "planRelationList": [],
                "currency" : $scope.config.currency
            }
            for (var i = 0; i < $scope.orderDetailCopy.length; i++) {
                for (var j = 0; j < $scope.orderDetailCopy[i].proOrderDetail.length; j++) {
                    if ($scope.orderDetailCopy[i].proOrderDetail[j].sourceId == '' || $scope.orderDetailCopy[i].proOrderDetail[j].sourceId == undefined ||
                        $scope.orderDetailCopy[i].proOrderDetail[j].sourceId == null) {
                        var sourceId = $scope.orderDetailCopy[i].proOrderDetail[j].planId;
                    } else {
                        var sourceId = $scope.orderDetailCopy[i].proOrderDetail[j].sourceId;
                    }
                    infosOrder.planRelationList.push({
                        "ePoint": {
                            "address": $scope.orderDetailCopy[i].proOrderDetail[j].address,
                            "detailAdress": $scope.orderDetailCopy[i].proOrderDetail[j].detailAdress,
                            "province": $scope.orderDetailCopy[i].proOrderDetail[j].province,
                            "city": $scope.orderDetailCopy[i].proOrderDetail[j].city,
                            "regions": $scope.orderDetailCopy[i].proOrderDetail[j].regions,
                            "latAndLng": $scope.orderDetailCopy[i].proOrderDetail[j].latAndLng
                        },
                        "goodsId": {
                            "commodityName": $scope.orderDetailCopy[i].proOrderDetail[j].commodityName,
                            "pack": $scope.orderDetailCopy[i].proOrderDetail[j].pack,
                            "material": $scope.orderDetailCopy[i].proOrderDetail[j].material,
                            "standard": $scope.orderDetailCopy[i].proOrderDetail[j].standard,
                            "weightUnit": $scope.orderDetailCopy[i].proOrderDetail[j].weightUnit,
                            "thickness": $scope.orderDetailCopy[i].proOrderDetail[j].thickness,
                            "width": $scope.orderDetailCopy[i].proOrderDetail[j].width,
                            "length": $scope.orderDetailCopy[i].proOrderDetail[j].length
                        },
                        "contactPersonId": {
                            "name": $scope.orderDetailCopy[i].proOrderDetail[j].name,
                            "phone": $scope.orderDetailCopy[i].proOrderDetail[j].phone
                        },
                        "materialNo": $scope.orderDetailCopy[i].proOrderDetail[j].materialNo,
                        "noticeNo": $scope.orderDetailCopy[i].proOrderDetail[j].noticeNo,
                        "orderItemNum" :$scope.orderDetailCopy[i].proOrderDetail[j].orderItemNum,
                        "num": $scope.orderDetailCopy[i].proOrderDetail[j].surplusNum,
                        "weight": $scope.orderDetailCopy[i].proOrderDetail[j].weight,
                        "parentId": $scope.orderDetailCopy[i].proOrderDetail[j].planId,
                        "sourceId": sourceId,
                        "endTime": $scope.orderDetailCopy[i].proOrderDetail[j].endTime,
                        "remark": $scope.orderDetailCopy[i].proOrderDetail[j].remark
                    });

                }
            }
            var urlOrderList = ROOTCONFIG.basePath + "info/plan/insert";
            urls.sendRequest('POST', angular.toJson(infosOrder), urlOrderList, '').success(function (response) {
                toaster.clear();
                if (ROOTCONFIG.debug) {
                    console.log(angular.toJson(response, true));
                }
                if (response.code == '100') {
                    toaster.pop("success", "提示", response.msg);
                } else if (response.code = '101') {

                } else if (response.code = '110') {

                }
            });
            $scope.rootConfig = {
                orderNum: 0,
                orderDetail: []
            };
            $modalInstance.close('new');
        }


    };
    //修改价格
    $scope.changePrice = function (item) {
        if(isNaN($scope.config.price)){
            toaster.pop("error", "提示", "请输入正确的吨价!");
            return;
        }
        var weight = 0;
        for (var i = 0; i < $scope.orderDetailCopy.length; i++) {
            for (var j = 0; j < $scope.orderDetailCopy[i].proOrderDetail.length; j++) {
                if (isNaN($scope.viewArray.arrayFlag[i][j])) {
                } else {
                    weight += parseFloat($scope.viewArray.arrayFlag[i][j] * 1000);
                }
            }
        }
        console.log(weight);
        if (isNaN(weight) || weight == 0) {
            return;
        }
        var price = $scope.config.price * 1000;
        var orderAmount = $scope.config.orderAmount * 1000;
        if (item === 'a') {
            $scope.config.price = (orderAmount / weight).toFixed(2);
        } else {
            $scope.config.orderAmount = price * weight / 1000000;
        }
    }
    //修改数量
    $scope.changeNum = function(){
        var weight = 0;
        for (var i = 0; i < $scope.orderDetailCopy.length; i++) {
            for (var j = 0; j < $scope.orderDetailCopy[i].proOrderDetail.length; j++) {
                if (isNaN($scope.viewArray.arrayFlag[i][j])) {
                } else {
                    weight += parseFloat($scope.viewArray.arrayFlag[i][j] * 1000);
                }
            }
        }
        console.log(weight);
        if (isNaN(weight) || weight == 0) {
            return;
        }
        var price = $scope.config.price * 1000;
        var orderAmount = $scope.config.orderAmount * 1000;
        if($scope.config.price > 0){
            $scope.config.orderAmount = price * weight /1000000;
        }else if($scope.config.orderAmount > 0){
            $scope.config.price = (orderAmount / weight).toFixed(4);
        }
    }
}]);


chuanyang.controller('orderModelCtrl', ['$scope', '$modalInstance', 'orderInfo', function ($scope, $modalInstance, orderInfo) {
    $scope.items = orderInfo;
    $scope.add = function () {
        $modalInstance.close('delete');
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

}]);