/**
 * Created by 2016年9月7日09:47:40. 下单
 */

'use strict';

chuanyang.controller('platformOrderController', ['$scope', '$http', '$state', 'urls', '$stateParams', '$modal', '$filter', 'toaster', '$localStorage','$cookieStore',
    function ($scope, $http, $state, urls, $stateParams, $modal, $filter, toaster, $localStorage,$cookieStore) {
        $scope.orderTrainMessage = $stateParams.orderTrainMessage;
        $scope.planId = $stateParams.planId,
        $scope.orderMessage = null;
        $scope.placeOrder = {};
        $scope.placeOrder.transPortWay = '1';//类型
        $scope.placeOrder.orderStatus = '0';
        $scope.dedicatedToPush = true;//专线推送
        $scope.theFreight = true;//运费
        $scope.placeOrder.passPoint = [];//路经点
        $scope.placeOrder.orderDetails = [];//货物
        $scope.senderOrder = false;
        $scope.placeAndGoodsInfos = [];//装卸货信息
        $scope.boatTrain = false;
        $scope.placeOrders = {
            "startTime": "",//开始时间
            "endTime": "",//结束时间
            "expiredTime": ""//过期时间
        };

        $scope.placeOrder.orderType = "2";//初始化订单类型
        $("#one").css({"background-color": "#EC6E69", "border-color": "#FFFFFF", "color": "#FFFFFF"});
        $("#two").css({"background-color": "", "border-color": ""});
        $("#three").css({"background-color": "", "border-color": ""});

        $scope.placeOrder.consignationMode = "1";//初始化委托方式
        $("#entrustWayOne").css({"background-color": "#EC6E69", "color": "#FFFFFF"});
        $("#entrustWayTwo").css({"background-color": "", "color": "#000000"});

        $scope.placeOrder.payWay = "0";//初始化支付方式
        $("#payOne").css({"background-color": "#EC6E69", "color": "#FFFFFF"});
        $("#payTwo").css({"background-color": "", "color": "#000000"});

        $scope.goodsParam = {
            "goodsNo": guUUID(),
            "goodsName": "",
            "goodsWeight": "",
            "goodsStandard": "",
            "goodsNum": "",
            "goodsUnit": "",
            "goodsOrigin": "",
            "goodsMaterial": "",
            "blastNo": "",
            "planId": "0"
        };
        $scope.placeOrder.orderDetails.push($scope.goodsParam);

        $scope.OnTheWay = [];//途经点
        $scope.pathStartList = {//开始
            "contactPhone": "",
            "contactPerson": "",
            "pointType": "s",
            "detailAdress": "",
            "province": "",
            "city": "",
            "regions": "",
            "address": "",
            "latAndLng": ""
        };
        $scope.pathEndList = {//目的
            "contactPhone": "",
            "contactPerson": "",
            "pointType": "e",
            "detailAdress": "",
            "province": "",
            "city": "",
            "regions": "",
            "address": "",
            "latAndLng": ""
        };
        //
        if($localStorage.chuanYangloginMessege == undefined){
            $state.go('index.login');
        }else{
            $scope.user_type = $localStorage.chuanYangloginMessege.userType;
        }
        //选择订单类型
        $scope.selectTrust = true;
        $scope.selectOrderType = function (type) {
            switch (type) {
                case 1://竞价订单
                    $scope.placeOrder.orderType = "1";
                    $scope.dedicatedToPush = true;//运输类型
                    $scope.theFreight = false;
                    $scope.selectTrust = false;
                    $scope.trianPerson = false;
                    $scope.placeOrder.transPortWay = "1";
                    $scope.placeOrder.orderAmount = null;
                    $("#one").css({"background-color": "", "color": "#000000"});
                    $("#two").css({"background-color": "", "color": "#000000"});
                    $("#three").css({"background-color": "#EC6E69", "border-color": "#FFFFFF", "color": "#FFFFFF"});
                    $("#four").css({"background-color": "", "color": "#000000"});
                    $scope.changeTransPortWay('1');
                    break;
                case 2://匹配订单
                    $scope.placeOrder.orderType = "2";
                    $scope.dedicatedToPush = true;
                    $scope.selectTrust = true;
                    $scope.theFreight = true;
                    $scope.trianPerson = false;
                    $scope.placeOrder.transPortWay = "1";
                    $("#one").css({"background-color": "#EC6E69", "border-color": "#FFFFFF", "color": "#FFFFFF"});
                    $("#two").css({"background-color": "", "color": "#000000"});
                    $("#three").css({"background-color": "", "color": "#000000"});
                    $("#four").css({"background-color": "", "color": "#000000"});
                    $scope.changeTransPortWay('1');
                    break;
                case 3://专线推送
                    $scope.placeOrder.orderType = "3";
                    $scope.dedicatedToPush = true;//专线没有运输类型
                    $scope.selectTrust = false;
                    $scope.theFreight = true;
                    $scope.trianPerson = true;
                    $scope.placeOrder.transPortWay = '1';
                    $scope.placeOrders.expiredTime = null;
                    $("#one").css({"background-color": "", "color": "#000000"});
                    $("#two").css({"background-color": "#EC6E69", "border-color": "#FFFFFF", "color": "#FFFFFF"});
                    $("#three").css({"background-color": "", "color": "#000000"});
                    $("#four").css({"background-color": "", "color": "#000000"});
                    $scope.changeTransPortWay('1');
                    break;
                case 0:
                    $scope.placeOrder.orderType = "0";
                    $scope.dedicatedToPush = true;//运输类型
                    $scope.selectTrust = false;
                    $scope.theFreight = false;
                    $scope.trianPerson = false;
                    $scope.placeOrder.transPortWay = "1";
                    $("#one").css({"background-color": "", "color": "#000000"});
                    $("#two").css({"background-color": "", "color": "#000000"});
                    $("#three").css({"background-color": "", "color": "#000000"});
                    $("#four").css({"background-color": "#EC6E69", "border-color": "#FFFFFF", "color": "#FFFFFF"});
                    $scope.changeTransPortWay('1');
                    break;
            }
        };
        //运输方式
        $scope.placeOrder.currency = 1;
        $scope.changeTransPortWay = function (item) {
            if (item == '2') {
                $scope.boatTrain = true;
                $scope.placeOrder.currency = 1;
            } else {
                $scope.boatTrain = false;
                $scope.placeOrder.currency = 1;
            }
        }
        $scope.config = {};
        $scope.open = function ($event, item) {
            $event.preventDefault();
            $event.stopPropagation();
            if (item == 'start') {
                $scope.config.openedStart = true;
            } else {
                $scope.config.openedEnd = true;
            }
        };


        //添加货品
        $scope.addGood = function () {
            $scope.goodsParam = {
                "goodsNo": guUUID(),
                "goodsName": "",
                "goodsWeight": "",
                "goodsStandard": "",
                "goodsNum": "",
                "goodsUnit": "",
                "goodsOrigin": "",
                "goodsMaterial": "",
                "blastNo": "",
                "planId": "0"
            };
            $scope.placeOrder.orderDetails.push($scope.goodsParam);
            $scope.changeNum();
        };

        //删除货品
        $scope.deleteGoods = function (index) {
            $scope.placeOrder.orderDetails.splice(index, 1);
        };

        //委托方式
        $scope.entrustWay = function (Num) {
            switch (Num) {
                case 1:
                    $scope.placeOrder.consignationMode = "1";
                    $("#entrustWayOne").css({"background-color": "#EC6E69", "color": "#FFFFFF"});
                    $("#entrustWayTwo").css({"background-color": "", "color": "#000000"});
                    break;
                case 2:
                    $scope.placeOrder.consignationMode = "2";
                    $("#entrustWayOne").css({"background-color": "", "color": "#000000"});
                    $("#entrustWayTwo").css({"background-color": "#EC6E69", "color": "#FFFFFF"});
                    break;
            }
        };

        //支付方式
        $scope.selectPayMethod = function (payNum) {
            switch (payNum) {
                case 0:
                    $scope.placeOrder.payWay = "0";
                    $("#payOne").css({"background-color": "#EC6E69", "color": "#FFFFFF"});
                    $("#payTwo").css({"background-color": "", "color": "#000000"});
                    break;
                case 1:
                    $scope.placeOrder.payWay = "1";
                    $("#payOne").css({"background-color": "", "color": "#000000"});
                    $("#payTwo").css({"background-color": "#EC6E69", "color": "#FFFFFF"});
                    break;
            }
        };

        //添加货主 or 承运人信息
        $scope.shipper = [];//货主信息
        $scope.addPerson = function (name, train,item,placeOrder) {
            $scope.place = placeOrder.transPortWay
            console.log(angular.toJson(placeOrder,true));
            if (name === 'shipper') {//货主
                $scope.title = "添加货主";
                $scope.type = "shipper";
                $scope.name = "请选择货主";
                getList(train);
            } else if (name === 'senderOrder') {//招标单
                getDriver(train,item);
            } else {
                $scope.title = "添加承运人";
                $scope.type = "haulier";
                $scope.name = "请选择承运人";
                getList(train);
            }
        };
        function getDriver(train,item) {
            var modalInstance = $modal.open({
                templateUrl: 'pages/order/selectDriverModal.html',
                controller: 'selectDriverModalCtrl',
                size: 'lg',
                scope: $scope,
                resolve: {
                    items: function () {
                        return $scope.senderDriverList;
                    },
                }
            });
            modalInstance.result.then(function (selectedItem) {
                if (selectedItem === undefined) {
                    toaster.pop('warning', '提示', '请填写承运人');
                } else {
                    train.push(selectedItem);//添加承运人
                    item.price = selectedItem.price;
                    $scope.changePrice('s',item);
                }
            }, function () {

            });
        }

        //删除货承运人
        $scope.deleteHaulier = function (index, train) {
            train.splice(index, 1);
        };

        //计算方式
        $scope.placeOrder.priceDay = 0;
        $scope.placeOrder.place = 0;
        $scope.changeCountType = function (item) {
            $scope.placeOrder.priceDay = item;
        }
        $scope.changeCountPlace = function (item) {
            $scope.placeOrder.place = item;
        }
        //保存信息
        $scope.send = function () {
            // if ($scope.placeOrder.orderType == "3" && $scope.haulier.length == 0) {
            //     toaster.pop('warning', '提示', '请填写承运人');
            //     return;
            // }
            if ($localStorage.chuanYangloginMessege.auditing == '-1') {
                toaster.pop('error', '提示', '等待验证,暂时不能下单!');
                return;
            }
            var services = [];
            if ($scope.selectX == true) {
                services.push('需要装卸');
            }
            if ($scope.selectD == true) {
                services.push('需要回单');
            }
            if ($scope.selectK == true) {
                services.push('代收货款');
            }
            if ($scope.selectG == true) {
                for (var i = 0; i < $scope.trainSelect.length; i++) {
                    if ($scope.trainSelect[i].train == true) {
                        services.push($scope.trainSelect[i].name);
                    }
                }
            }
            if (services.length > 0) {
                $scope.placeOrder.services = services.join(',');
            }
            if ($scope.placeOrder.transPortWay == '2') {
                if (!isEmpty($scope.placeOrder.stevedoreDay)) {
                } else {
                    toaster.pop('error', '提示', '请输入装卸货期限');
                }
                if (isEmpty($scope.placeOrder.demurrage)) {
                    toaster.pop('error', '提示', '请输入滞期费');
                }
            }
            $scope.placeOrder.orderPerson = $localStorage.chuanYangloginMessege.userId;
            if ($scope.placeOrder.orderPerson == undefined || $scope.placeOrder.orderPerson == null) {
                toaster.pop('warning', '提示', '请重新登录');

            }

            if (isEmpty($scope.placeOrder.expiredTime)) {
                $scope.placeOrder.expiredTime = $filter('date')($scope.placeOrders.expiredTime, 'yyyy-MM-dd hh:mm:ss');
                if (isEmpty($scope.placeOrder.expiredTime)) {
                    $scope.placeOrder.expiredTime = null;
                }
            }

            console.log('下单提交信息');
            console.log($scope.placeOrder);
            console.log($scope.placeAndGoodsInfos);

            var info = {
                "orderList": []
            }
            var placeOrder = $scope.placeOrder;
            for (var i = 0; i < $scope.placeAndGoodsInfos.length; i++) {
                placeOrder.passPoint = [$scope.placeAndGoodsInfos[i].pathStartList, $scope.placeAndGoodsInfos[i].pathEndList];
                placeOrder.orderDetails = $scope.placeAndGoodsInfos[i].orderDetails;
                placeOrder.startTime = $scope.placeAndGoodsInfos[i].startTime;
                placeOrder.loadDate = $scope.placeAndGoodsInfos[i].startTime;
                placeOrder.fq = $scope.placeAndGoodsInfos[i].fq;
                placeOrder.endTime = $scope.placeAndGoodsInfos[i].endTime;
                placeOrder.waveNum = $scope.placeAndGoodsInfos[i].waveNum;
                placeOrder.waveUnit = $scope.placeAndGoodsInfos[i].waveUnit;
                placeOrder.price = $scope.placeAndGoodsInfos[i].price;
                placeOrder.orderAmount = $scope.placeAndGoodsInfos[i].orderAmount;
                if ($scope.placeAndGoodsInfos[i].haulier.length > 0) {
                    placeOrder.fleetId = $scope.placeAndGoodsInfos[i].haulier[0].fleetId;
                    placeOrder.driverId = $scope.placeAndGoodsInfos[i].haulier[0].driverId;
                }
                info.orderList[i] = angular.copy(placeOrder);
            }
                info.currency= $scope.placeOrder.currency;
                if( $scope.user_type==1){
                    info.accountType = 1;
                    info.custId = $localStorage.chuanYangloginMessege.userId;
                }else if($scope.user_type==3){
                    info.accountType = 2;
                    info.custId = $localStorage.chuanYangloginMessege.companys[0].companyID;
                }
            console.log(info);
            // return;
            /*--------------------------------改动-----------------------------------------------------------*/
            toaster.pop("wait", "提示", "正在提交...", 60000);
            var urlSaveOrder = ROOTCONFIG.basePath + "info/order/saveOrderByAdvance";
            urls.sendRequest('POST', angular.toJson(info), urlSaveOrder, '').success(function (response) {
                toaster.clear();
                if (response.code == '100') {
                    toaster.pop('success', '提示', response.msg);
                    if ($scope.user_type==3) {
                        $state.go("home.orderList");
                        console.log(111);
                    } else if($scope.user_type==1){
                        $state.go("home.shipperList");
                        console.log(222);
                    }
                } else if (response.code = '101') {
                    toaster.clear();
                    toaster.pop('error', '提示', response.msg|| '下单失败!');
                } else if (response.code = '110') {

                }
            });

        };

        function getList(train) {
            if ($scope.placeOrder.transPortWay == "2") {
                var fleetType = '3';
            } else {
                var fleetType = '2';
            }
            $scope.items = {
                "title": $scope.title,
                "type": $scope.type,
                "name": $scope.name,
                "fleetType": fleetType
            };
            var modalInstance = $modal.open({
                templateUrl: 'pages/order/alertHint.html',
                controller: 'alertModelCtrl',
                //size: size,
                scope: $scope,
                resolve: {
                    items: function () {
                        return $scope.items;
                    },
                }
            });
            modalInstance.result.then(function (selectedItem) {
                if (selectedItem.selected === undefined) {
                    toaster.pop('warning', '提示', '请填写承运人');
                } else {
                    if (selectedItem.single === true) {
                        train.push(selectedItem.selected);
                    } else {
                        train.push(selectedItem.selected);//添加承运人

                    }
                }
            }, function () {

            });
        }

        //获取货主信息userId
        function getShipper(userId) {
            var urlUser = ROOTCONFIG.basePath + "info/user/select";
            var param = {
                "userId": userId
            };
            urls.sendRequest('post', angular.toJson(param), urlUser, '').success(function (response) {
                if (response.code == '100') {
                    $scope.shipper.push(response.data);//添加货主
                } else if (response.code = '101') {

                } else if (response.code = '110') {

                }
            });
        }

        //修改数量
        $scope.changeNum = function () {
            var weight = 0;
            for (var i = 0; i < $scope.placeOrder.orderDetails.length; i++) {
                if (isNaN($scope.placeOrder.orderDetails[i].goodsWeight) || $scope.placeOrder.orderDetails[i].goodsWeight == '') {
                } else {
                    weight += parseFloat($scope.placeOrder.orderDetails[i].goodsWeight) * 1000;
                }
            }
            if (isNaN(weight) || weight == 0) {
                return;
            }
            var price = $scope.placeOrder.price * 1000;
            var orderAmount = $scope.placeOrder.orderAmount * 1000;
            if ($scope.placeOrder.price > 0) {
                $scope.placeOrder.orderAmount = price * weight / 1000000;
            } else if ($scope.placeOrder.orderAmount > 0) {
                $scope.placeOrder.price = (orderAmount / weight).toFixed(4);
            }
        }
        //修改价格
        $scope.placeOrder.orderAmountAllOrder = 0;
        $scope.changePrice = function (item, info) {
            $scope.placeOrder.orderAmountAllOrder = 0;
            var weight = 0;
            for (var i = 0; i < info.orderDetails.length; i++) {
                if (isNaN(info.orderDetails[i].goodsWeight)) {
                } else {
                    weight += parseFloat(info.orderDetails[i].goodsWeight) * 1000;
                }
            }
            if (isNaN(weight) || weight == 0) {
                return;
            }
            var price = info.price * 1000;
            var orderAmount = info.orderAmount * 1000;
            if (item === 'a') {
                info.price = (orderAmount / weight).toFixed(4);
            } else {
                info.orderAmount = price * weight / 1000000;
            }
            for(var i=0;i<$scope.placeAndGoodsInfos.length;i++){
                if(!isNaN($scope.placeAndGoodsInfos[i].orderAmount)){
                    $scope.placeOrder.orderAmountAllOrder += $scope.placeAndGoodsInfos[i].orderAmount;
                }
            }
        }
        //其他服务
        $scope.selectX = false;
        $scope.selectD = false;
        $scope.selectK = false;
        $scope.selectG = false;
        $scope.trainSelect = [
            {train: false, name: '全挂', id: 1},
            {train: false, name: '半挂', id: 2},
            {train: false, name: '自卸', id: 3},
            {train: false, name: '箱式', id: 4},
            {train: false, name: '平板', id: 5},
            {train: false, name: '集装箱', id: 6},
            {train: false, name: '特殊', id: 7},
            {train: false, name: '普通', id: 8},
            {train: false, name: '其他', id: 9}
        ]
        $scope.selectTrain = function (id) {
            for (var i = 0; i < $scope.trainSelect.length; i++) {
                if (id == $scope.trainSelect[i].id) {
                    $scope.trainSelect[i].train = true;
                } else {
                    $scope.trainSelect[i].train = false;
                }
            }
        }
        $scope.selectOther = function (item) {
            if (item == '1') {
                $scope.placeOrder.otherService = "需要装卸";
                $scope.selectX = !$scope.selectX;
            } else if (item == '2') {
                $scope.placeOrder.otherService = "需要回单";
                $scope.selectD = !$scope.selectD;
            } else if (item == '3') {
                $scope.placeOrder.otherService = "代收货款";
                $scope.selectK = !$scope.selectK;
            } else if (item == '4') {
                $scope.placeOrder.otherService = "运输工具";
                $scope.selectG = !$scope.selectG;
                if ($scope.selectG == false) {
                    for (var i = 0; i < $scope.trainSelect.length; i++) {
                        $scope.trainSelect[i].train = false;
                    }
                }
            }
        }
        //招标单
        $scope.selectSenderList = function () {
            var modalInstance = $modal.open({
                templateUrl: 'pages/order/tenderListModel.html',
                controller: 'senderListModelCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return $scope.orderTrainMessage;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                $scope.senderOrder = true;
                $scope.placeOrder.transPortWay = selectedItem.transPortWay;
                $scope.placeOrder.currency = selectedItem.currency;
                $scope.placeOrder.remark = selectedItem.remark;
                if (selectedItem.transPortWay == '2') {
                    $scope.boatTrain = true;
                }
                $scope.senderDriverList = selectedItem.driverMsgList;
                $scope.placeAndGoodsInfos.push({
                    price: selectedItem.price,
                    orderDetails: [{
                        goodsName: selectedItem.goodsName,
                        goodsWeight: selectedItem.goodsWeight,
                        uuid: guUUID()
                    }],
                    tenderTime : selectedItem.advancedPeriodNo,
                    tenderNo : selectedItem.advancedorderId,
                    startTime: '',
                    endTime: '',
                    haulier: [],
                    haulierSelect: [],
                    pathStartList: {//开始
                        "contactPhone": "",
                        "contactPerson": "",
                        "pointType": "s",
                        "detailAdress": "",
                        "province": "",
                        "city": "",
                        "regions": "",
                        "address": selectedItem.startCity,
                        "latAndLng": ""
                    },
                    pathEndList: {//目的
                        "contactPhone": "",
                        "contactPerson": "",
                        "pointType": "e",
                        "detailAdress": "",
                        "province": "",
                        "city": "",
                        "regions": "",
                        "address": selectedItem.targetCity,
                        "latAndLng": ""
                    },
                });
                $scope.placeAndGoodsAll = {
                    boatTrain: $scope.boatTrain,
                    placeAndGoodsInfos: $scope.placeAndGoodsInfos
                };
            }, function () {
                //$log.info('Modal dismissed at: ' + new Date());
            });
        }
        //招标单
        $scope.senderSaveOrder = function () {
            // if ($scope.placeOrder.orderType == "3" && $scope.haulier.length == 0) {
            //     toaster.pop('warning', '提示', '请填写承运人');
            //     return;
            // }
            if ($localStorage.chuanYangloginMessege.auditing == '-1') {
                toaster.pop('error', '提示', '等待验证,暂时不能下单!');
                return;
            }
            var services = [];
            if ($scope.selectX == true) {
                services.push('需要装卸');
            }
            if ($scope.selectD == true) {
                services.push('需要回单');
            }
            if ($scope.selectK == true) {
                services.push('代收货款');
            }
            if ($scope.selectG == true) {
                for (var i = 0; i < $scope.trainSelect.length; i++) {
                    if ($scope.trainSelect[i].train == true) {
                        services.push($scope.trainSelect[i].name);
                    }
                }
            }
            if (services.length > 0) {
                $scope.placeOrder.services = services.join(',');
            }
            if ($scope.placeOrder.transPortWay == '2') {
                if (!isEmpty($scope.placeOrder.stevedoreDay)) {
                } else {
                    toaster.pop('error', '提示', '请输入装卸货期限');
                }
                if (isEmpty($scope.placeOrder.demurrage)) {
                    toaster.pop('error', '提示', '请输入滞期费');
                }
            }
            $scope.placeOrder.orderPerson = $localStorage.chuanYangloginMessege.userId;
            if ($scope.placeOrder.orderPerson == undefined || $scope.placeOrder.orderPerson == null) {
                toaster.pop('warning', '提示', '请重新登录');

            }
            if (isEmpty($scope.placeOrder.expiredTime)) {
                $scope.placeOrder.expiredTime = $filter('date')($scope.placeOrders.expiredTime, 'yyyy-MM-dd hh:mm:ss');
                if (isEmpty($scope.placeOrder.expiredTime)) {
                    $scope.placeOrder.expiredTime = null;
                }
            }

            console.log('下单提交信息');
            console.log($scope.placeOrder);
            var info = {
                "orderList": []
            }
            var placeOrder = $scope.placeOrder;
            for (var i = 0; i < $scope.placeAndGoodsInfos.length; i++) {
                placeOrder.passPoint = [$scope.placeAndGoodsInfos[i].pathStartList, $scope.placeAndGoodsInfos[i].pathEndList];
                placeOrder.orderDetails = $scope.placeAndGoodsInfos[i].orderDetails;
                placeOrder.startTime = $scope.placeAndGoodsInfos[i].startTime;
                placeOrder.loadDate = $scope.placeAndGoodsInfos[i].startTime;
                placeOrder.fq = $scope.placeAndGoodsInfos[i].fq;
                if($scope.boatTrain == true){
                }else{
                    placeOrder.endTime = $scope.placeAndGoodsInfos[i].endTime;
                }
                placeOrder.waveNum = $scope.placeAndGoodsInfos[i].waveNum;
                placeOrder.waveUnit = $scope.placeAndGoodsInfos[i].waveUnit;
                placeOrder.price = $scope.placeAndGoodsInfos[i].price;
                placeOrder.orderAmount = $scope.placeAndGoodsInfos[i].orderAmount;
                placeOrder.tenderTime = $scope.placeAndGoodsInfos[i].tenderTime;
                placeOrder.tenderNo = $scope.placeAndGoodsInfos[i].tenderNo;
                if ($scope.placeAndGoodsInfos[i].haulier.length > 0) {
                    placeOrder.fleetId = $scope.placeAndGoodsInfos[i].haulier[0].fleetId;
                    placeOrder.driverId = $scope.placeAndGoodsInfos[i].haulier[0].driverId;
                }
                info.orderList[i] = angular.copy(placeOrder);
            }
                info.currency= $scope.placeOrder.currency;
                if( $scope.user_type==1){
                    info.accountType = 1;
                    info.custId = $localStorage.chuanYangloginMessege.userId;
                }else if($scope.user_type==3){
                    info.accountType = 2;
                    info.custId = $localStorage.chuanYangloginMessege.companys[0].companyID;
                };
            console.log(info);
            /*---------------------------------改动2---------------------------------------*/
            var urlSaveOrder = ROOTCONFIG.basePath4 + "info/order/saveOrderByAdvance";
            toaster.pop("wait", "提示", "正在提交...", 60000);
            urls.sendRequest('POST', angular.toJson(info), urlSaveOrder, '').success(function (response) {
                toaster.clear();
                if (response.code == '100') {
                    toaster.pop('success', '提示', response.msg);
                    if ($scope.user_type==3) {
                        $state.go("home.orderList");
                    } else if($scope.user_type==1) {
                        $state.go("home.shipperList");
                    }
                } else if (response.code = '101') {
                    toaster.pop('error', '提示', response.msg||'下单失败!');
                } else if (response.code = '110') {

                }
            });
        }
        //添加装卸港口
        $scope.addPlace = function () {
            $scope.placeAndGoodsAll = {
                currency : $scope.placeOrder.currency,
                boatTrain: $scope.boatTrain,
                placeAndGoodsInfos: $scope.placeAndGoodsInfos
            };
            var modalInstance = $modal.open({
                templateUrl: 'pages/order/addPlaceModal.html',
                controller: 'addPlaceModalCtrl',
                backdrop : 'static',
                size: 'lg',
                $scope: $scope,
                resolve: {
                    items: function () {
                        return $scope.placeAndGoodsAll;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                $scope.placeAndGoodsAll = selectedItem;
                $scope.placeAndGoodsInfos = selectedItem.placeAndGoodsInfos;
            }, function () {
            });
        }
        //添加装卸模块
        $scope.addGoods = function (item) {
            item.orderTrainMessage = $scope.orderTrainMessage;
            item.planId = $scope.planId;
            var modalInstance = $modal.open({
                templateUrl: 'pages/order/addGoodsModal.html',
                controller: 'addGoodsModalCtrl',
                $scope: $scope,
                backdrop : 'static',
                size: 'lg',
                resolve: {
                    items: function () {
                        return item;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                item.orderDetails = selectedItem;
                $scope.changePrice('s', item);
            }, function () {
            });
        }
        $scope.deleteGoods = function (index, info) {
            info.splice(index, 1);
        }
    }]);

//弹窗控制器
chuanyang.controller('alertModelCtrl', ['$scope', '$modalInstance', 'items', 'urls', function ($scope, $modalInstance, items, urls) {
    $scope.config = {
        more: false,
        single: true
    }
    $scope.changeTrain = function (item) {
        if (item == 'single') {
            $scope.config.single = true;
            $scope.config.more = false;
            $scope.refreshAddresses('');
        } else {
            $scope.config.single = false;
            $scope.config.more = true;
            $scope.refreshAddresses('');
        }
    };
    $scope.items = items;
    if ($scope.items.type === "shipper") {
        $scope.config.singleDesc = "个人货主";
        $scope.config.moreDesc = "公司货主";
    } else if($scope.place == 1){
        $scope.config.singleDesc = "司机";
        $scope.config.moreDesc = "车队";
    } else{
        $scope.config.singleDesc = "船长";
        $scope.config.moreDesc = "船队";
    }
    $scope.refreshAddresses = function (name) {
        if ($scope.items.type === "shipper") {
            var paramByUserName = {"username": name};
            var urlGetAll = ROOTCONFIG.basePath + "info/user/selectUserbyUsername";//获取货主信息
            urls.sendRequest('POST', angular.toJson(paramByUserName), urlGetAll, '').success(function (response) {
                if (response.code == '100') {
                    $scope.people = response.data;
                } else if (response.code = '101') {

                } else if (response.code = '110') {

                }
            });
        } else {
            if ($scope.config.single == true) {
                var paramByFleetName = {"driverName": name, driverType: $scope.items.fleetType};
                var urlGetAll = ROOTCONFIG.basePath + "info/driverWeb/selectDriverByName";//获取车队信息
                urls.sendRequest('POST', angular.toJson(paramByFleetName), urlGetAll, '').success(function (response) {
                    if (response.code == '100') {
                        $scope.people = response.data;
                    } else if (response.code = '101') {

                    } else if (response.code = '110') {

                    }
                });
            } else {
                var paramByFleetName = {"fleetName": name, fleetType: $scope.items.fleetType};
                var urlGetAll = ROOTCONFIG.basePath + "info/driverWeb/selectFleetByName";//获取车队信息
                urls.sendRequest('POST', angular.toJson(paramByFleetName), urlGetAll, '').success(function (response) {
                    if (response.code == '100') {
                        $scope.people = response.data;
                    } else if (response.code = '101') {

                    } else if (response.code = '110') {

                    }
                });
            }

        }
    };

    $scope.add = function () {
        $scope.items.single = $scope.config.single;
        $modalInstance.close($scope.items);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

}]);

chuanyang.controller('searchOutRepositoryAddressCtrl', ['$scope', '$modalInstance', 'items', '$localStorage', 'urls', 'toaster', function ($scope, $modalInstance, items, $localStorage, urls, toaster) {
    $scope.items = items;
    $scope.address = {};
    var paramByFleetName = {"shipperId": $localStorage.chuanYangloginMessege.userId};
    var urlGetAll = ROOTCONFIG.basePath + "info/shipperLine/selectByUser";//路线
    urls.sendRequest('POST', angular.toJson(paramByFleetName), urlGetAll, '').success(function (response) {
        if (response.code == '100') {
            $scope.locationDetail = response.data.data;
            if ($scope.locationDetail.length == 0) {
                toaster.pop('warning', '提示', '请在移动端维护常用路线! ');
            }
        } else if (response.code = '101') {

        } else if (response.code = '110') {

        }
    });
    $scope.locationSelect = null;
    $scope.selectLocation = function (select, item) {
        $scope.showSelectLocation = [];
        for (var i = 0; i < $scope.locationDetail.length; i++) {
            if (i === select) {
                $scope.showSelectLocation[i] = true;
            } else {
                $scope.showSelectLocation[i] = false;
            }
        }
        $scope.locationSelect = item;
    };
    $scope.add = function () {//添加  省：addressProvince 市：addressCity 详细地址：result 经纬度：lnglat
        $scope.address.province = $('#addressProvince').val();
        $scope.address.levelcity = $('#addressCity').val();
        if (isEmpty($scope.address.levelcity)) {
            $scope.address.levelcity = $scope.address.province;
        } else {
            $scope.address.levelcity = $('#addressCity').val();
        }
        $scope.address.district = $('#addressDistrict').val();
        $scope.address.companyaddress = $('#result').val();
        $scope.address.latAndLng = $('#lnglat').val();
        $modalInstance.close($scope.address);
    };
    $scope.confirm = function () {
        if ($scope.locationSelect == null) {
            toaster.pop('warning', '提示', '请选择常用路线');
        }
        var slId = {slId: $scope.locationSelect.slId};
        $scope.items.type = '2';
        var urlGetSelect = ROOTCONFIG.basePath + "info/shipperLine/selectBySlId";//路线
        urls.sendRequest('post', angular.toJson(slId), urlGetSelect, '').success(function (response) {
            if (response.code == '100') {
                var info = response.data.shipperPoints;
                for (var i = 0; i < info.length; i++) {
                    if (info[i].pointType == 's') {
                        $scope.items.locationS = {
                            "province": info[i].province,
                            "levelcity": info[i].city,
                            "district": info[i].regions,
                            "companyaddress": info[i].detailAdress,
                            "latAndLng": info[i].latAndLng,
                            "contactPerson":info[i].contactPerson,
                            "contactPhone":info[i].contactPhone
                        }
                    }
                    if (info[i].pointType == 'e') {
                        $scope.items.locationE = {
                            "province": info[i].province,
                            "levelcity": info[i].city,
                            "district": info[i].regions,
                            "companyaddress": info[i].detailAdress,
                            "latAndLng": info[i].latAndLng,
                            "contactPerson":info[i].contactPerson,
                            "contactPhone":info[i].contactPhone
                        }
                    }
                }
                $modalInstance.close($scope.items);
            } else if (response.code = '101') {

            } else if (response.code = '110') {

            }
        });
    };
    $scope.cancel = function () {
        $modalInstance.dismiss();
    }
}]);


chuanyang.controller('createAddressCtrl', ['$scope', '$modalInstance', 'items', '$localStorage', 'urls', 'toaster', function ($scope, $modalInstance, items, $localStorage, urls, toaster) {
    $scope.items = items;
    $scope.items = {
        province: ' ',
        levelcity: '',
        district: ' ',
        companyaddress: '',
        latAndLng: '',
    }
    $scope.config = {};
    $scope.confirm = function () {
        if ($scope.items.levelcity == '') {
            toaster.pop('warning', '提示', '请输入城市');
            return;
        }
        if ($scope.items.companyaddress == '') {
            toaster.pop('warning', '提示', '请输入详细地址');
            return;
        }
        if (isNaN($scope.config.wei) || isNaN($scope.config.jing)) {
            toaster.pop('warning', '提示', '请输入经纬度!');
            return;
        } else {
            if ($scope.config.wei < 90 && $scope.config.wei > -90) {
            } else {
                toaster.pop('warning', '提示', '请输入正确的纬度');
                return;
            }
            if ($scope.config.jing < 180 && $scope.config.jing > -180) {
            } else {
                toaster.pop('warning', '提示', '请输入正确的精度');
                return;
            }
        }
        $scope.items.latAndLng = $scope.config.jing + ',' + $scope.config.wei;
        $modalInstance.close($scope.items);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss();
    }
}]);


chuanyang.controller('senderListModelCtrl', ['$scope', '$modalInstance', 'items', '$localStorage', 'urls', 'toaster', function ($scope, $modalInstance, items, $localStorage, urls, toaster) {

    $scope.searchPeriodNoList = function () {
        if (items == null || items == undefined) {
            var senderListInfo = {
                'userId': $localStorage.chuanYangloginMessege.userId,
                "page": 1,
                "length": 100,
                "state": 2
            };
        } else {
            var senderListInfo = {
                'companyId': $localStorage.chuanYangloginMessege.companys[0].companyID,
                "page": 1,
                "length": 100,
                "state": 2
            };
        }
        var urlSelectList = ROOTCONFIG.basePath + "info/AdvancedOrder/selectAdvancedPeriodNo";//标期
        urls.sendRequest('post', angular.toJson(senderListInfo), urlSelectList, '').success(function (response) {
            if (response.code == '100') {
                $scope.senderAdvancedPeriodNoList = response.data.data;
            } else if (response.code = '101') {
                toaster.pop('warning', '提示', response.msg);
            } else if (response.code = '110') {

            }
        });
    };
    $scope.searchPeriodNoList();
    $scope.searchList = function (info) {
        if (items == null || items == undefined) {
            var senderListInfo = {
                'userId': $localStorage.chuanYangloginMessege.userId,
                "page": 1,
                "length": 100,
                "state": 2,
                "advancedPeriodNo" : info.advancedPeriodNo
            };
        } else {
            var senderListInfo = {
                'companyId': $localStorage.chuanYangloginMessege.companys[0].companyID,
                "page": 1,
                "length": 100,
                "state": 2,
                "advancedPeriodNo" : info.advancedPeriodNo
            };
        }
        var urlSelectList = ROOTCONFIG.basePath + "info/AdvancedOrder/selectAdvancedOrder";//招标单列表
        urls.sendRequest('post', angular.toJson(senderListInfo), urlSelectList, '').success(function (response) {
            if (response.code == '100') {
                $scope.senderList = response.data.data;
            } else if (response.code = '101') {
                toaster.pop('warning', '提示', response.msg);
            } else if (response.code = '110') {

            }
        });
    };
    $scope.confirm = function () {
        if ($scope.selectList == null) {
            toaster.pop('warning', '提示', '请选择招标单!');
            return;
        }
        var senderDetailInfo = {advancedorderId: $scope.selectList.advancedorderId};
        var urlSelectDetail = ROOTCONFIG.basePath + "info/AdvancedOrder/selectAdvancedOrderById";//招标单详情
        urls.sendRequest('post', angular.toJson(senderDetailInfo), urlSelectDetail, '').success(function (response) {
            if (response.code == '100') {
                $modalInstance.close(response.data);
            } else if (response.code = '101') {
                toaster.pop('warning', '提示', response.msg);
            } else if (response.code = '110') {

            }
        });
    };
    $scope.cancel = function () {
        $modalInstance.dismiss();
    }
    $scope.selectList = null;
    $scope.selectSender = function (item) {
        $scope.selectList = item;
        for (var i = 0; i < $scope.senderList.length; i++) {
            $scope.senderList[i].select = false;
        }
        item.select = !item.select;
    }
}]);

//添加装卸港口
chuanyang.controller('addPlaceModalCtrl', ['$scope', '$modalInstance', 'items', '$localStorage', 'urls', 'toaster', '$modal', function ($scope, $modalInstance, items, $localStorage, urls, toaster, $modal) {
    $scope.items = angular.copy(items);
    $scope.currency = $scope.items.currency;
    $scope.addPlace = function () {
        $scope.items.placeAndGoodsInfos.unshift(
            {
                pathStartList: {//开始
                    "contactPhone": "",
                    "contactPerson": "",
                    "pointType": "s",
                    "detailAdress": "",
                    "province": "",
                    "city": "",
                    "regions": "",
                    "address": "",
                    "latAndLng": ""
                },
                pathEndList: {//目的
                    "contactPhone": "",
                    "contactPerson": "",
                    "pointType": "e",
                    "detailAdress": "",
                    "province": "",
                    "city": "",
                    "regions": "",
                    "address": "",
                    "latAndLng": ""
                },
                orderDetails: [],//货物
                price: '',
                waveUnit: '',
                waveNum: '',
                haulier: []
            }
        );
    }
    $scope.addPlace();
    $scope.phone = function (item) {
        if (item.length != 11) {
            toaster.pop('warning', '提示', '请输入正确的手机号码!');
        }
    }
    //搜素地图获取地址
    $scope.searchAddress = function (size, item) {
        var items = {};
        var modalInstance = $modal.open({
            templateUrl: 'pages/order/searchAddress.html',
            controller: 'searchOutRepositoryAddressCtrl',
            size: 'lg',
            resolve: {
                items: function () {
                    return items;
                }
            }
        });
        modalInstance.result.then(function (selectedItem) {
            if (selectedItem.type == '2') {
                //qishidian
                item.pathStartList.province = selectedItem.locationS.province;
                item.pathStartList.city = selectedItem.locationS.levelcity;
                item.pathStartList.regions = selectedItem.locationS.district;
                item.pathStartList.address = selectedItem.locationS.companyaddress;
                item.pathStartList.latAndLng = selectedItem.locationS.latAndLng;
                item.pathStartList.detailAdress = selectedItem.locationS.companyaddress;
                item.pathStartList.contactPerson = selectedItem.locationS.contactPerson;
                item.pathStartList.contactPhone = selectedItem.locationS.contactPhone;
                //zhongdian
                item.pathEndList.province = selectedItem.locationE.province;
                item.pathEndList.city = selectedItem.locationE.levelcity;
                item.pathEndList.regions = selectedItem.locationE.district;
                item.pathEndList.address = selectedItem.locationE.companyaddress;
                item.pathEndList.latAndLng = selectedItem.locationE.latAndLng;
                item.pathEndList.detailAdress = selectedItem.locationE.companyaddress;
                item.pathEndList.contactPerson = selectedItem.locationE.contactPerson;
                item.pathEndList.contactPhone = selectedItem.locationE.contactPhone;
            } else {
                if (size === 's') {//开始
                    item.pathStartList.province = selectedItem.province;
                    item.pathStartList.city = selectedItem.levelcity;
                    item.pathStartList.regions = selectedItem.district;
                    item.pathStartList.address = selectedItem.companyaddress;
                    item.pathStartList.latAndLng = selectedItem.latAndLng;
                    item.pathStartList.detailAdress = selectedItem.companyaddress;
                } else if (size === 'p') {//途径
                    item.pathList.province = selectedItem.province;
                    item.pathList.city = selectedItem.levelcity;
                    item.pathList.regions = selectedItem.district;
                    item.pathList.address = selectedItem.companyaddress;
                    item.pathList.latAndLng = selectedItem.latAndLng;
                    item.pathList.detailAdress = selectedItem.companyaddress;
                } else if (size === 'e') {//终点
                    item.pathEndList.province = selectedItem.province;
                    item.pathEndList.city = selectedItem.levelcity;
                    item.pathEndList.regions = selectedItem.district;
                    item.pathEndList.address = selectedItem.companyaddress;
                    item.pathEndList.latAndLng = selectedItem.latAndLng;
                    item.pathEndList.detailAdress = selectedItem.companyaddress;
                }
            }
        }, function () {
        });
    };
    //手动添加地址
    $scope.createAdress = function (size, item) {
        var modalInstance = $modal.open({
            templateUrl: 'pages/order/createAdress.html',
            controller: 'createAddressCtrl',
            size: '',
            resolve: {
                items: function () {
                    return '';
                }
            }
        });
        modalInstance.result.then(function (selectedItem) {
            if (size === 's') {//开始
                item.pathStartList.province = selectedItem.province;
                item.pathStartList.city = selectedItem.levelcity;
                item.pathStartList.regions = selectedItem.district;
                item.pathStartList.address = selectedItem.companyaddress;
                item.pathStartList.latAndLng = selectedItem.latAndLng;
                item.pathStartList.detailAdress = selectedItem.companyaddress;
            } else if (size === 'p') {//途径
                item.pathList.province = selectedItem.province;
                item.pathList.city = selectedItem.levelcity;
                item.pathList.regions = selectedItem.district;
                item.pathList.address = selectedItem.companyaddress;
                item.pathList.latAndLng = selectedItem.latAndLng;
                item.pathList.detailAdress = selectedItem.companyaddress;
            } else if (size === 'e') {//终点
                item.pathEndList.province = selectedItem.province;
                item.pathEndList.city = selectedItem.levelcity;
                item.pathEndList.regions = selectedItem.district;
                item.pathEndList.address = selectedItem.companyaddress;
                item.pathEndList.latAndLng = selectedItem.latAndLng;
                item.pathEndList.detailAdress = selectedItem.companyaddress;
            }
        }, function () {
            //$log.info('Modal dismissed at: ' + new Date());
        });
    };
    $scope.deletePlace = function (index) {
        $scope.items.placeAndGoodsInfos.splice(index, 1);
    }
    $scope.confirm = function () {
        for (var i = 0; i < $scope.items.placeAndGoodsInfos.length; i++) {
            if (isEmpty($scope.items.placeAndGoodsInfos[i].pathEndList.address) || isEmpty($scope.items.placeAndGoodsInfos[i].pathStartList.address)) {
                toaster.pop('warning', '提示', '选择起止地点!');
                return;
            }
            /*if (isEmpty($scope.items.placeAndGoodsInfos[i].pathEndList.contactPhone) || isEmpty($scope.items.placeAndGoodsInfos[i].pathStartList.contactPhone)) {
                toaster.pop('warning', '提示', '输入手机号!');
                return;
            }*/
            if($scope.currency == '1'){
                if (isEmpty($scope.items.placeAndGoodsInfos[i].pathEndList.contactPerson) || isEmpty($scope.items.placeAndGoodsInfos[i].pathStartList.contactPerson)) {
                    $scope.items.placeAndGoodsInfos[i].pathEndList.contactPerson = $localStorage.chuanYangloginMessege.username;
                    $scope.items.placeAndGoodsInfos[i].pathStartList.contactPerson = $localStorage.chuanYangloginMessege.username;
                }
            }else{
                if (isEmpty($scope.items.placeAndGoodsInfos[i].pathEndList.contactPerson) || isEmpty($scope.items.placeAndGoodsInfos[i].pathStartList.contactPerson)) {
                    toaster.pop('warning', '提示', '输入联系人!');
                    return;
                }
            }
            if (isEmpty($scope.items.placeAndGoodsInfos[i].price)) {
                toaster.pop('warning', '提示', '输入单价!');
                return;
            }

            if (isEmpty($scope.items.placeAndGoodsInfos[i].startTime) || isEmpty($scope.items.placeAndGoodsInfos[i].endTime)) {
                toaster.pop('warning', '提示', '输入时间!');
                return;
            }
        }
        $modalInstance.close($scope.items);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss();
    }
}]);

//添加装卸模块
chuanyang.controller('addGoodsModalCtrl', ['$scope', '$modalInstance', 'items', '$localStorage', 'urls', 'toaster', function ($scope, $modalInstance, items, $localStorage, urls, toaster) {
    $scope.config = angular.copy(items);
    for(var i=0;i<$scope.config.orderDetails.length;i++){
        $scope.config.orderDetails[i].noticeNo = $scope.config.orderTrainMessage;
    }
    $scope.addInfo = {
        goodsName: "",
        goodsStandard: "",
        goodsWeight: "",
        goodsNum: "",
        planId: $scope.config.planId,
        noticeNo: $scope.config.orderTrainMessage
    }
    $scope.deleteGoods = function (index) {
        $scope.config.orderDetails.splice(index, 1)
    }
    $scope.updateGoods = function (goods) {
        $scope.addInfo = {
            goodsName: goods.goodsName,
            goodsStandard: goods.goodsStandard,
            goodsWeight: goods.goodsWeight,
            goodsNum: goods.goodsNum,
            noticeNo: goods.noticeNo,
            planId: $scope.config.orderTrainMessage,
            uuid: goods.uuid
        }
    }
    $scope.addGoods = function () {
        if($scope.addInfo.goodsName == "" ){
            toaster.pop('warning', '提示', '输入货物名称!');
            return;
        }
        if($scope.addInfo.goodsWeight == "" ){
            toaster.pop('warning', '提示', '输入货物重量!');
            return;
        }
        if ($scope.addInfo.uuid == undefined || isEmpty($scope.addInfo.uuid)) {
            $scope.config.orderDetails.push(
                {
                    goodsName: $scope.addInfo.goodsName,
                    goodsStandard: $scope.addInfo.goodsStandard,
                    goodsWeight: $scope.addInfo.goodsWeight,
                    goodsNum: $scope.addInfo.goodsNum,
                    noticeNo: $scope.addInfo.noticeNo,
                    planId: $scope.addInfo.planId,
                    uuid: guUUID()
                }
            );
        } else {
            for (var i = 0; i < $scope.config.orderDetails.length; i++) {
                if ($scope.addInfo.uuid == $scope.config.orderDetails[i].uuid) {
                    $scope.config.orderDetails[i] = {
                        goodsName: $scope.addInfo.goodsName,
                        goodsStandard: $scope.addInfo.goodsStandard,
                        goodsWeight: $scope.addInfo.goodsWeight,
                        goodsNum: $scope.addInfo.goodsNum,
                        noticeNo: $scope.addInfo.noticeNo,
                        planId: $scope.addInfo.planId,
                        uuid: $scope.addInfo.uuid
                    }
                }
            }
        }
        $scope.addInfo = {
            goodsName: "",
            goodsStandard: "",
            goodsWeight: "",
            goodsNum: "",
            planId: $scope.config.planId,
            noticeNo: $scope.config.orderTrainMessage
        };
    }
    $scope.confirm = function () {
        $modalInstance.close($scope.config.orderDetails);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss();
    }
}]);


//添加司机选择模块
chuanyang.controller('selectDriverModalCtrl', ['$scope', '$modalInstance', 'items', '$localStorage', 'urls', 'toaster', function ($scope, $modalInstance, items, $localStorage, urls, toaster) {
    $scope.driverList = items;
    $scope.confirm = function (item) {
        $modalInstance.close(item);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss();
    }
}]);