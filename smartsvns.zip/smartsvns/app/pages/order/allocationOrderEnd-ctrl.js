/**
 * Created by admin on 2016/10/23.
 */

chuanyang.controller('allocationOrderEndController', ['$scope', 'transportationList', 'transportationChildList', 'orderList', 'urls', '$state', '$modal', 'toaster', '$filter','$localStorage',
    function ($scope, transportationList, transportationChildList, orderList, urls, $state, $modal, toaster, $filter,$localStorage) {

        if (ROOTCONFIG.debug) {
            console.log("into twiceAllocationController...");
            console.log(angular.toJson($state.current.url, true));
        }
        $scope.config = {
            //查询条件
            orderNo: "",
            orderId: "",
            startTime: "",
            endTime: "",
            startArea: "",
            endArea: "",

            openedStart: false,
            openedEnd: false,

            selectOrderInfos: []
        };
        $scope.functionName = $state.current.url;
        $scope.pageSize = 10;
        $scope.total = 0;
        $scope.currentPage = 1;

        $scope.formats = ['yyyy-MM-dd'];
        $scope.format = $scope.formats[0];

        //查询  waring success error
        $scope.searchOrderList = function () {
            // toaster.pop('waring', '提示', '请选择货主');
            // toaster.pop("wait","提示","正在加载...",1000);
            var getPlan = {
                "userId":$localStorage.chuanYangloginMessege.userId,
                "noticeNo": $scope.config.orderCode,
                "startTime": serverFormateDate($scope.config.startTime),
                "endTime": serverFormateDate($scope.config.endTime),
                "fromCity": $scope.config.startArea,
                "toCity": $scope.config.endArea,
                "flow": $scope.config.endArea,
                "page": $scope.currentPage,
                "length": $scope.pageSize,
                "allocated" : 1
            };
            console.log(getPlan);
            searchOrderListData(getPlan);
        }
        $scope.searchOrderList();
        function searchOrderListData(getPlan) {
            var urlTransportationList = ROOTCONFIG.basePath + "info/tPlanInfo/select";
            urls.sendRequest('POST', angular.toJson(getPlan), urlTransportationList, '').success(function (response) {
                if (ROOTCONFIG.debug) {
                    console.log(angular.toJson(response, true));
                }
                if (response.code == '100') {
                    $scope.total = response.data.plans.total;
                    $scope.transportationList = response.data.plans.data;
                    $scope.isCollapsed = [];
                    for (var i = 0; i < $scope.transportationList.length; i++) {
                        $scope.transportationList[i].selected == false;
                        $scope.isCollapsed[i] = true;
                        // $scope.transportationList[i].createTime = $filter('date')(new Date($scope.transportationList[i].createTime), 'yyyy-MM-dd hh:mm:ss');
                    }
                } else if (response.code = '101') {
                    toaster.pop("waring", "提示", response.msg);
                } else if (response.code = '110') {

                }
            });
        }

        function searchOrderNumListData(index,item) {
            var urlTransportationChildList = ROOTCONFIG.basePath + "info/tPlanInfo/selectTPlanGoodsRelate?noticeNo=" + item.noticeNo;
            console.log(urlTransportationChildList);
            urls.sendRequest('get', '', urlTransportationChildList, '').success(function (response) {
                if (ROOTCONFIG.debug) {
                    console.log(angular.toJson(response, true));
                }
                if (response.code == '100') {
                    $scope.transportationChildList = response.data;
                    if($scope.transportationChildList.length>0){
                        $scope.isCollapsed[index] = !$scope.isCollapsed[index];
                    }else{
                        toaster.pop("waring", "提示", "暂无运单!");
                    }

                } else if (response.code = '101') {
                    toaster.pop("waring", "提示", response.msg);
                } else if (response.code = '110') {

                }
            });
        }

        $scope.isCollapsed = [];
        $scope.orderList = [];
        $scope.transportationList = [];
        $scope.transportationChildList = [];
        console.log(angular.toJson($scope.transportationList, true));
        for (var i = 0; i < $scope.transportationList.length; i++) {
            $scope.isCollapsed[i] = true;
        }

        $scope.getAllocationPlan = function (index, item) {
            if ($scope.isCollapsed[index] === true) {
                searchOrderNumListData(index,item);
            }
        };

        //选择时间的
        $scope.open = function ($event, item) {
            $event.preventDefault();
            $event.stopPropagation();
            if (item == 'start') {
                $scope.config.openedStart = true;
            } else {
                $scope.config.openedEnd = true;

            }
        };
        function serverFormateDate(dateObject) {
            if (angular.isUndefined(dateObject) || dateObject == null) {
                return '';
            }
            return $filter('date')(dateObject, 'yyyy/MM/dd');
        };

        //分页
        $scope.DoCtrlPagingAct = function (text, page, pageSize, total) {
            $scope.currentPage = page;
            $scope.searchOrderList();
            console.log("分页点击：" + text + page + pageSize + total);
        };
    }]);