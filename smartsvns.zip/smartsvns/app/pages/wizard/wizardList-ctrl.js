/**
 * Created by W on 2016/10/25.
 */
chuanyang.controller('wizardListCtrl',['$scope','urls','$modal','$state','$localStorage','toaster',function($scope,urls,$modal,$state,$localStorage,toaster){
    console.log($localStorage);
    $scope.wizardListData=[];
    var wizardChildUrl=ROOTCONFIG.basePath+"info/wizard/selWizardByfirmId";
    $scope.wizardParamsChild = {
        "firmId":4
    };
    $scope.wizardListShow=function(){
        urls.sendRequest('POST', angular.toJson($scope.wizardParamsChild), wizardChildUrl, '').success(function (response) {
            if(response.code==100){
                console.log(response);
                $scope.wizardListData=angular.copy(response.data);
            }
        })

    }
    $scope.wizardListShow();
//删除
    $scope.deleteData=function(){
        $scope.items={
            "title":"提示",
            "tips":"确定删除？"
        }
        var modalInstance = $modal.open({
            templateUrl: 'wizardModal.html',
            controller: 'wizardModelCtrl',
            resolve: {
               items: function () {
                    return $scope.items;
                }
            }
        });
    }
    //查看订单
    $scope.detailsShow=function(data){
        //订单列表
        var orderDetailsUrl=ROOTCONFIG.basePath+"info/wizard/selOrderBywizardId";
        $scope.orderDetailsParams={
            "wizardId":data.wizardId
        };
        console.log(angular.toJson($scope.orderDetailsParams,true));
        urls.sendRequest('POST', angular.toJson($scope.orderDetailsParams), orderDetailsUrl, '').success(function (response) {
            if(response.code==100){
                console.log(response.data);
                if(response.data[0]!=null){
                    $scope.noOrderShow=false;
                    console.log(angular.toJson(response,true));
                    $scope.orderDetailsList=angular.copy(response.data);
                }else{
                    $scope.noOrderShow=true;
                }

                $scope.items={
                    "title":data.wizardName+"的订单详情",
                    "orderData":$scope.orderDetailsList
                };
                var modalInstance = $modal.open({
                    templateUrl: 'WizardOrderDetail.html',
                    controller: 'wizardModelCtrl',
                    size:'lg',
                    resolve: {
                        items: function () {
                            return $scope.items;
                        }
                    }
                });
            }
        });
    };

    //显示地图
    $scope.showMap=function(items){
        $scope.mapImageParam={
            "wizardId":items.wizardId
        };
        urls.sendRequest('POST', angular.toJson($scope.mapImageParam),wizardChildUrl, '').success(function (response) {
            if(response.code==100){
                console.log(angular.toJson(response,true));
                if(response.data[0].image==undefined||response.data[0].image==""){
                    toaster.pop("message","提示","无位置信息");
                    return false;
                };
                $scope.items={
                    "image":{'url':response.data[0].image}
                };
                var modalInstance = $modal.open({
                    templateUrl: 'wizardModal.html',
                    controller: 'wizardModelCtrl',
                    resolve: {
                        items: function () {
                            return $scope.items;
                        }
                    }
                });
            }
        });

    };

}]);


chuanyang.controller('wizardModelCtrl', ['$scope', '$modalInstance', 'items',function ($scope, $modalInstance, items) {
    $scope.items = items;
    $scope.add = function () {
        $scope.selected = items;
        console.log($scope.selected);
        $modalInstance.close($scope.selected);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);