/**
 * Created by fangqiang on 17/1/3.
 */
angular.module('chuanyang').controller('subscriptionManagementController', subscriptionManagementController);
subscriptionManagementController.$inject = ['$http', '$state', '$localStorage', 'urls', '$scope', '$modal', 'toaster'];
function subscriptionManagementController($http, $state, $localStorage, urls, $scope, $modal, toaster) {
    var vm = this;
    vm.page = 1;
    vm.length = 7;
    vm.total = 10;
    vm.mySubs = true;
    vm.ortherSubs = false;
    vm.allType = [{
        "id": 1,
        "name": "司机"
    }, {
        "id": 2,
        "name": "车队"
    }];
    vm.selectSubscritions = function () {
        $scope.hideLoading = false;
        var params = {};
        vm.allSubscriptions = [];
        var flag = {
            "flag": true
        };
        params.length = vm.length;
        params.page = vm.page;
        params.subscriptionType = vm.subscriptionType;
        params.name = vm.name;
        params.userId = $localStorage.chuanYangloginMessege.userId;
        var url = ROOTCONFIG.basePath2 + "info/subscription/selSubscriptionByType";
        urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {
            $scope.hideLoading = true;
            if (response.code == "100") {
                vm.total = response.data.total;
                angular.copy(response.data.data, vm.allSubscriptions);
                vm.allSubscriptions.splice(0, 0, flag);
            } else {
                toaster.pop('error', '提示', '查询失败,请联系管理员');
            }
            console.log(angular.toJson(response, true));
        }).error(function (status) {
            $scope.hideLoading = true;
            toaster.pop('error', '提示', '查询失败,请联系管理员');

        })
    };
    vm.selectSubscritions();

    vm.doCtrlPagingAct = function (pageFlag, page, pageSize, total) {
        vm.page = page;
        vm.selectSubscritions();
    };
    vm.addSubscriptions = function () {

    };

    vm.changeTab = function (flag) {
        switch (flag) {
            case 1:
                vm.mySubs = true;
                vm.ortherSubs = false;
                break;
            case 2:
                vm.mySubs = false;
                vm.ortherSubs = true;
                break;
        }
    };

    vm.selectMore = function () {
        vm.page = 1;
        vm.selectSubscritions();

    };

    vm.addSubscriptions = function () {
        $scope.items = {
            "title": "添加订阅对象",
            "data": [
                {type: 'detel', filter: 'text'}
            ]
        };
        var modalInstance = $modal.open({
            templateUrl: 'addSubscription.html',
            controller: 'addSubscriptionCtrl',
            resolve: {
                items: function () {
                    return $scope.items;
                }
            }
        });

        modalInstance.result.then(function (selectedItem) {
            if(selectedItem == true){
                vm.selectSubscritions();
            }
        }, function () {
        });


    };
    $scope.max = 5;
    $scope.readonly = false;
    $scope.onHover = function (val) {
        $scope.hoverVal = val;
    };
    $scope.onLeave = function () {
        $scope.hoverVal = null;
    };
    $scope.onChange = function (val) {
        $scope.ratingVal = val;
    }
}

angular.module('chuanyang').controller('addSubscriptionCtrl', addSubscriptionCtrl);
addSubscriptionCtrl.$inject = ['$http', '$state', '$localStorage', 'urls', '$scope', '$modal', 'toaster', 'items', '$modalInstance'];
function addSubscriptionCtrl($http, $state, $localStorage, urls, $scope, $modal, toaster, items, $modalInstance) {
    $scope.items = items;
    $scope.memberName = {};
    $scope.selectMember = function () {
        $scope.hideFlag = true;
        $scope.subMembwe = [];
        var params = {
            "length": "10",
            "page": "1",
            "name": $scope.memberName.memberName

        };
        var url = ROOTCONFIG.basePath4 + "info/homePage/selhomePageByName";
        urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {
            $scope.hideFlag = false;
            console.log(angular.toJson(response, true));
            if (response.code == '101') {
            } else if (response.code == '100') {
                angular.copy(response.data.data, $scope.subMembwe);
            }
        }).error(function (status) {
            $scope.hideFlag = false;

        });
    };
    $scope.onHover = function () {

    };
    $scope.onLeave = function () {

    };
    $scope.returnFlag = false;
    $scope.subscriptionsThis = function (list) {
        console.log(angular.toJson(list, true));
        var params = {
            "userId": $localStorage.chuanYangloginMessege.userId,
            "subscriptionId": list.id,
            "subscriptionType": list.subscriptionType

        };
        var url = ROOTCONFIG.basePath4 + "info/subscription/addSubscription";
        urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {
            if (response.code == '101') {
                toaster.pop('error', '提示', response.msg);

            } else if (response.code == '100') {
                list.flag = true;
                $scope.returnFlag = true;

                toaster.pop('success', '提示', '订阅成功');
            }
        }).error(function (status) {
            toaster.pop('error', '提示', '订阅失败');

        });

    };


    $scope.selectDetails = function (list) {
        $scope.items = {
            "title": "查看详情",
            "data": list
        };
        var modalInstance = $modal.open({
            templateUrl: 'memberDetails.html',
            controller: 'memberDetailsCtrl',
            // size:"lg",
            resolve: {
                items: function () {
                    return $scope.items;
                }
            }
        });


    };
    $scope.add = function () {
        $scope.selected = $scope.returnFlag;
        $modalInstance.close($scope.selected);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}

angular.module('chuanyang').controller('memberDetailsCtrl', memberDetailsCtrl);
memberDetailsCtrl.$inject = ['$http', '$state', '$localStorage', 'urls', '$scope', '$modal', 'toaster', 'items', '$modalInstance'];
function memberDetailsCtrl($http, $state, $localStorage, urls, $scope, $modal, toaster, items, $modalInstance) {
    $scope.items = items;
    var url = ROOTCONFIG.basePath4 + "info/driver/selectDriverInfo";
    var params = {
        driverId: $scope.items.data.id
    };
    $scope.flagLoading = true;

    if ($scope.items.data.subscriptionType == 2) {
        url = ROOTCONFIG.basePath4 + "info/driver/selectFleetInfo";
        params = {
            fleetId: $scope.items.data.id
        };
    }

    urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {
        $scope.flagLoading = false;

        console.log(angular.toJson(response, true));
        if (response.code == '101') {
            toaster.pop('error', '提示', response.msg);

        } else if (response.code == '100') {
            $scope.memberDetails = response.data;
        }
    }).error(function (status) {

    });
    $scope.onHover = function () {

    };
    $scope.onLeave = function () {

    };
    $scope.add = function () {
        $scope.selected = items;
        $modalInstance.close($scope.selected);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
};