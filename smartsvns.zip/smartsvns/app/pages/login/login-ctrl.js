/**
 * Created by admin on 2016/10/19.
 */

chuanyang.controller('loginCtrl', ['$scope', '$state', '$localStorage', '$modal', 'urls', '$rootScope','$interval','$filter',
    function ($scope, $state, $localStorage, $modal, urls, $rootScope,$interval,$filter) {
    //console.log("into loginCtrl...", ROOTCONFIG.debug);
    $scope.userType = -1;
    $scope.orderList = [];
    $scope.orderBox = {};
    $scope.param = {};
    $scope.person = {};

    $scope.total = 0;
    $scope.currentPage = 1;//当前页
    $scope.pageSize = 6;//每页多少条数据


    //日期
    $scope.cacleTask = function () {

    };
    $scope.today = function () {
        $scope.dt = new Date();
    };
    $scope.today();

    $scope.clear = function () {
        $scope.dt = null;
    };

    // Disable weekend selection
    $scope.disabled = function (date, mode) {
        return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
    };

    $scope.toggleMin = function () {
        $scope.minDate = $scope.minDate ? null : new Date();
    };
    $scope.toggleMin();


    $scope.open = function ($event) {
        $event.preventDefault();
        $event.stopPropagation();
        $scope.opened = true;
    };
    $scope.open1 = function ($event) {
        $event.preventDefault();
        $event.stopPropagation();
        $scope.opened1 = true;
    };

    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1,
        class: 'datepicker',
        lang: 'zh-cn'
    };

    $scope.dateOptions1 = {
        formatYear: 'yy',
        startingDay: 1,
        class: 'datepicker',
        lang: 'zh-cn'
    };
    $scope.initDate = new Date('2016-15-20');
    $scope.formats = ['yyyy-MM-dd'];
    $scope.format = $scope.formats[0];

    //订单列表
    $scope.timeSetting = [];
    $scope.getOrderList = function () {
        $scope.orderBox.page = $scope.currentPage;
        $scope.orderBox.length = $scope.pageSize;
        console.log(angular.toJson($scope.orderBox, true));
        var getOrderListUrl = ROOTCONFIG.basePath + "info/driverWeb/selectOrderListMsg";//获取订单列表

        urls.sendRequest('POST', angular.toJson($scope.orderBox), getOrderListUrl).success(function (response) {
            for (var i = 0; i < response.data.data.length; i++) {
                $scope.timeSetting[i] = {};
                $scope.timeSetting[i].endTime = response.data.data[i].expiredTime;
            }
            var url = "http://www.chuanyangwuliu.com/version/time.php";
            urls.sendRequest('GET', '', url, '').success(function (response) {
                for (var j = 0; j < $scope.timeSetting.length; j++) {
                    $scope.timeSetting[j].endTime =  - response +  $scope.timeSetting[j].endTime
                }
                $interval(function(){
                    for (var j = 0; j < $scope.timeSetting.length; j++) {
                        $scope.timeSetting[j].endTime-=1000;
                    }
                    // console.log($scope.timeSetting)
                },1000)
            });
            console.log(angular.toJson(response, true));
            //forMessage("close");
            if (response.code == '101') {
            } else if (response.code == '100') {
                $scope.orderList = response.data.data;
                $scope.total = response.data.total;
            }
        })
    };

    //查询订单
        $scope.selectByorder = function () {
            /*$scope.param.orderTime = $scope.person.dateOne;*/
            /*$scope.param.startTime = $scope.person.date;*/
            $scope.param.orderTime = $filter('date')($scope.person.dateOne, 'yyyy-MM-dd');
            $scope.param.startTime = $filter('date')($scope.person.date, 'yyyy-MM-dd');

            $scope.param.orderType = $scope.orderBox.orderType;
            $scope.param.page = $scope.currentPage;
            $scope.param.length = $scope.pageSize;

            console.log(angular.toJson($scope.param,true));
            var getOrderListUrl = ROOTCONFIG.basePath + "info/driverWeb/selectOrderListMsg";//获取订单列表
            urls.sendRequest('POST', angular.toJson($scope.param), getOrderListUrl).success(function (response) {
                console.log(angular.toJson(response,true));
                if (response.code == '100') {
                    $scope.orderList = response.data.data;
                    $scope.total = response.data.total;
                } else {
                }
            });
        };


    $scope.orderType = function (flag) {
        if (flag === 1) {
            $scope.orderBox.orderType = flag;
        } else if (flag === 2) {
            $scope.orderBox.orderType = flag;
        }
        $scope.getOrderList();
    };
    $scope.orderType(1);


    if (ROOTCONFIG.debug) {
        console.log("into loginCtrl...");
    }

    $scope.user = {
        "userName": "",
        "password": ""
    };
    $scope.login = function () {
        if ($scope.userType == -1) {
            alert("请选择登录角色！");
            return;
        }


        var getOrderListUrl = ROOTCONFIG.basePath4 + "info/driverWeb/selectOrderListMsg";//获取用户列表


        //登陆
        console.log(angular.toJson($scope.user)+"***");
        var urlLogin = ROOTCONFIG.basePath4 + "info/user/signIn";
        urls.sendRequest('POST', angular.toJson($scope.user), urlLogin, '').success(function (response) {
            console.log(angular.toJson($scope.user, true));
          // $rootScope.loginMessege = response.data;
            console.log(angular.toJson($localStorage.chuanYangloginMessege, true));
            if (ROOTCONFIG.debug) {
                console.log(angular.toJson(response, true));
            }
            if (response.code == '100') {
                $localStorage.chuanYangloginMessege = response.data;
                //根据用户类型跳转界面
                if ($scope.userType == 1) {
                    $state.go('home.shipperList');
                    $localStorage.chuanYangloginMessege.selected = 'shipper';
                } else if ($scope.userType == 2) {
                    $state.go('home.welcome');
                    $localStorage.chuanYangloginMessege.selected = 'logistic';//暂时driver改为logistic
                } else if ($scope.userType == 3) {
                    $state.go('home.allocationOrder');
                    $localStorage.chuanYangloginMessege.selected = 'logistic';
                }

                /*----------------------------------------*/
            } else {
                toaster.pop('error', '提示', '登录失败');
            }
        });

    };
    /*$(".login_role ul li").on("click",function(){
     console.log(this);
     })*/

    $(".login_role ul li a").click(function () {
        var n = $(".login_role ul li a").index(this);
        /*document.title=n;*/
        $(".login_role ul li a").removeClass("add_border").eq(n).addClass("add_border");
        if (n == 0) {
            $scope.userType = 1;
        } else if (n == 1) {
            $scope.userType =3;
        } //else if (n == 2) {
        //    $scope.userType = 3;
    //    }
        $scope.user.userType=$scope.userType;
        console.log($scope.userType);
    });
    //注册用户
    $scope.loginUser = function () {
        var user = {};
        $scope.items = {
            title: "注册用户"
        };
        var modalInstance = $modal.open({
            templateUrl: 'loginUser.html',
            controller: 'repeatModelCtrl',
            resolve: {
                items: function () {
                    return $scope.items;
                },
                user: function () {
                    return user;
                }
            }
        });
        /*console.log(angular.toJson(user,true));*/
        modalInstance.result.then(function (loginUser) {
            console.log(angular.toJson(loginUser, true));
        });
    };
    $(".new-a .delect-b").click(function () {
        var n = $(".new-a .delect-b").index(this);
        /*document.title=n;*/
        $(".new-a .delect-b").removeClass("add-border").eq(n).addClass("add-border");
    });


    //分页

    $scope.DoCtrlPagingAct = function (text, currentPage, pageSize, total) {
        $scope.currentPage = currentPage;
        //$scope.selectByUserName();
        $scope.getOrderList();
        console.log("分页点击：" + currentPage);
    };

    $scope.dialogQR = function () {
        $("#qrcode").show();
    };


        $scope.myInterval = 5000;

        var slides = $scope.slides = [];
        $scope.addSlide = function() {
            var newWidth = 600 + slides.length + 1;

            slides.push({

                image: 'img/official/phone.png'


            });

        };

        for (var i=0; i<4; i++) {

            $scope.addSlide();

        }

//title
        $scope.orderInfo=true;
        $scope.wayBillInfo=false;
        $scope.getSearch = function (size) {
            console.log(size);
            switch (size) {
                case 1:
                    $scope.orderInfo=true;
                    $scope.wayBillInfo=false;
                    break;
                case 2:
                    $scope.orderInfo=false;
                    $scope.wayBillInfo=true;
                    break;
            }

        };
        $scope.config = {};
        /*$scope.change= function(bind){
            console.log($scope.bind);
            console.log(bind);
        }*/
        $scope.getOrderInfo = function () {
            console.log($scope.config.bind);

            $state.go('index.wayBillSearch.orderInfo',{orderMessage: $scope.config.bind});
            //console.log(angular.toJson(bind,true))
        }
        $scope.getWayBillInfo = function () {
            console.log($scope.config.bind);

            $state.go('index.wayBillSearch.wayBillInfo',{orderMessage: $scope.config.bind});
            //console.log(angular.toJson(bind,true))
        }

}]);

