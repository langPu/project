/**
 * Created by fangqiang on 16/10/22.
 */
'use strict';

/* Controllers */
// signin controller
angular.module('chuanyang').controller('manageFleetController', ['$scope',
    '$http',
    '$state',
    '$localStorage',
    'urls',
    '$modal',
    'toaster', function ($scope,
                         $http,
                         $state,
                         $localStorage,
                         urls,
                         $modal,
                         toaster) {
        $scope.labelClass = function(label) {
            console.log(label);
            return {
                'b-l-info': angular.lowercase(label) === 'angular',
                'b-l-primary': angular.lowercase(label) === 'bootstrap',
                'b-l-warning': angular.lowercase(label) === 'client',
                'b-l-success': angular.lowercase(label) === 'work'
            };
        };
        $scope.serchName = "";
        $scope.isCollapsed = [];
        $scope.mails = [];
        $scope.mailsChilds = [];
        $scope.getMotorcadeList = function (page) {//车队
            var getMotorcadeListUrl = ROOTCONFIG.basePath4 + "/info/driverWeb/selectFleetList";
            var params = {};
            params.logisticscompanyId = $localStorage.chuanYangloginMessege.companys[0].companyID;
            params.fleetName = $scope.serchName;
            params.startCity = $scope.startCity;
            params.targetCity = $scope.targetCity;
            params.length = "10";
            params.page = page;
            params.fleetType = 3;
            console.log(angular.toJson(params,true));
            console.log(angular.toJson($localStorage.chuanYangloginMessege,true));
            urls.sendRequest('POST', angular.toJson(params), getMotorcadeListUrl, '').success(function (response) {
                $scope.hideLoading = true;
                if (response.code == '101') {
                } else if (response.code == '100') {
                    console.log(angular.toJson(response, true));
                    $scope.total = response.data.total;
                    $scope.totalPages = response.data.totalPages;
                    if (response.data.data.length <= 4) {
                        angular.element("#motorcadeList").css('height', '500px');
                    } else {
                        angular.element("#motorcadeList").css('height', 'auto');
                    }
                    angular.copy(response.data.data, $scope.mails);
                    if(response.data.data[0] == undefined){
                        toaster.pop('info', '提示', '没有数据');

                    }
                    

                }
            }).error(function (status) {

            });
        };
        $scope.getMotorcadeList(1);
        $scope.selectMotorMember = function (index, motorMember) {//车队成员
            if ($scope.isCollapsed[index] == true) {

            } else if ($scope.isCollapsed[index] == false) {
                $scope.isCollapsed[index] = !$scope.isCollapsed[index];
            } else {
                $scope.mailsChilds[index] = [];
                $scope.isCollapsed[index] = !$scope.isCollapsed[index];
                var selectMemberUrl = ROOTCONFIG.basePath4 + "info/driverWeb/selectFleetDriverlist";
                var params = {};
                params.fleetId = motorMember.id;
                urls.sendRequest('POST', angular.toJson(params), selectMemberUrl, '').success(function (response) {
                    console.log(angular.toJson(response, true));
                    if (response.code == '101') {
                    } else if (response.code == '100') {
                        angular.copy(response.data, $scope.mailsChilds[index]);
                    }
                }).error(function (status) {
                });
            }
        };

        $scope.findMore = function () {
            $scope.getMotorcadeList(1);
        };

        $scope.checkMotordeLi = function (size, mail) {
            console.log(angular.toJson(mail,true));
            var selectMemberUrl = ROOTCONFIG.basePath4 + "info/driverWeb/selectFleetDriverlist";
            var params = {};
            $scope.items = {
                "title": "审核车队",
                "data": [
                    {type: 'checkList', filter: 'text'}

                ]
            };
            var modalInstance = $modal.open({
                templateUrl: 'changeMotorde.html',
                controller: 'repeatModelCtrl',
                size: size,
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                $scope.updateFleet(mail.id,mail.fleetName,mail.fleetLeader,1,size,mail)
            }, function () {
            });

        };

        $scope.changeMotordeLi = function (size, mail) {
            var selectMemberUrl = ROOTCONFIG.basePath4 + "info/driverWeb/selectFleetDriverlist";
            var params = {};
            params.fleetId = mail.id;
            urls.sendRequest('POST', angular.toJson(params), selectMemberUrl, '').success(function (response) {
                if (response.code == '101') {

                } else if (response.code == '100') {
                    $scope.items = {
                        "title": "修改车队",
                        "data": [
                            {name: '车队名称', type: 'text', filter: 'text'},
                            {name: '指定车队长', type: 'carLeader', filter: 'text', 'select': response.data},
                            {
                                name: '修改车队状态', type: 'portType', filter: 'text', 'select': [{
                                'key': 1,
                                'value': '认证'
                            }, {
                                'key': 2,
                                'value': '未认证'
                            }]
                            }
                        ]
                    };
                    var modalInstance = $modal.open({
                        templateUrl: 'changeMotorde.html',
                        controller: 'repeatModelCtrl',
                        size: size,
                        resolve: {
                            items: function () {
                                return $scope.items;
                            }
                        }
                    });
                    modalInstance.result.then(function (selectedItem) {
                        console.log(angular.toJson(selectedItem,true));
                        if (selectedItem.data[0].model || selectedItem.data[1].model || selectedItem.data[2].model) {
                            $scope.updateFleet(mail.id, selectedItem.data[0].model, selectedItem.data[1].model, selectedItem.data[2].model, size, mail);
                        } else {
                            toaster.pop('warning', '提示', '没有填写修改内容');

                        }
                    }, function () {
                    });
                }
            }).error(function (status) {
            });


        };

        $scope.updateFleet = function (id, fleetName, fleetLeader, fleetState, size, mail) {
            var params = {
                "id": id,
                "fleetName": fleetName,
                "fleetLeader": fleetLeader,
                "fleetState": fleetState
            };
            console.log(angular.toJson(params,true));
            var updateFleetUrl = ROOTCONFIG.basePath4 + "info/fleet/updateFleet";
            urls.sendRequest('POST', angular.toJson(params), updateFleetUrl, '').success(function (response) {
                if (response.code == "100") {
                    toaster.pop('success', '提示', '修改成功');
                    if (params.fleetName === undefined) {

                    } else {
                        $scope.mails[size].fleetName = fleetName;
                    }

                    if (params.fleetLeader === undefined) {

                    } else {
                        $scope.mails[size].fleetLeader = fleetLeader;

                    }
                    if (params.fleetState === undefined) {

                    } else {
                        $scope.mails[size].fleetState = fleetState;

                    }
                } else {
                    toaster.pop('error', '提示', '修改失败');

                }
            })
        };


        $scope.detelMotordeLi = function (size, mail) {
            $scope.items = {
                "title": "删除车队",
                "data": [
                    {type: 'detel', filter: 'text'}

                ]
            };
            var modalInstance = $modal.open({
                templateUrl: 'changeMotorde.html',
                controller: 'repeatModelCtrl',
                size: size,
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                var params = {
                    "id": mail.id
                };
                var deleteFleetUrl = ROOTCONFIG.basePath4 + "info/fleet/deleteFleet";
                urls.sendRequest('POST', angular.toJson(params), deleteFleetUrl, '').success(function (response) {
                    if (response.code == "100") {
                        toaster.pop('success', '提示', '删除成功');
                        $scope.mails.splice(size, 1);
                    } else {
                        toaster.pop('error', '提示', '删除失败');

                    }
                });
            }, function () {
            });
        };

        $scope.changeMemberLi = function (indexFa, indexCh, menberDetails) {
            $scope.items = {
                "title": "修改车队成员的状态",
                "data": [
                    {
                        name: '修改成员状态', type: 'portType', filter: 'text', 'select': [{
                        'key': 1,
                        'value': '认证'
                    }, {
                        'key': 2,
                        'value': '待司机认证'
                    }, {
                        'key': 4,
                        'value': '待车队长认证'
                    }]
                    }
                ]
            };
            var modalInstance = $modal.open({
                templateUrl: 'changeMotorde.html',
                controller: 'repeatModelCtrl',
                size: indexFa,
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                if (selectedItem.data[0].model === undefined) {
                    toaster.pop('warning', '提示', '没有填写修改内容');

                } else {
                    var params = {
                        "driverId": menberDetails.driverId,
                        "fleetDriverState": selectedItem.data[0].model,
                        "fleetId": $scope.mails[indexFa].id
                    };
                    var deleteFleetUrl = ROOTCONFIG.basePath4 + "info/fleet/updateFleetDriver";
                    urls.sendRequest('POST', angular.toJson(params), deleteFleetUrl, '').success(function (response) {
                        if (response.code == "100") {
                            toaster.pop('success', '提示', '修改成功');
                            $scope.mailsChilds[indexFa][indexCh].fleetDriverState = selectedItem.data[0].model;
                        } else {
                            toaster.pop('error', '提示', '修改失败');
                        }
                    });
                }
            }, function () {
            });
            // $scope.updateFleet(mail.id, selectedItem.data[0].model, selectedItem.data[1].model, selectedItem.data[2].model, size, mail);
        };
        $scope.detelMember = function (indexFa, indexCh, menberDetails) {
            $scope.items = {
                "title": "删除车队成员",
                "data": [
                    {type: 'detel', filter: 'text'}
                ]
            };
            var modalInstance = $modal.open({
                templateUrl: 'changeMotorde.html',
                controller: 'repeatModelCtrl',
                size: indexFa,
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                var params = {
                    "driverId": menberDetails.driverId,
                    "fleetDriverState": 3,
                    "fleetId": $scope.mails[indexFa].id
                };
                var deleteFleetUrl = ROOTCONFIG.basePath4 + "info/fleet/updateFleetDriver";
                urls.sendRequest('POST', angular.toJson(params), deleteFleetUrl, '').success(function (response) {
                    if (response.code == "100") {
                        toaster.pop('success', '提示', '删除成功');
                        $scope.mailsChilds[indexFa].splice(indexCh, 1);
                    } else {
                        toaster.pop('error', '提示', '删除失败');
                    }
                });
            }, function () {
            });
        };

        $scope.DoCtrlPagingAct = function (title, page, pageSize, total) {
            $scope.getMotorcadeList($scope.serchName ,page);
            console.log(title, page, pageSize, total);
        };
        $scope.today = function () {
            $scope.dt = new Date();
        };
        $scope.today();

        $scope.clear = function () {
            $scope.dt = null;
        };
        // Disable weekend selection
        $scope.disabled = function (date, mode) {
            return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
        };
        $scope.toggleMin = function () {
            $scope.minDate = $scope.minDate ? null : new Date();
        };
        $scope.toggleMin();
        $scope.open = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();
            $scope.opened = true;
        };

        $scope.dateOptions = {
            formatYear: 'yy',
            startingDay: 1,
            class: 'datepicker',
            lang: 'zh-cn'
        };

        $scope.initDate = new Date('2016-15-20');
        $scope.formats = ['yyyy-MM-dd'];
        $scope.format = $scope.formats[0];


        $scope.bigImg = function (img) {
            console.log(img);
            if (img === undefined) {

            } else {
                $scope.items = img;
                var modalInstance = $modal.open({
                    templateUrl: 'bigImg.html',
                    controller: 'repeatModelCtrl',
                    resolve: {
                        items: function () {
                            return $scope.items;
                        }
                    }
                });
                modalInstance.result.then(function (selectedItem) {
                }, function () {
                });
            }
        };
    }]);

//总模板
angular.module('chuanyang').controller('repeatModelCtrl', ['$scope', '$modalInstance', 'items', function ($scope, $modalInstance, items) {
    $scope.items = items;
    $scope.add = function () {
        $modalInstance.close($scope.items);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);
