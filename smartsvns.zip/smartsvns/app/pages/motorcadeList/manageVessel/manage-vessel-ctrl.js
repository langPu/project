/**
 * Created by fangqiang on 16/12/1.
 */
/**
 * Created by fangqiang on 16/9/7.
 */
angular.module('chuanyang').controller('manageAllFleetController', manageAllFleetController);
manageAllFleetController.$inject = ['$scope', '$http', '$state', '$localStorage', 'urls', '$modal', 'toaster'];
function manageAllFleetController($scope,
                                  $http,
                                  $state,
                                  $localStorage,
                                  urls,
                                  $modal,
                                  toaster) {

    var vm = this;
    vm.allCarMessage = [];
    vm.transportAllState = [{key: "2", name: "空闲"}, {key: "1", name: "在运"}];
    vm.driverAllState = [{key: "1", name: "认证"}, {key: "2", name: "未认证"}, {key: "3", name: "已删除"}];
    vm.getAllTheCar = function () {
        $scope.hideLoading = false;
        vm.isCollapsed = [];
        vm.allCarMessage = [];
        var params = {};
        params.driverState = vm.driverState;
        params.transportState = vm.transportState;
        params.plateNumber = vm.plateNumber;
        params.startCity = vm.startCity;
        params.targetCity = vm.targetCity;
        params.page = vm.page;
        params.length = vm.length;
        params.roleId = vm.roleId;
        params.driverType = 3;
        params.companyID = $localStorage.chuanYangloginMessege.companys[0].companyID;
        console.log(angular.toJson(params, true));
        console.log(angular.toJson($state.current, true));
        var getAllCarUrl;
            getAllCarUrl = ROOTCONFIG.basePath4 + "info/driver/selectDriverListCP";
        urls.sendRequest('POST', angular.toJson(params), getAllCarUrl, '').success(function (response) {
            console.log(angular.toJson(response, true));
            $scope.hideLoading = true;
            if (response.code == '101') {

            } else if (response.code == '100') {

                angular.copy(response.data.data, vm.allCarMessage);
                if(response.data.data[0] == undefined){
                    toaster.pop('info', '提示', '没有数据');

                }
                if (response.data.data.length <= 4) {
                    angular.element("#motorcadeList").css('height', '500px');
                } else {
                    angular.element("#motorcadeList").css('height', 'auto');
                }
                vm.total = response.data.total;
                vm.totalPages = response.data.totalPages;

            }
        }).error(function (status) {

        });

    };
    vm.page = 1;
    vm.length = 8;

    vm.doCtrlPagingAct = function (pageClink, page, pageSize, total) {
        vm.page = page;
        vm.getAllTheCar();
        console.log(pageClink, page, pageSize, total);
    };
    vm.bigImg = function (img) {
        console.log(img);
        if (img === undefined) {

        } else {
            $scope.items = img;
            var modalInstance = $modal.open({
                templateUrl: 'bigImg.html',
                controller: 'repeatModelCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
            }, function () {
            });
        }
    };
    vm.labelClass = function (label) {
        return {
            'b-l-info': label == '1',
            // 'b-l-primary': label == '3',
            'b-l-danger': label == '2' || label == '3' || label == undefined,
            'b-l-success': label === '4'
        };
    };
    vm.findLocations = function () {
        console.log('test');
        $state.go("app.carLocations", {
            carID: 117917,
            size: 2
        })
    };

    vm.changeState = function (state, data, index) {
        $scope.items = {
            "title": "修改成员的状态",
            "data": [
                {
                    name: '修改成员状态', type: 'portType', filter: 'text', 'select': [{
                    'key': 1,
                    'value': '认证'
                }, {
                    'key': 2,
                    'value': '未认证'
                }, {
                    'key': 3,
                    'value': '已删除'
                }], 'model': state
                }
            ]
        };
        var modalInstance = $modal.open({
            templateUrl: 'changeConpany.html',
            controller: 'repeatModelCtrl',
            size: 'small',
            resolve: {
                items: function () {
                    return $scope.items;
                }
            }
        });
        modalInstance.result.then(function (selectedItem) {
            console.log(angular.toJson(selectedItem, true));
            if (selectedItem.data[0].model === undefined) {
                toaster.pop('warning', '提示', '没有填写修改内容');

            } else {
                var params = {};
                var changeStateUrl = "";
                if (selectedItem.data[0].model == 1) {
                    changeStateUrl = ROOTCONFIG.basePath4 + "info/driver/updateApprove";
                    params = {
                        'driverId': data.driverId
                    };
                } else {
                    changeStateUrl = ROOTCONFIG.basePath4 + "info/driver/update";
                    params = {
                        'driverId': data.driverId,
                        'driverState': selectedItem.data[0].model
                    };
                }

                console.log(angular.toJson(params, true));
                urls.sendRequest('POST', angular.toJson(params), changeStateUrl, '').success(function (response) {
                    toaster.clear();
                    if (response.code == '101') {
                        toaster.pop('danger', '提示', response.msg);

                    } else if (response.code == '100') {
                        toaster.pop('success', '提示', '修改成功');
                        vm.allCarMessage[index].driverState = selectedItem.data[0].model;

                    }
                }).error(function (status) {

                });

            }
        }, function () {
        });

    };
//获取角色
    vm.allRoles = [];
    vm.getAllRole = function () {
        var url = ROOTCONFIG.basePath4 + "info/role/getRole";
        var params = {};
        params.userType = 2;
        urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {
            if (response.code == "100") {
                angular.copy(response.data, vm.allRoles);
                console.log(angular.toJson(vm.allRoles, true));

                vm.getAllTheCar();
            } else {

            }
        }).error(function (status) {

        })
    };
    vm.getAllRole();
    vm.returnRoleName = function (roleId) {
        if (roleId == undefined) {
            return "暂未分配角色"
        } else {
            for (var i = 0; i < vm.allRoles.length; i++) {
                if (vm.allRoles[i].id == roleId) {
                    return vm.allRoles[i].rolename;
                }

            }
        }

    };


    vm.addCar = function () {
        $scope.items = {
            "title": "选择船只",
            "name": "选择船只",
            "ship":true
        };
        var modalInstance = $modal.open({
            templateUrl: 'selectMotorcadeModel.html',
            controller: 'addMemberController',
            resolve: {
                items: function () {
                    return $scope.items;
                }
            }
        });
        modalInstance.result.then(function (selectedItem) {
            console.log(angular.toJson(selectedItem.selected, true));
            var params = {};
            params.companyID = $localStorage.chuanYangloginMessege.companys[0].companyID;
            params.driverId = selectedItem.selected.userId;
            var url = ROOTCONFIG.basePath4 + "info/driver/addLcDriver";
            toaster.pop('wait', '提示', '正在更改数据', 60000);
            urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {
                toaster.clear();
                if (response.code == "100") {
                    toaster.pop('success', '提示', '添加成功');
                    vm.getAllTheCar();
                } else {
                    toaster.pop('error', '提示', '添加失败');

                }
            });

        }, function () {
        });
    };


    vm.deleteCar = function (data, index, flag) {

        if (flag == 3) {
            vm.items = {
                "title": "确认不再邀请,删除邀请?",
                "data": [
                    {type: 'detel', filter: 'text'}

                ]
            };
        } else if (flag == 2) {
            vm.items = {
                "title": "是否接受订阅请求?",
                "data": [
                    {
                        name: '同意或者拒绝', type: 'portType', filter: 'text', 'select': [{
                        'key': 1,
                        'value': '同意'
                    }, {
                        'key': 2,
                        'value': '拒绝'
                    }], 'model': data.status
                    }
                ]
            }

        } else {

            vm.items = {
                "title": "是否移除,删除该成员?",
                "data": [
                    {type: 'detel', filter: 'text'}

                ]

            }
        }

        var modalInstance = $modal.open({
            templateUrl: 'changeConpany.html',
            controller: 'repeatModelCtrl',
            size: 'small',
            resolve: {
                items: function () {
                    return vm.items;
                }
            }
        });
        modalInstance.result.then(function (selectedItem) {
            var deleteFleetUrl = ROOTCONFIG.basePath4 + "info/driver/deleteLcDriver";
            var params = {
                "driverId": data.driverId,
                "companyID": $localStorage.chuanYangloginMessege.companys[0].companyID
            };
            if (flag == 2) {
                if (params.status == 1) {
                    params.status = selectedItem.data[0].model;
                    deleteFleetUrl = ROOTCONFIG.basePath4 + "info/driver/updateLcDriver";
                }
            } else {

            }

            urls.sendRequest('POST', angular.toJson(params), deleteFleetUrl, '').success(function (response) {
                if (response.code == "100") {
                    if (flag == 2){
                        if (params.status == 1) {
                            vm.allCarMessage[index].status = 1;
                        }else{
                            vm.allCarMessage.splice(index, 1);

                        }
                    }else {
                        toaster.pop('success', '提示', '移除成功');
                        vm.allCarMessage.splice(index, 1);

                    }
                } else {
                    toaster.pop('error', '提示', '修改失败');

                }
            });
        }, function () {
        });

        console.log("删除");
    };
    vm.changeCar = function (data, index) {
        console.log(angular.toJson(data, true));
        console.log(angular.toJson(index, true));
        // vm.changeMotordeLi = function (index, data) {
        //     console.log(angular.toJson(index, true), angular.toJson(data, true));
        vm.items = {
            "title": "修改车辆信息",
            "data": [
                {name: '车牌', type: 'text', filter: 'text', model: data.plateNumber},
                {name: '司机运力', type: 'text', filter: 'text', model: data.capacity},
                {name: '司机实际运力', type: 'text', filter: 'text', model: data.actualCapacity},
                {name: '保险单', type: 'text', filter: 'text', model: data.driverInsurance},
                {name: '车辆规格', type: 'text', filter: 'text', model: data.carStandard},
                {name: '备注', type: 'text', filter: 'text', model: data.driverRemark}
                // {name: '修改GPS信息', type: 'text', filter: 'text', model: data.driverRemark}

            ]
        };
        var modalInstance = $modal.open({
            templateUrl: 'changeConpany.html',
            controller: 'repeatModelCtrl',
            resolve: {
                items: function () {
                    return vm.items;
                }
            }
        });
        modalInstance.result.then(function (selectedItem) {
            console.log(angular.toJson(selectedItem, true));
            if (selectedItem.data[0].model === "") {
                toaster.pop('warning', '提示', '车牌号不能为空为空');

            } else {
                toaster.pop('wait', '提示', '正在更改数据', 60000);

                var params = {
                    "driverId": data.driverId,
                    "plateNumber": selectedItem.data[0].model,
                    "capacity": selectedItem.data[1].model,
                    "actualCapacity": selectedItem.data[2].model,
                    "driverInsurance": selectedItem.data[3].model,
                    "carStandard": selectedItem.data[4].model,
                    "driverRemark": selectedItem.data[5].model

                };
                var deleteFleetUrl = ROOTCONFIG.basePath4 + "info/driver/update";
                urls.sendRequest('POST', angular.toJson(params), deleteFleetUrl, '').success(function (response) {
                    toaster.clear();
                    if (response.code == "100") {

                        toaster.pop('success', '提示', '修改成功');
                        vm.allCarMessage[index].plateNumber = params.plateNumber;
                        vm.allCarMessage[index].capacity = params.capacity;
                        vm.allCarMessage[index].actualCapacity = params.actualCapacity;
                        vm.allCarMessage[index].driverInsurance = params.driverInsurance;
                        vm.allCarMessage[index].carStandard = params.carStandard;
                        vm.allCarMessage[index].driverRemark = params.driverRemark;


                    } else {
                        toaster.pop('error', '提示', '修改失败');
                    }
                });
            }
        }, function () {
        });
    };
}

