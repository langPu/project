/**
 * Created by fangqiang on 16/10/28.
 */
    'use strict';
    angular.module('chuanyang').controller('manageCompanyController', manageCompanyController);
    manageCompanyController.$inject = ['$http', '$state', '$localStorage', 'urls', '$scope', '$modal', 'toaster'];
    function manageCompanyController($http, $state, $localStorage, urls, $scope, $modal, toaster) {
        var vm = this;
        vm.page = 1;
        vm.length = 7;
        vm.selectAllCompanys = function () {
            vm.flag = false;
            var url = ROOTCONFIG.basePath2 + "info/lgCompany/getCooperateCompany";
            var params = {
                "userId": $localStorage.chuanYangloginMessege.userId,
                "page": vm.page,
                "length": vm.length
            };

            console.log(angular.toJson(params,true));
            urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {
                vm.flag = true;
                $scope.hideLoading = true;
                console.log(angular.toJson(response, true));
                if (response.code == '101') {
                } else if (response.code == '100') {
                    if (response.data.data[0] == undefined) {

                    } else {
                        angular.copy(response.data.data, vm.companys);
                        if(response.data.data[0] == undefined){
                            toaster.pop('info', '提示', '没有数据');

                        }
                        if (response.data.data.length <= 4) {
                            angular.element("#motorcadeList").css('height', '500px');
                        } else {
                            angular.element("#motorcadeList").css('height', 'auto');
                        }
                    }
                    vm.total = response.data.total;
                }
            }).error(function (status) {

            });
        };
        vm.companys = [];
        vm.selectAllCompanys();
        vm.doCtrlPagingAct = function (size, page, pageSize, total) {
            console.log(page);
            vm.page = page;
            vm.companys = [];
            vm.selectAllCompanys()

        };
        vm.changeCompanyMessage = function (index, list) {
            console.log(angular.toJson(index, true), angular.toJson(list, true));
            vm.items = {
                "title": "取消关联",
                "data": [
                    {name: '', type: 'detelCompany', filter: 'text'}

                ]
            };
            var modalInstance = $modal.open({
                templateUrl: 'changeConpany.html',
                controller: 'repeatModelCtrl',
                resolve: {
                    items: function () {
                        return vm.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                console.log(angular.toJson(selectedItem, true));
                var  params  ={
                    "companyB":$localStorage.chuanYangloginMessege.companys[0].companyID,
                    "companyA":list.id
                };
                    var deleteFleetUrl = ROOTCONFIG.basePath2 + "info/CompanyCooperate/delete";
                    urls.sendRequest('POST', angular.toJson(params), deleteFleetUrl, '').success(function (response) {
                        toaster.clear();
                        if (response.code == "100") {
                            vm.companys.splice(index,1);
                            toaster.pop('success', '提示', '取消成功');
                        } else {
                            toaster.pop('error', '提示', '取消失败');
                        }
                    });

            }, function () {
            });
        };
        vm.allCompanyss = [];
        vm.addCompanys = function () {
            toaster.pop('wait', '提示', '正在查询所有物流公司', 6000);
            var deleteFleetUrl = ROOTCONFIG.basePath2 + "info/lgCompany/getAllCompany";
            urls.sendRequest('POST', '', deleteFleetUrl, '').success(function (response) {
                toaster.clear();
                if (response.code == "100") {
                    console.log(angular.toJson(response, true));

                    angular.copy(response.data, vm.allCompanyss);
                    $scope.items = {
                        "title": "关联物流公司",
                        "data": [
                            {
                                name: '选择物流公司', type: 'portType', filter: 'text', 'select': []
                            }
                        ]
                    };
                    for (var i = 0; i < response.data.length; i++) {
                        $scope.items.data[0].select[i] = {};
                        $scope.items.data[0].select[i].key = i;
                        $scope.items.data[0].select[i].value = response.data[i].logisticsCompanyName;

                    }
                    var modalInstance = $modal.open({
                        templateUrl: 'changeConpany.html',
                        controller: 'repeatModelCtrl',
                        resolve: {
                            items: function () {
                                return $scope.items;
                            }
                        }
                    });
                    modalInstance.result.then(function (selectedItem) {
                        console.log(angular.toJson(selectedItem, true));
                        var params = {
                            companyA: $localStorage.chuanYangloginMessege.companys[0].companyID,
                            companyB: vm.allCompanyss[selectedItem.data[0].model].id,
                            createUser: $localStorage.chuanYangloginMessege.userId
                        };
                        console.log(angular.toJson(params, true));

                        var url = ROOTCONFIG.basePath2 + "info/CompanyCooperate/insert";
                        toaster.pop('wait', '提示', '正在添加物流公司', 6000);
                        urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {
                            toaster.clear();
                            if (response.code == '101') {
                                toaster.pop('error', '提示', '添加失败,请查看是否已经关联');
                            } else if (response.code == '100') {
                                vm.companys.push(vm.allCompanyss[selectedItem.data[0].model]);
                                toaster.pop('success', '提示', '添加成功');
                            }
                        }).error(function (status) {

                        });


                    }, function () {
                    });

                } else {
                }
            });
        }

    }
