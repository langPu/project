/**
 * Created by fangqiang on 16/11/17.
 */
        'use strict';
        angular.module('chuanyang').controller('createMotorcadeController', createMotorcadeController);
    createMotorcadeController.$inject = ['$http', '$state','$scope'];
        function createMotorcadeController($http, $state,$scope) {
            $scope.functionName = $state.current.url;
            var vm = this;
            vm.addCarrier = function (size) {
                console.log(size);
                switch (size) {
                    case 1:
                        $state.go("home.createMotorcade.allCar");
                        $scope.functionName = "/allCar";

                        break;
                    case 2:
                        $state.go("home.createMotorcade.createMotorcade");
                        $scope.functionName = "/createMotorcade";

                        break;
                    case 3:
                        $state.go("home.createMotorcade.createShipFleet");
                        $scope.functionName = "/createShipFleet";

                        break;
                }

            };
        }
