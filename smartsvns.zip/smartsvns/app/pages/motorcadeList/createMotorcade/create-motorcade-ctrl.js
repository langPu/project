/**
 * Created by fangqiang on 16/11/17.
 */
    'use strict';
    angular.module('chuanyang').controller('createMotorcadeListController', createMotorcadeListController);
    createMotorcadeListController.$inject = ['$http', '$state', '$scope', '$modal', 'FileUploader', '$localStorage','toaster','urls'];
    function createMotorcadeListController($http, $state, $scope, $modal, FileUploader, $localStorage,toaster,urls) {
        var vm = this;
        vm.params = {};
        vm.params.fleetLines = [];
        vm.params.fleetImgs = [];
        vm.selectMotorcader = function () {
            $scope.items = {
                "title": "选择车队长",
                "name": "选择车队长"
            };
            var modalInstance = $modal.open({
                templateUrl: 'selectMotorcadeModel.html',
                controller: 'createMotorcadeModelController',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                console.log(angular.toJson(selectedItem, true));
                vm.params.leaderName = selectedItem.selected.username;
                vm.params.fleetLeader = selectedItem.selected.userId;
            }, function () {
            });

        };

        vm.addLines = function () {
            vm.items = {
                "title": "修改车辆信息",
                "data": [
                    {name: '起始点', type: 'text', filter: 'text'},
                    {name: '起始城市', type: 'text', filter: 'text'},
                    {name: '目的地', type: 'text', filter: 'text'},
                    {name: '目的城市', type: 'text', filter: 'text'}
                ]
            };
            var modalInstance = $modal.open({
                templateUrl: 'changeConpany.html',
                controller: 'repeatModelCtrl',
                resolve: {
                    items: function () {
                        return vm.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                console.log(angular.toJson(selectedItem, true));
                var lines = {};
                lines.startAddr = selectedItem.data[0].model;
                lines.startCity = selectedItem.data[1].model;
                lines.targetAddr = selectedItem.data[2].model;
                lines.targetCity = selectedItem.data[3].model;

                vm.params.fleetLines.push(lines);
            }, function () {
            });
        };

        vm.removeLines = function (index, list) {
            vm.params.fleetLines.splice(index, 1);


        };

        vm.addMotocade = function () {
            // console.log(angular.toJson(vm.params,true));
            vm.params.fleetState = 2;
            vm.params.lcFleet = {};
            vm.params.lcFleet.logisticscompanyId = $localStorage.chuanYangloginMessege.companys[0].companyID;
            if($localStorage.chuanYangloginMessege.companys[0].companyGPSId == undefined){
                vm.params.lcFleet.companyGPSId = 1;

            }else{
                vm.params.lcFleet.companyGPSId = $localStorage.chuanYangloginMessege.companys[0].companyGPSId;

            }
            vm.params.lcFleet.state = 1;
            var url = ROOTCONFIG.basePath4 + "info/fleet/add";
            console.log(angular.toJson(vm.params, true));
            toaster.pop('wait', '提示', '正在更改数据', 60000);

            urls.sendRequest('POST', angular.toJson(vm.params), url, '').success(function (response) {
                toaster.clear();
                if (response.code == 100) {
                    toaster.pop('success', '提示', '添加成功');
                } else {
                    toaster.pop('error', '提示', '添加失败');
                }
            }).error(function (state) {

            });

            // vm.params.lcFleet.companyGPSId =

        };
        var uploaderOne = $scope.uploaderOne = new FileUploader({
            url: ROOTCONFIG.basePath1 + 'info/driver/uploadDriverImg',
            alias: 'image',
            queueLimit: 1

        });

        uploaderOne.filters.push({
            name: 'imageFilter',
            fn: function (item /*{File|FileLikeObject}*/, options) {
                var type = '|' + item.type.slice(item.type.lastIndexOf('/') + 1) + '|';
                return '|jpg|png|jpeg|bmp|gif|'.indexOf(type) !== -1;
            }
        });

        vm.uploaderOneParams = {};

        // uploaderOne.onProgressItem = function (fileItem, progress) {
        //     console.info('onProgressItem', fileItem, progress);
        // };
        uploaderOne.onSuccessItem = function (fileItem, response, status, headers) {
            console.log(angular.toJson(response, true));

            console.info('onSuccessItem', fileItem, response, status, headers);
            // vm.uploaderOneParams.name = fileItem._file.name;
            vm.params.fleetImgs[0] = response.data;
            console.log(fileItem._file.name);

        };
        uploaderOne.onErrorItem = function (fileItem, response, status, headers) {
            console.info('onErrorItem', fileItem, response, status, headers);
        };
        uploaderOne.removeFromQueue = function (value) {
            console.log(uploaderOne.queue);
            console.log(uploaderOne.queue.indexOf(value));
            uploaderOne.queue.splice(uploaderOne.queue.indexOf(value), 1);
            vm.params.fleetImgs[0] = undefined;
        };
    }

    angular.module('chuanyang').controller('createMotorcadeModelController', createMotorcadeModelController);
    createMotorcadeModelController.$inject = ['$http', '$state', '$scope', '$modal', '$modalInstance', 'items', '$localStorage', 'urls'];
    function createMotorcadeModelController($http, $state, $scope, $modal, $modalInstance, items, $localStorage, urls) {

        $scope.items = items;
        $scope.people = {};
        $scope.people.person = [];
        $scope.people.refreshAddresses = function (username) {
            var params = {};
            params.companyID = $localStorage.chuanYangloginMessege.companys[0].companyID;
            params.username = username;
            var url = ROOTCONFIG.basePath4 + "info/driverWeb/selectDriverNofleetCP";
            urls.sendRequest('POST', angular.toJson(params), url, '').success(function (response) {
                console.log(angular.toJson(response, true));
                if (response.code == '101') {

                } else if (response.code == '100') {

                    angular.copy(response.data, $scope.people.person);
                }
            }).error(function (status) {

            });
        };
        $scope.add = function () {
            $scope.selected = items;
            $modalInstance.close($scope.selected);
        };
        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };

    }

