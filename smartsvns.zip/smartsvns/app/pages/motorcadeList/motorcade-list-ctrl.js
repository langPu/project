/**
 * Created by fangqiang on 16/10/22.
 */
    'use strict';
    angular.module('chuanyang').controller('motorcadeListController', motorcadeListController);
    motorcadeListController.$inject = ['$http','$state','$scope'];
    function motorcadeListController($http,$state,$scope) {
        $scope.functionName = $state.current.url;
        var vm = this;
        vm.addCarrier = function (size) {
            console.log(size);
            switch (size) {
                case 1:
                    $state.go("home.motorcadeList.allCar");
                    $scope.functionName = "/allCar";

                    break;
                case 2:
                    $state.go("home.motorcadeList.motorcade");
                    $scope.functionName = "/motorcade";

                    break;
                case 3:
                    $state.go("home.motorcadeList.company");
                    $scope.functionName = "/company";

                    break;
                case 4:
                    $state.go("home.motorcadeList.vessel");
                    $scope.functionName = "/vessel";

                    break;
                case 5:
                    $state.go("home.motorcadeList.fleet");
                    $scope.functionName = "/fleet";

                    break;
            }

        };
    }
