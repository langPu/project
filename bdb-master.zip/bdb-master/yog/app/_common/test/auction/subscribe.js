/**
 * @description
 */
var Mock = require('mockjs');

module.exports.subscribe = function () {
  return {
    status: '0',
    count: 100
  }
};