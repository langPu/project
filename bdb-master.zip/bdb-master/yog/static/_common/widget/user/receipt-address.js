define('_common:widget/user/receipt-address.js', function(require, exports, module) {

/**
 * @author radish.
 */
var B = require('_common:js/bdb/core.js');

module.exports = {
	init: function () {
		this.event();
	},
	//用户登录
	save: function (e) {
		e && e.preventDefault();
		var name = $('#name').val(),
				tel = $('#tel').val(),
				code = $('#code').val(),
		    address = $('#address').val();

		/*if (!userName) {
			B.topWarn('用户名不能为空!');
			return false;
		}
		if (!password) {
			B.topWarn('密码不能为空!');
			return false;
		}*/
		/*$tip.hide();*/
		//向后台提交数据
		$.ajax({
			type: 'post',
			dataType: 'json',
			url: '/_common/user',
			data: {
				username: name,
				mobile: tel,
				post: code,
				address: address
			},
			success: function (data) {
				if (0 == data.status) {
					window.location.href = '/';
				} else {
					var msg = data.msg || '服务器异常，请稍后再试';
					B.topWarn(msg);
				}
			},
			error: function (jqXHR, textStatus, errorThrown) {
				$tip.html('服务器异常，请稍后再试').show();
			}
		});
	},

	event: function () {
		$('#btn-save').on('click', this.save.bind(this));
	}
};


});
