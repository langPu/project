define('_common:widget/login/login.js', function(require, exports, module) {

/**
 * @description
 */


});
