define('cus:widget/user/personal-card.js', function(require, exports, module) {

/**
 * @author radish.
 */
var B = require('_common:js/bdb/core.js');

var keyRemember = 'remember_pwd';//是否记住密码

module.exports = {
	init: function () {
		this.event();
		this.query();
	},
	//用户登录
	query: function (e) {
		e && e.preventDefault();

		//从后台获取个人资料
		$.ajax({
			type: 'get',
			dataType: 'json',
			url: '/user',
			data: null,
			success: function (data) {
				if (0 == data.status) {
					window.location.href = '/';
				} else {
					var msg = data.msg || '服务器异常，请稍后再试';
					B.topWarn(msg);
				}
			},
			error: function (jqXHR, textStatus, errorThrown) {
				/*$tip.html('服务器异常，请稍后再试').show();*/
			}
		});
	},

	event: function () {
		/*$('#btn-login').on('click', this.login.bind(this));
		$('#btn-remember').on('click', this.remember);*/
	}
};


});
