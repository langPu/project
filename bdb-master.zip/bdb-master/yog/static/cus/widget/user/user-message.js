define('cus:widget/user/user-message.js', function(require, exports, module) {



});
