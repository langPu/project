define('cus:widget/store.js', function(require, exports, module) {



});
