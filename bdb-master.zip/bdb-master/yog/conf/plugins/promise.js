/**
 * @description ral promise
 */
module.exports.promise = {
	overrideRAL: true
};