module.exports.session = {
    key: 'sid',
    secret: 'SecretWWW.bdb.vip.cOm',
    resave: false,
    saveUninitialized: true,
    cookie: {domain: 'bdbvip.com'}
};

/*
 module.exports.cookieParser = {
 secret: 'yog'
 };*/
