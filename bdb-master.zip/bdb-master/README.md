###技术结构


####系统设计
		设计风格
		RESTful、MVC
		页面布局
		用rem来实现多屏适配


####工程构建

		fis3
		http://fex-team.github.io/fis3/index.html

####NodeJS框架

		express
		http://expressjs.com/zh/
		
		yog2
		https://github.com/fex-team/yog2
		
		模板引擎
		http://paularmstrong.github.io/swig/docs/
		
####模拟数据
		
		mock.js
		http://mockjs.com/#

####环境安装
1. 安装NodeJS
2. 安装yog2 

		npm i -g yog2
		
3. 安装插件fis-optimizer-tpl 

		npm i -g fis-parser-optimizer-tpl
		
		
####本地改进
		1.less编译模块-支持了跨模块的引用
		2.ral模块-更加符合需要的日志输出
		
		
		

