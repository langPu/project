/**
 * @author chenzhenhua
 * @createTime 2015-12-29
 * @description
 */

module.exports = {
	pay: function (){

	}
}