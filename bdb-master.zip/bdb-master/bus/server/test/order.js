module.exports ={
  form:'bus',
  status:'dfh',//dfh待发货  dfk待付款  yfh已发货  tkz退款中
  dataList:[
    {
      date: '2015-09-09',
      name: '满绿翡翠吊玉',
      money: '48000.00',
      num: '1',
      pay: '48000.00',
      'img-url':''
    },
    {
      date: '2015-09-09',
      name: '满绿翡翠吊玉',
      money: '48000.00',
      num: '1',
      pay: '48000.00',
      'img-url':''
    }
  ]
};