module.exports ={
  from:'bus',
  status:'tkz',//dfh待发货  dfk待付款  yfh已发货  tkz退款中
  commodity:[
      {
        name: '满绿翡翠吊玉',
        money: '48000.00',
        num: '1',
        pay: '48000.00',
        'img-url':''
      },
      {
        name: '满绿翡翠吊玉',
        money: '48000.00',
        num: '1',
        pay: '48000.00',
        'img-url':''
      }
    ],
    freight:'12', //运费
    insurance:'0.8',  //运费险
    payTotal:'48000.00',
    orderNo:'62534415783',
    dealTime:'2015-09-04 21:10',
    payTime:'2015-10-04 10:10',
    deliverTime:'2015-09-02 09:50',
    confirmTime:'2015-09-08 11:20',
    receiptName:'老刘',
    receiptTel:'18952632412',
    receiptAddress:'广东省深圳市宝安大道'
};