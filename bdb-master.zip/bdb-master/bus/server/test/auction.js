module.exports ={
  form:'bus',
  dataList:[
    {
      name: '小唐的店铺',
      shop:'满绿翡翠吊坠',
      details: '翡翠吊坠铂金镶嵌 钻石0.43克拉',
      date: '01/01-01/05',
      num: '41',
      pay: '48000.00',
      'img-url':'',
      status: 'wks'
    },
    {
      name: '小唐的店铺',
      shop:'满绿翡翠吊坠',
      details: '翡翠吊坠铂金镶嵌 钻石0.43克拉',
      date: '01/01-01/05',
      num: '41',
      pay: '48000.00',
      'img-url':'',
      status: 'dsh'
    },
    {
      name: '小唐的店铺',
      shop:'满绿翡翠吊坠',
      details: '翡翠吊坠铂金镶嵌 钻石0.43克拉',
      date: '01/01-01/05',
      num: '41',
      pay: '48000.00',
      'img-url':'',
      status: 'cj'
    },
    {
      name: '小唐的店铺',
      shop:'满绿翡翠吊坠',
      details: '翡翠吊坠铂金镶嵌 钻石0.43克拉',
      date: '01/01-01/05',
      num: '41',
      pay: '48000.00',
      'img-url':'',
      status: 'wks'
    }
  ]
};