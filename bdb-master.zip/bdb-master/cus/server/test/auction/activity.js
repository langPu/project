//
module.exports = {
	getData:function(){
    return {
      form:'cus',
      dataList:[
        {
          name: '小唐的店铺',
          shop:'满绿翡翠吊坠',
          details: '翡翠吊坠铂金镶嵌 钻石0.43克拉',
          date: '01/01-01/05',
          num: '41',
          pay: '48000.00',
          'img-url':'',
          status: 0
        },
        {
          name: '小唐的店铺',
          shop:'满绿翡翠吊坠',
          details: '翡翠吊坠铂金镶嵌 钻石0.43克拉',
          date: '01/01-01/05',
          num: '41',
          pay: '48000.00',
          'img-url':'',
          status: 1
        },
        {
          name: '小唐的店铺',
          shop:'满绿翡翠吊坠',
          details: '翡翠吊坠铂金镶嵌 钻石0.43克拉',
          date: '01/01-01/05',
          num: '41',
          pay: '48000.00',
          'img-url':'',
          status: 2
        },
        {
          name: '小唐的店铺',
          shop:'满绿翡翠吊坠',
          details: '翡翠吊坠铂金镶嵌 钻石0.43克拉',
          date: '01/01-01/05',
          num: '41',
          pay: '48000.00',
          'img-url':'',
          status: 3
        }
      ]
    }
  }
};