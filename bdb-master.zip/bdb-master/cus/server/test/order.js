module.exports ={
  form:'cus',
  //status: dfh待发货  dfk待付款  yfh已发货  tkz退款中  dsh待收货
  dataList:[
    {
      status:'dfk',
      date: '2015-09-24',
      name: '满绿翡翠吊玉',
      money: '48000.00',
      num: '1',
      pay: '48000.00',
      'img-url':''
    },
    {
      status:'dfh',
      date: '2015-09-24',
      name: '吉安妮钻石项链',
      money: '15800.00',
      num: '1',
      pay: '15000.00',
      'img-url':''
    },
    {
      status:'dsh',
      date: '2015-09-24',
      name: '蓝宝石耳钉',
      money: '8800.00',
      num: '1',
      pay: '8800.00',
      'img-url':''
    },
    {
      status:'dpj',
      date: '2015-09-24',
      name: '蓝宝石耳钉',
      money: '8800.00',
      num: '1',
      pay: '8800.00',
      'img-url':''
    },
    {
      status:'ywc',
      date: '2015-09-24',
      name: '蓝宝石耳钉',
      money: '8800.00',
      num: '1',
      pay: '8800.00',
      'img-url':''
    },
    {
      status:'tkz',
      date: '2015-09-24',
      name: '蓝宝石耳钉',
      money: '8800.00',
      num: '1',
      pay: '8800.00',
      'img-url':''
    }
  ]
};
