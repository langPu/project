$(document).ready(function() {
	var height;
	var width = $(document.body).width();
	var body;
	if (navigator.userAgent.indexOf("Firefox") > 0 || navigator.userAgent.indexOf("MSIE") > 0) {
		body = document.documentElement;
	} else {
		body = document.body;
	}

	//判断鼠标滚动 上、下
	var isFinish = true;
	var scrollFunc = function(e) {
		if (isFinish) {
			var scrollTop = body.scrollTop;
			e = e || window.event;
			if ((e.wheelDelta < 0 || e.detail > 0)) { //}&& scrollTop >= 0 && scrollTop < height - 20) {
				//向下
				console.log("向下")
				height = $(document.body).height();
				scroll(height, "down");
			} else if ((e.wheelDelta > 0 || e.detail < 0)) { // && scrollTop >= height && scrollTop <= height + 20) {
				//向上
				console.log("向上")
				height = $(document.body).height();
				scroll(height, "up");
			}
		}
	};

	//滚动事件
	var numup = 0;
	var numdown = 0;
	var index = 0;
	var scroll = function(height, der) {
		isFinish = false;
		if (der == "down") {
			index = ++index < 4 ? index : 3
			$("#div_bg").removeClass().addClass("div_bg_" + index + "");
			$(".play-icon li").eq(index).css("background","#fff").siblings().css("background","transparent")
			$("#div-temp").animate({
				marginTop: -index * height
			}, "slow", "linear", function() {
				isFinish = true;
			});
		} else if (der == "up") {
			index = --index > 0 ? index : 0
			$("#div_bg").removeClass().addClass("div_bg_" + index + "");
			$(".play-icon li").eq(index).css("background","#fff").siblings().css("background","transparent")
			$("#div-temp").animate({
				marginTop: -index * height
			}, "slow", "linear", function() {
				isFinish = true;
			});
		}
	};

	$(".play-icon li").first().css("background", "#fff");
	$(".play-icon li").click(function() {
		index = $(this).index();
		$(this).css("background","#fff").siblings().css("background","transparent")
		$("#div_bg").removeClass().addClass("div_bg_" + index + "");
		
		$("#div-temp").animate({
			marginTop: -index * height
		}, "slow", "linear", function() {});
	})

	//事件注册
	if (navigator.userAgent.indexOf("Firefox") > 0) {
		if (document.addEventListener) {
			document.addEventListener('DOMMouseScroll', scrollFunc, false);
		}
	} else {
		document.onmousewheel = scrollFunc;
	}

});